// WidgetBlueprintGeneratedClass KeyGuideTabContentWidget.KeyGuideTabContentWidget_C
// Size: 0x518 (Inherited: 0x500)
struct UKeyGuideTabContentWidget_C : U*d4399f19a3 {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x500(0x08)
	struct UTextBlock* TitleNormal; // 0x508(0x08)
	struct UTextBlock* TitleSelected; // 0x510(0x08)

	void PreConstruct(); // Function KeyGuideTabContentWidget.KeyGuideTabContentWidget_C.PreConstruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x32e590
	int32 ExecuteUbergraph_KeyGuideTabContentWidget(); // Function KeyGuideTabContentWidget.KeyGuideTabContentWidget_C.ExecuteUbergraph_KeyGuideTabContentWidget //  // @ game+0x32e590
};

