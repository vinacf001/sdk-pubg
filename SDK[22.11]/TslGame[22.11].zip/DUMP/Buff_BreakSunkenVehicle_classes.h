// BlueprintGeneratedClass Buff_BreakSunkenVehicle.Buff_BreakSunkenVehicle_C
// Size: 0x480 (Inherited: 0x470)
struct ABuff_BreakSunkenVehicle_C : ATslBuff {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x470(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x478(0x08)

	void UserConstructionScript(); // Function Buff_BreakSunkenVehicle.Buff_BreakSunkenVehicle_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void TickBuff(); // Function Buff_BreakSunkenVehicle.Buff_BreakSunkenVehicle_C.TickBuff // Event|Public|BlueprintEvent // @ game+0x32e590
	void StopBuffBlueprint(); // Function Buff_BreakSunkenVehicle.Buff_BreakSunkenVehicle_C.StopBuffBlueprint // Event|Public|BlueprintEvent // @ game+0x32e590
	bool ExecuteUbergraph_Buff_BreakSunkenVehicle(); // Function Buff_BreakSunkenVehicle.Buff_BreakSunkenVehicle_C.ExecuteUbergraph_Buff_BreakSunkenVehicle //  // @ game+0x32e590
};

