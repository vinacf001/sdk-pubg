// WidgetBlueprintGeneratedClass BP_FlowTextWidget.BP_FlowTextWidget_C
// Size: 0x448 (Inherited: 0x448)
struct UBP_FlowTextWidget_C : U*d426ac14c0 {
};

