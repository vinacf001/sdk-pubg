// BlueprintGeneratedClass BP_DamageField_JerryCan.BP_DamageField_JerryCan_C
// Size: 0x490 (Inherited: 0x490)
struct ABP_DamageField_JerryCan_C : ATslDamageField {

	bool UserConstructionScript(); // Function BP_DamageField_JerryCan.BP_DamageField_JerryCan_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x32e590
};

