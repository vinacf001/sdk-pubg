// BlueprintGeneratedClass BP_TslBaseLobbySceneTravel_CameraMove.BP_TslBaseLobbySceneTravel_CameraMove_C
// Size: 0x588 (Inherited: 0x580)
struct ABP_TslBaseLobbySceneTravel_CameraMove_C : ATslLobbySceneTravel_CameraMove {
	struct USceneComponent* DefaultSceneRoot; // 0x580(0x08)

	void UserConstructionScript(); // Function BP_TslBaseLobbySceneTravel_CameraMove.BP_TslBaseLobbySceneTravel_CameraMove_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x32e590
};

