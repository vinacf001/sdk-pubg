// BlueprintGeneratedClass M_OutPlayArea2.M_OutPlayArea2_C
// Size: 0x480 (Inherited: 0x470)
struct AM_OutPlayArea2_C : ATslPostProcessEffect {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x470(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x478(0x08)

	void UserConstructionScript(); // Function M_OutPlayArea2.M_OutPlayArea2_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void OnSetEffectParameter(struct FString ParameterName); // Function M_OutPlayArea2.M_OutPlayArea2_C.OnSetEffectParameter // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x32e590
	bool ExecuteUbergraph_M_OutPlayArea2(int32 EntryPoint); // Function M_OutPlayArea2.M_OutPlayArea2_C.ExecuteUbergraph_M_OutPlayArea2 //  // @ game+0x32e590
};

