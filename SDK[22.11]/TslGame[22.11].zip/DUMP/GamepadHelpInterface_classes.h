// BlueprintGeneratedClass GamepadHelpInterface.GamepadHelpInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UGamepadHelpInterface_C : UInterface {

	void GetGamePadHelpWidgetClass(); // Function GamepadHelpInterface.GamepadHelpInterface_C.GetGamePadHelpWidgetClass // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x32e590
};

