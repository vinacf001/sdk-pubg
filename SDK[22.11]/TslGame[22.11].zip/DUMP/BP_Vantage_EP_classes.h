// BlueprintGeneratedClass BP_Vantage_EP.BP_Vantage_EP_C
// Size: 0x1000 (Inherited: 0x1000)
struct ABP_Vantage_EP_C : ABP_Vantage_C {
};

