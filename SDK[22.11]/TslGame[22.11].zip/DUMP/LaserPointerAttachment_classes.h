// BlueprintGeneratedClass LaserPointerAttachment.LaserPointerAttachment_C
// Size: 0xc30 (Inherited: 0xc30)
struct ULaserPointerAttachment_C : U*8dcf0e5779 {
};

