// BlueprintGeneratedClass FBPBuff_AddMovementSpeed.FBPBuff_AddMovementSpeed_C
// Size: 0x4a0 (Inherited: 0x498)
struct AFBPBuff_AddMovementSpeed_C : ATslFBRBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x498(0x08)

	void UserConstructionScript(); // Function FBPBuff_AddMovementSpeed.FBPBuff_AddMovementSpeed_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x32e590
};

