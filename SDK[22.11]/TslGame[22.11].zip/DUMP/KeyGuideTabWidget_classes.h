// WidgetBlueprintGeneratedClass KeyGuideTabWidget.KeyGuideTabWidget_C
// Size: 0x468 (Inherited: 0x468)
struct UKeyGuideTabWidget_C : U*61f9f61a04 {
};

