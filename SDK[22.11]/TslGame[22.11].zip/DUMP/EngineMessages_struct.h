// ScriptStruct EngineMessages.*2316223636
// Size: 0x18 (Inherited: 0x00)
struct F*2316223636 {
	struct FString Text; // 0x00(0x10)
	double TimeSeconds; // 0x10(0x08)
};

// ScriptStruct EngineMessages.*a377abb4d3
// Size: 0x10 (Inherited: 0x00)
struct F*a377abb4d3 {
	struct FString UserName; // 0x00(0x10)
};

// ScriptStruct EngineMessages.*7289a16527
// Size: 0x20 (Inherited: 0x00)
struct F*7289a16527 {
	struct FString Command; // 0x00(0x10)
	struct FString UserName; // 0x10(0x10)
};

// ScriptStruct EngineMessages.*9c6f799623
// Size: 0x20 (Inherited: 0x00)
struct F*9c6f799623 {
	struct FString UserName; // 0x00(0x10)
	struct FString *b9a320e7cb; // 0x10(0x10)
};

// ScriptStruct EngineMessages.*344d924f36
// Size: 0x20 (Inherited: 0x00)
struct F*344d924f36 {
	struct FString UserName; // 0x00(0x10)
	struct FString *cfbdc306b6; // 0x10(0x10)
};

// ScriptStruct EngineMessages.*ec03e7bb7c
// Size: 0x50 (Inherited: 0x00)
struct F*ec03e7bb7c {
	struct FString CurrentLevel; // 0x00(0x10)
	int32 EngineVersion; // 0x10(0x04)
	bool *8cab2d71c2; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	struct FGuid InstanceId; // 0x18(0x10)
	struct FString InstanceType; // 0x28(0x10)
	struct FGuid SessionId; // 0x38(0x10)
	float *a1fb6f04f4; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// ScriptStruct EngineMessages.*f541f7b217
// Size: 0x01 (Inherited: 0x00)
struct F*f541f7b217 {
	char pad_0[0x1]; // 0x00(0x01)
};

