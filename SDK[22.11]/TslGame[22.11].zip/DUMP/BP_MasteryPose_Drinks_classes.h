// BlueprintGeneratedClass BP_MasteryPose_Drinks.BP_MasteryPose_Drinks_C
// Size: 0x498 (Inherited: 0x438)
struct ABP_MasteryPose_Drinks_C : ABP_MasteryPose_C {
	struct UAsyncStaticMeshComponent* Can_inside3; // 0x438(0x08)
	struct UAsyncStaticMeshComponent* Can_inside2; // 0x440(0x08)
	struct UAsyncStaticMeshComponent* Can_inside1; // 0x448(0x08)
	struct UAsyncStaticMeshComponent* FridgeMesh; // 0x450(0x08)
	struct UAsyncStaticMeshComponent* DrinkMesh; // 0x458(0x08)
	struct UAsyncStaticMeshComponent* Can5; // 0x460(0x08)
	struct UAsyncStaticMeshComponent* Can4; // 0x468(0x08)
	struct UAsyncStaticMeshComponent* Can3; // 0x470(0x08)
	struct UAsyncStaticMeshComponent* Can2; // 0x478(0x08)
	struct UAsyncStaticMeshComponent* Can1; // 0x480(0x08)
	struct UAsyncStaticMeshComponent* BinMesh; // 0x488(0x08)
	struct USpotLightComponent* spotlight; // 0x490(0x08)

	void UserConstructionScript(); // Function BP_MasteryPose_Drinks.BP_MasteryPose_Drinks_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x32e590
};

