// Class MK3DPublisher.AudioCapturer
// Size: 0x468 (Inherited: 0x3e8)
struct AAudioCapturer : AActor {
	char pad_3E8[0x80]; // 0x3e8(0x80)
};

// Class MK3DPublisher.*d340a69cdb
// Size: 0x28 (Inherited: 0x28)
struct U*d340a69cdb : UBlueprintFunctionLibrary {

	void *f51f7c3053(); // Function MK3DPublisher.*d340a69cdb.*f51f7c3053 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x67458d4
	void *8239d16133(); // Function MK3DPublisher.*d340a69cdb.*8239d16133 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746d6c
	struct FString *d8fbc089a3(int32 Height); // Function MK3DPublisher.*d340a69cdb.*d8fbc089a3 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6747598
	int32 *236c91f525(int32 VideoBitrate); // Function MK3DPublisher.*d340a69cdb.*236c91f525 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x67470c0
	void *5b69d3d575(); // Function MK3DPublisher.*d340a69cdb.*5b69d3d575 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6745ad8
	void *3725c796f5(); // Function MK3DPublisher.*d340a69cdb.*3725c796f5 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746638
	int32 *aade74eb6e(); // Function MK3DPublisher.*d340a69cdb.*aade74eb6e // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x67462d8
	void *9faa1720ab(); // Function MK3DPublisher.*d340a69cdb.*9faa1720ab // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746e7c
	void *2a8f3eaa0d(); // Function MK3DPublisher.*d340a69cdb.*2a8f3eaa0d // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746af8
	void *2d9e03186b(); // Function MK3DPublisher.*d340a69cdb.*2d9e03186b // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x67466c0
	void *c1674adf43(); // Function MK3DPublisher.*d340a69cdb.*c1674adf43 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746580
	void *24a6d16d39(); // Function MK3DPublisher.*d340a69cdb.*24a6d16d39 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x674687c
	void *72c374ae64(); // Function MK3DPublisher.*d340a69cdb.*72c374ae64 // Final|Native|Static|Public|BlueprintCallable // @ game+0x67472bc
	void *e6823d6970(); // Function MK3DPublisher.*d340a69cdb.*e6823d6970 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746ad4
	struct FString *4c312458ba(); // Function MK3DPublisher.*d340a69cdb.*4c312458ba // Final|Native|Static|Public|BlueprintCallable // @ game+0x6747338
	void *e72e52dc8f(); // Function MK3DPublisher.*d340a69cdb.*e72e52dc8f // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746bc0
	void *51a1ac92cc(int32 inIdx); // Function MK3DPublisher.*d340a69cdb.*51a1ac92cc // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6746144
	int32 *5635330ad3(); // Function MK3DPublisher.*d340a69cdb.*5635330ad3 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745f18
	void *0f77220a7b(); // Function MK3DPublisher.*d340a69cdb.*0f77220a7b // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746c20
	void *ef40c99ac4(); // Function MK3DPublisher.*d340a69cdb.*ef40c99ac4 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746dd0
	void *8c667b961f(); // Function MK3DPublisher.*d340a69cdb.*8c667b961f // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x67467c8
	void *8ecc4e4773(); // Function MK3DPublisher.*d340a69cdb.*8ecc4e4773 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746c84
	struct FString *dd8493fa2a(); // Function MK3DPublisher.*d340a69cdb.*dd8493fa2a // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6747b30
	void *3bedc1c81d(int32 Height); // Function MK3DPublisher.*d340a69cdb.*3bedc1c81d // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745b84
	void *4ba3798cc7(); // Function MK3DPublisher.*d340a69cdb.*4ba3798cc7 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746610
	void *62c99f76b0(); // Function MK3DPublisher.*d340a69cdb.*62c99f76b0 // Final|Native|Static|Public|BlueprintCallable // @ game+0x67477f8
	void *8e9944cf63(); // Function MK3DPublisher.*d340a69cdb.*8e9944cf63 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6747a34
	void *885f580d45(); // Function MK3DPublisher.*d340a69cdb.*885f580d45 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6747324
	void *66f35dbe77(); // Function MK3DPublisher.*d340a69cdb.*66f35dbe77 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746a70
	struct UUserWidget* *fab4ef9aeb(); // Function MK3DPublisher.*d340a69cdb.*fab4ef9aeb // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745844
	void *b55e7440af(); // Function MK3DPublisher.*d340a69cdb.*b55e7440af // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746b5c
	void *6d54beafda(int32 inIdx); // Function MK3DPublisher.*d340a69cdb.*6d54beafda // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x674603c
	void *8a00777bc0(); // Function MK3DPublisher.*d340a69cdb.*8a00777bc0 // Final|Native|Static|Public|BlueprintCallable // @ game+0x67465e0
	int32 *36d810ce16(); // Function MK3DPublisher.*d340a69cdb.*36d810ce16 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745e88
	int32 *82519c6c0e(int32 Height); // Function MK3DPublisher.*d340a69cdb.*82519c6c0e // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6746f24
	void *5c58eaa378(); // Function MK3DPublisher.*d340a69cdb.*5c58eaa378 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6745c9c
	float *a7a2f277bc(); // Function MK3DPublisher.*d340a69cdb.*a7a2f277bc // Final|Native|Static|Public|BlueprintCallable // @ game+0x674794c
	void *f5b00bdc7e(); // Function MK3DPublisher.*d340a69cdb.*f5b00bdc7e // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745e60
	void *1d9afe09f4(); // Function MK3DPublisher.*d340a69cdb.*1d9afe09f4 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6745a2c
	void *26eefef501(); // Function MK3DPublisher.*d340a69cdb.*26eefef501 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745dc8
	float *cf6d1c5d08(); // Function MK3DPublisher.*d340a69cdb.*cf6d1c5d08 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6747864
	void *dec5e093e9(); // Function MK3DPublisher.*d340a69cdb.*dec5e093e9 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746930
	void *0e1307f80d(); // Function MK3DPublisher.*d340a69cdb.*0e1307f80d // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6745980
	void *8ccdc3df17(); // Function MK3DPublisher.*d340a69cdb.*8ccdc3df17 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745fa4
	void *34576e9f63(); // Function MK3DPublisher.*d340a69cdb.*34576e9f63 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746d08
	int32 *b12c16bc50(); // Function MK3DPublisher.*d340a69cdb.*b12c16bc50 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x67463e4
};

// Class MK3DPublisher.ViewportCapturer
// Size: 0x480 (Inherited: 0x3e8)
struct AViewportCapturer : AActor {
	char pad_3E8[0x98]; // 0x3e8(0x98)
};

