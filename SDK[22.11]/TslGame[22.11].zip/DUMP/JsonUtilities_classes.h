// Class JsonUtilities.*234db94519
// Size: 0x28 (Inherited: 0x28)
struct U*234db94519 : UObject {
};

