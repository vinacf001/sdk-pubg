// WidgetBlueprintGeneratedClass BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C
// Size: 0x8c0 (Inherited: 0x890)
struct UBP_PcOptionItemDropDownListWidget_C : U*90bdb4fc86 {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x890(0x08)
	struct U*125d11dc45* ComboBox; // 0x898(0x08)
	struct UButton* ComboBoxButton; // 0x8a0(0x08)
	struct USizeBox* IndentationSizeBox; // 0x8a8(0x08)
	struct FMulticastDelegate OnSelectionChanged; // 0x8b0(0x10)

	struct FString BndEvt__ComboBox_K2Node_ComponentBoundEvent_21_OnSelectionChangedEvent__DelegateSignature(); // Function BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C.BndEvt__ComboBox_K2Node_ComponentBoundEvent_21_OnSelectionChangedEvent__DelegateSignature // BlueprintEvent // @ game+0x32e590
	struct FString ExecuteUbergraph_BP_PcOptionItemDropDownListWidget(); // Function BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C.ExecuteUbergraph_BP_PcOptionItemDropDownListWidget //  // @ game+0x32e590
	void OnSelectionChanged__DelegateSignature(); // Function BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C.OnSelectionChanged__DelegateSignature // Public|Delegate|BlueprintCallable|BlueprintEvent // @ game+0x32e590
};

