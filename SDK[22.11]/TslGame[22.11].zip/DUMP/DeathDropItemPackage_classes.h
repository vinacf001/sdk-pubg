// BlueprintGeneratedClass DeathDropItemPackage.DeathDropItemPackage_C
// Size: 0x618 (Inherited: 0x610)
struct ADeathDropItemPackage_C : AFloorSnapItemPackage {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x610(0x08)

	struct TArray<struct FFormatArgumentData> GetCategory(); // Function DeathDropItemPackage.DeathDropItemPackage_C.GetCategory // Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void UserConstructionScript(); // Function DeathDropItemPackage.DeathDropItemPackage_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void ReceiveBeginPlay(); // Function DeathDropItemPackage.DeathDropItemPackage_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x32e590
	void ExecuteUbergraph_DeathDropItemPackage(); // Function DeathDropItemPackage.DeathDropItemPackage_C.ExecuteUbergraph_DeathDropItemPackage // HasDefaults // @ game+0x32e590
};

