// WidgetBlueprintGeneratedClass MainLobbyHUD.MainLobbyHUD_C
// Size: 0x338 (Inherited: 0x310)
struct UMainLobbyHUD_C : U*76dd958a40 {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x310(0x08)
	struct UInvalidationBox* InvalidationBox_1; // 0x318(0x08)
	struct UInvalidationBox* InvalidationBox_2; // 0x320(0x08)
	struct UImage* LoadingSpinnerImage; // 0x328(0x08)
	struct AReplayList_BP_C* refReplayListBp; // 0x330(0x08)

	struct FKeyEvent OnKeyDown(); // Function MainLobbyHUD.MainLobbyHUD_C.OnKeyDown // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void HasChildren(); // Function MainLobbyHUD.MainLobbyHUD_C.HasChildren // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x32e590
	void BndEvt__Button_0_K2Node_ComponentBoundEvent_35_OnButtonClickedEvent__DelegateSignature(); // Function MainLobbyHUD.MainLobbyHUD_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_35_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x32e590
	int32 ExecuteUbergraph_MainLobbyHUD(bool CallFunc_IsValid_ReturnValue, struct AActor* CallFunc__156662a2f2_ReturnValue); // Function MainLobbyHUD.MainLobbyHUD_C.ExecuteUbergraph_MainLobbyHUD // HasDefaults // @ game+0x32e590
};

