// BlueprintGeneratedClass BP_ItemRecommendManager.BP_ItemRecommendManager_C
// Size: 0x118 (Inherited: 0x118)
struct UBP_ItemRecommendManager_C : U*68c77a10e7 {
};

