// WidgetBlueprintGeneratedClass BP_PcOptionTabLabelWidget.BP_PcOptionTabLabelWidget_C
// Size: 0x4b8 (Inherited: 0x4b8)
struct UBP_PcOptionTabLabelWidget_C : U*57196c3db1 {
};

