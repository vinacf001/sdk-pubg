// BlueprintGeneratedClass McLarenGT_Wheel.McLarenGT_Wheel_C
// Size: 0x3a8 (Inherited: 0x3a8)
struct UMcLarenGT_Wheel_C : U*179c2e5850 {
};

