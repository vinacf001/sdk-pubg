// WidgetBlueprintGeneratedClass LobbyWebView.LobbyWebView_C
// Size: 0x438 (Inherited: 0x430)
struct ULobbyWebView_C : U*89013b1e2f {
	struct ULobbyRotationRectWidget_C* RotationRect; // 0x430(0x08)

	struct FText OnKeyUp(struct FKey CallFunc_GetKey_ReturnValue, struct FString CallFunc__cf9e97b29f_ReturnValue); // Function LobbyWebView.LobbyWebView_C.OnKeyUp // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x32e590
	struct FString OnKeyDown(struct FKeyEvent InKeyEvent, struct FEventReply ReturnValue, struct FText CallFunc__4b809b55f3_ReturnValue); // Function LobbyWebView.LobbyWebView_C.OnKeyDown // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x32e590
	float OnPreviewMouseButtonDown(struct FEventReply CallFunc__7229935fb0_ReturnValue); // Function LobbyWebView.LobbyWebView_C.OnPreviewMouseButtonDown // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void GetMainCoherentWidget(); // Function LobbyWebView.LobbyWebView_C.GetMainCoherentWidget // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const // @ game+0x32e590
	struct FKey OnPreviewKeyDown(struct FEventReply ReturnValue, struct FString CallFunc__cf9e97b29f_ReturnValue); // Function LobbyWebView.LobbyWebView_C.OnPreviewKeyDown // Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x32e590
};

