// BlueprintGeneratedClass GunImpact_Sniper.GunImpact_Sniper_C
// Size: 0x12e8 (Inherited: 0x12e0)
struct AGunImpact_Sniper_C : ATslGunImpact {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x12e0(0x08)

	void UserConstructionScript(); // Function GunImpact_Sniper.GunImpact_Sniper_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void ExecuteUbergraph_GunImpact_Sniper(); // Function GunImpact_Sniper.GunImpact_Sniper_C.ExecuteUbergraph_GunImpact_Sniper //  // @ game+0x32e590
};

