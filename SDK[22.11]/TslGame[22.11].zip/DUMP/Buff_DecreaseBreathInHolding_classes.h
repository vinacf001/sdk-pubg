// BlueprintGeneratedClass Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C
// Size: 0x498 (Inherited: 0x478)
struct ABuff_DecreaseBreathInHolding_C : ACharacterBreathBuff {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x478(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x480(0x08)
	struct F*9147081c37 BuffClass; // 0x488(0x10)

	enum class EBreathType UserConstructionScript(); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void TickBuff(); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.TickBuff // Event|Public|BlueprintEvent // @ game+0x32e590
	bool ExecuteUbergraph_Buff_DecreaseBreathInHolding(struct ATslCharacter* CallFunc__a4519f511d_ReturnValue, struct ATslCharacter* K2Node_Event_OtherCharacter, bool K2Node_DynamicCast_bSuccess); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.ExecuteUbergraph_Buff_DecreaseBreathInHolding //  // @ game+0x32e590
};

