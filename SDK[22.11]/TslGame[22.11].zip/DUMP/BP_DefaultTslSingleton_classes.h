// BlueprintGeneratedClass BP_DefaultTslSingleton.BP_DefaultTslSingleton_C
// Size: 0x12d8 (Inherited: 0x12d8)
struct UBP_DefaultTslSingleton_C : U*21d7aec80c {
};

