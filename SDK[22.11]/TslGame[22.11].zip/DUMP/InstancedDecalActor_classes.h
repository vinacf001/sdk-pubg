// BlueprintGeneratedClass InstancedDecalActor.InstancedDecalActor_C
// Size: 0x3f0 (Inherited: 0x3f0)
struct AInstancedDecalActor_C : ADecalActor {
};

