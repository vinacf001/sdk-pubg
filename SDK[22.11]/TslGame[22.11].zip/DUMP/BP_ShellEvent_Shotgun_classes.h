// BlueprintGeneratedClass BP_ShellEvent_Shotgun.BP_ShellEvent_Shotgun_C
// Size: 0x88 (Inherited: 0x88)
struct UBP_ShellEvent_Shotgun_C : U*02828cfc0e {
};

