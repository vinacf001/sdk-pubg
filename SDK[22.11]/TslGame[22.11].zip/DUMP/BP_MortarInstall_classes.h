// BlueprintGeneratedClass BP_MortarInstall.BP_MortarInstall_C
// Size: 0x448 (Inherited: 0x440)
struct ABP_MortarInstall_C : APowerup_Base_C {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x440(0x08)

	void UserConstructionScript(); // Function BP_MortarInstall.BP_MortarInstall_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void ReceiveBeginPlay(); // Function BP_MortarInstall.BP_MortarInstall_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x32e590
	void PlayAnim_MortarInstall(); // Function BP_MortarInstall.BP_MortarInstall_C.PlayAnim_MortarInstall // BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void ExecuteUbergraph_BP_MortarInstall(); // Function BP_MortarInstall.BP_MortarInstall_C.ExecuteUbergraph_BP_MortarInstall //  // @ game+0x32e590
};

