// BlueprintGeneratedClass DmgTypeExplosion_JerryCan.DmgTypeExplosion_JerryCan_C
// Size: 0xf8 (Inherited: 0xf8)
struct UDmgTypeExplosion_JerryCan_C : UTslDamageType {
};

