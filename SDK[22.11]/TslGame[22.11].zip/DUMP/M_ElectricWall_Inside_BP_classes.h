// BlueprintGeneratedClass M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C
// Size: 0x490 (Inherited: 0x470)
struct AM_ElectricWall_Inside_BP_C : ATslPostProcessEffect {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x470(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x478(0x08)
	float _____0______0_F1196C2844F052526643A091F7753F02; // 0x480(0x04)
	enum class ETimelineDirection _____0__Direction_F1196C2844F052526643A091F7753F02; // 0x484(0x01)
	char pad_485[0x3]; // 0x485(0x03)
	struct UTimelineComponent* �Є�|�x�_1; // 0x488(0x08)

	void UserConstructionScript(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void �Є�|�x�_(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.�Є�|�x�_ // BlueprintEvent // @ game+0x32e590
	void �Є�|�x�_(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.�Є�|�x�_ // BlueprintEvent // @ game+0x32e590
	void ReceiveBeginPlay(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x32e590
	void Custom Event_1(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.Custom Event_1 // BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void OnSetEffectParameter(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.OnSetEffectParameter // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x32e590
	bool ExecuteUbergraph_M_ElectricWall_Inside_BP(int32 EntryPoint); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.ExecuteUbergraph_M_ElectricWall_Inside_BP // HasDefaults // @ game+0x32e590
};

