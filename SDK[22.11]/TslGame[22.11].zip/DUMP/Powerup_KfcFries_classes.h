// BlueprintGeneratedClass Powerup_KfcFries.Powerup_KfcFries_C
// Size: 0x450 (Inherited: 0x440)
struct APowerup_KfcFries_C : APowerup_Base_C {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x440(0x08)
	struct F*b2f5f3e08e Timer2Handle; // 0x448(0x08)

	void UserConstructionScript(); // Function Powerup_KfcFries.Powerup_KfcFries_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void ReceiveBeginPlay(); // Function Powerup_KfcFries.Powerup_KfcFries_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x32e590
	void CustomEvent_1(); // Function Powerup_KfcFries.Powerup_KfcFries_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void ReceiveDestroyed(); // Function Powerup_KfcFries.Powerup_KfcFries_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x32e590
	void PlayAnim(); // Function Powerup_KfcFries.Powerup_KfcFries_C.PlayAnim // BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void ReceiveTick(); // Function Powerup_KfcFries.Powerup_KfcFries_C.ReceiveTick // Event|Public|BlueprintEvent // @ game+0x32e590
	void Drop(); // Function Powerup_KfcFries.Powerup_KfcFries_C.Drop // BlueprintCallable|BlueprintEvent // @ game+0x32e590
	struct F*b2f5f3e08e ExecuteUbergraph_Powerup_KfcFries(int32 EntryPoint, struct AActor* CallFunc__714237daa5_ReturnValue, bool K2Node_DynamicCast_bSuccess, struct UChar_AnimBP_C* K2Node_DynamicCast_AsChar_Anim_BP); // Function Powerup_KfcFries.Powerup_KfcFries_C.ExecuteUbergraph_Powerup_KfcFries // HasDefaults // @ game+0x32e590
};

