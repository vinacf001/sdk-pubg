// WidgetBlueprintGeneratedClass LobbyRotationRectWidget.LobbyRotationRectWidget_C
// Size: 0x420 (Inherited: 0x418)
struct ULobbyRotationRectWidget_C : U*bb33d4820c {
	struct UImage* RotationRect; // 0x418(0x08)
};

