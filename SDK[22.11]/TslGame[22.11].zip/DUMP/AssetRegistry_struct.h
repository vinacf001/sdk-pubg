// ScriptStruct AssetRegistry.AssetBundleData
// Size: 0x10 (Inherited: 0x00)
struct FAssetBundleData {
	struct TArray<struct F*3404531622> *b424cddc85; // 0x00(0x10)
};

// ScriptStruct AssetRegistry.*3404531622
// Size: 0x28 (Inherited: 0x00)
struct F*3404531622 {
	struct FPrimaryAssetId *7c29e8dc83; // 0x00(0x10)
	struct FName BundleName; // 0x10(0x08)
	struct TArray<struct FStringAssetReference> *296af77962; // 0x18(0x10)
};

