// WidgetBlueprintGeneratedClass KeyGuideWidgetBP.KeyGuideWidgetBP_C
// Size: 0x630 (Inherited: 0x590)
struct UKeyGuideWidgetBP_C : U*1780b3fcec {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x590(0x08)
	struct UBackgroundBlur* BackgroundBlur_1; // 0x598(0x08)
	struct U*46534bdc1f* ButtonBack; // 0x5a0(0x08)
	struct UKeyboardWidgetBP_C* KeyboardWidgetBP; // 0x5a8(0x08)
	struct UKeyGuideContentBP_C* KeyGuideContentBP; // 0x5b0(0x08)
	struct UKeyGuideContentBP_C* KeyGuideContentBP_7; // 0x5b8(0x08)
	struct UKeyGuideContentBP_C* KeyGuideContentBP_8; // 0x5c0(0x08)
	struct UKeyGuideContentBP_C* KeyGuideContentBP_9; // 0x5c8(0x08)
	struct UKeyGuideContentBP_C* KeyGuideContentBP_12; // 0x5d0(0x08)
	struct UKeyGuideContentBP_C* KeyGuideContentBP_13; // 0x5d8(0x08)
	struct UKeyGuideContentBP_C* KeyGuideContentBP_14; // 0x5e0(0x08)
	struct UKeyGuideContentBP_C* KeyGuideContentBP_15; // 0x5e8(0x08)
	struct UKeyGuideContentBP_C* KeyGuideContentBP_C_1; // 0x5f0(0x08)
	struct UKeyGuideContentBP_C* KeyGuideContentBP_C_2; // 0x5f8(0x08)
	struct UKeyGuideContentBP_C* KeyGuideContentBP_C_3; // 0x600(0x08)
	struct UKeyGuideContentBP_C* KeyGuideContentBP_C_7; // 0x608(0x08)
	struct UKeyGuideContentBP_C* KeyGuideContentBP_C_17; // 0x610(0x08)
	struct UKeyGuideTabWidget_C* KeyGuideTabWidget; // 0x618(0x08)
	struct UInvalidationBox* MainInvalidationBox; // 0x620(0x08)
	struct UMouseWidgetBP_C* MouseWidgetBP; // 0x628(0x08)

	void Construct(); // Function KeyGuideWidgetBP.KeyGuideWidgetBP_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x32e590
	void EscapeEvent(); // Function KeyGuideWidgetBP.KeyGuideWidgetBP_C.EscapeEvent // BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void BndEvt__TslCommonButton_0_K2Node_ComponentBoundEvent_20_OnButtonClickedEvent__DelegateSignature(); // Function KeyGuideWidgetBP.KeyGuideWidgetBP_C.BndEvt__TslCommonButton_0_K2Node_ComponentBoundEvent_20_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x32e590
	void BndEvt__TslCommonButton_0_K2Node_ComponentBoundEvent_37_OnButtonHoverEvent__DelegateSignature(); // Function KeyGuideWidgetBP.KeyGuideWidgetBP_C.BndEvt__TslCommonButton_0_K2Node_ComponentBoundEvent_37_OnButtonHoverEvent__DelegateSignature // BlueprintEvent // @ game+0x32e590
	struct APlayerController* ExecuteUbergraph_KeyGuideWidgetBP(DelegateProperty _d01ead63d9_OutputDelegate, struct ATslHUD* K2Node_DynamicCast_AsTsl_HUD); // Function KeyGuideWidgetBP.KeyGuideWidgetBP_C.ExecuteUbergraph_KeyGuideWidgetBP //  // @ game+0x32e590
};

