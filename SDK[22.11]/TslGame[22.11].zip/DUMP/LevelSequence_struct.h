// ScriptStruct LevelSequence.*4ea68bc3e5
// Size: 0x38 (Inherited: 0x00)
struct F*4ea68bc3e5 {
	struct UObject* *fb258a57a8; // 0x00(0x1c)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString ComponentName; // 0x20(0x10)
	struct UObject* *f6c58781e5; // 0x30(0x08)
};

// ScriptStruct LevelSequence.*b7de243b84
// Size: 0x50 (Inherited: 0x00)
struct F*b7de243b84 {
	struct TMap<struct FGuid, struct F*42424cd1b7> *ea5238412d; // 0x00(0x50)
};

// ScriptStruct LevelSequence.*42424cd1b7
// Size: 0x10 (Inherited: 0x00)
struct F*42424cd1b7 {
	struct TArray<struct F*1662c01469> References; // 0x00(0x10)
};

// ScriptStruct LevelSequence.*1662c01469
// Size: 0x20 (Inherited: 0x00)
struct F*1662c01469 {
	struct FString PackageName; // 0x00(0x10)
	struct FString ObjectPath; // 0x10(0x10)
};

// ScriptStruct LevelSequence.*fd68d45efc
// Size: 0x50 (Inherited: 0x00)
struct F*fd68d45efc {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct LevelSequence.*ad2985dee7
// Size: 0x20 (Inherited: 0x00)
struct F*ad2985dee7 {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct LevelSequence.*33ceb78436
// Size: 0x50 (Inherited: 0x00)
struct F*33ceb78436 {
	struct FText MasterName; // 0x00(0x18)
	float MasterTime; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FText CurrentShotName; // 0x20(0x18)
	float CurrentShotLocalTime; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct UCameraComponent* CameraComponent; // 0x40(0x08)
	struct F*0d017fb920 Settings; // 0x48(0x08)
};

// ScriptStruct LevelSequence.*0d017fb920
// Size: 0x08 (Inherited: 0x00)
struct F*0d017fb920 {
	bool ZeroPadAmount; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float FrameRate; // 0x04(0x04)
};

// ScriptStruct LevelSequence.*b40843bc3a
// Size: 0x01 (Inherited: 0x00)
struct F*b40843bc3a {
	char pad_0[0x1]; // 0x00(0x01)
};

