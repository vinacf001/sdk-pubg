// Class FacialAnimation.*1e4453e6ec
// Size: 0x770 (Inherited: 0x730)
struct U*1e4453e6ec : UAudioComponent {
	char pad_730[0x8]; // 0x730(0x08)
	struct FName CurveSourceBindingName; // 0x738(0x08)
	float CurveSyncOffset; // 0x740(0x04)
	char pad_744[0x2c]; // 0x744(0x2c)
};

