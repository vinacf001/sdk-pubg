// Class ClothingSystemRuntime.*9553a762fe
// Size: 0x28 (Inherited: 0x28)
struct U*9553a762fe : UObject {
};

// Class ClothingSystemRuntime.ClothingAsset
// Size: 0x158 (Inherited: 0x48)
struct UClothingAsset : U*00b0d3ce78 {
	struct F*b3b8f7e1f6 *b3b8f7e1f6; // 0x48(0xbc)
	char pad_104[0x4]; // 0x104(0x04)
	struct TArray<struct F*0a50355043> *db24bbedf0; // 0x108(0x10)
	struct TArray<int32> *e4d79f51c7; // 0x118(0x10)
	struct TArray<struct FName> *31ac041cbd; // 0x128(0x10)
	struct TArray<int32> *5bacc4851f; // 0x138(0x10)
	int32 *2326ef9ff1; // 0x148(0x04)
	char pad_14C[0x4]; // 0x14c(0x04)
	struct U*9553a762fe* CustomData; // 0x150(0x08)
};

// Class ClothingSystemRuntime.*8169aff6f9
// Size: 0x28 (Inherited: 0x28)
struct U*8169aff6f9 : U*41d1d8804c {
};

