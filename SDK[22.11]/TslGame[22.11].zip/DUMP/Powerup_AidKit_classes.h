// BlueprintGeneratedClass Powerup_AidKit.Powerup_AidKit_C
// Size: 0x450 (Inherited: 0x440)
struct APowerup_AidKit_C : APowerup_Base_C {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x440(0x08)
	struct F*b2f5f3e08e Timer2Handle; // 0x448(0x08)

	void UserConstructionScript(); // Function Powerup_AidKit.Powerup_AidKit_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void ReceiveBeginPlay(); // Function Powerup_AidKit.Powerup_AidKit_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x32e590
	void ReceiveDestroyed(); // Function Powerup_AidKit.Powerup_AidKit_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x32e590
	void CustomEvent_1(); // Function Powerup_AidKit.Powerup_AidKit_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x32e590
	int32 ExecuteUbergraph_Powerup_AidKit(struct F*b2f5f3e08e CallFunc__e67535aba8_ReturnValue, struct FName CallFunc__7e3cecea6d_ReturnValue); // Function Powerup_AidKit.Powerup_AidKit_C.ExecuteUbergraph_Powerup_AidKit // HasDefaults // @ game+0x32e590
};

