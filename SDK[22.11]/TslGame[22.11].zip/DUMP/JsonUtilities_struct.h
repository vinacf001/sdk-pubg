// ScriptStruct JsonUtilities.*f454bb9940
// Size: 0x20 (Inherited: 0x00)
struct F*f454bb9940 {
	struct FString *5a935a7367; // 0x00(0x10)
	char pad_10[0x10]; // 0x10(0x10)
};

