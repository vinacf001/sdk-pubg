// WidgetBlueprintGeneratedClass BP_DisplayOptionSliderWidget.BP_DisplayOptionSliderWidget_C
// Size: 0x890 (Inherited: 0x868)
struct UBP_DisplayOptionSliderWidget_C : U*78a1fc22ef {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x868(0x08)
	struct UProgressBar* BrightnessProgressBar; // 0x870(0x08)
	struct USlider* BrightnessSlider; // 0x878(0x08)
	struct UEditableText* BrightnessText; // 0x880(0x08)
	struct UProgressBar* NewVar_1; // 0x888(0x08)

	struct FGeometry Tick(); // Function BP_DisplayOptionSliderWidget.BP_DisplayOptionSliderWidget_C.Tick // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x32e590
	struct FGeometry ExecuteUbergraph_BP_DisplayOptionSliderWidget(); // Function BP_DisplayOptionSliderWidget.BP_DisplayOptionSliderWidget_C.ExecuteUbergraph_BP_DisplayOptionSliderWidget // HasDefaults // @ game+0x32e590
};

