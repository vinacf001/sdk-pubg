// BlueprintGeneratedClass JerryCan_Explosion.JerryCan_Explosion_C
// Size: 0x10f8 (Inherited: 0x10f8)
struct AJerryCan_Explosion_C : ATslExplosionEffect {
};

