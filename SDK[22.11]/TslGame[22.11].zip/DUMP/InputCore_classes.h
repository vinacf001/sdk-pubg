// Class InputCore.*b05cdb4c14
// Size: 0x28 (Inherited: 0x28)
struct U*b05cdb4c14 : UObject {
};

