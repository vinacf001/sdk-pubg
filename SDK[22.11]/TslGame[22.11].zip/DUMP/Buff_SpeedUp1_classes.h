// BlueprintGeneratedClass Buff_SpeedUp1.Buff_SpeedUp1_C
// Size: 0x484 (Inherited: 0x470)
struct ABuff_SpeedUp1_C : ATslBuff {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x470(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x478(0x08)
	float AddSpeedUpFactor; // 0x480(0x04)

	void UserConstructionScript(); // Function Buff_SpeedUp1.Buff_SpeedUp1_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x32e590
	void StartBuffBlueprint(); // Function Buff_SpeedUp1.Buff_SpeedUp1_C.StartBuffBlueprint // Event|Public|BlueprintEvent // @ game+0x32e590
	void StopBuffBlueprint(); // Function Buff_SpeedUp1.Buff_SpeedUp1_C.StopBuffBlueprint // Event|Public|BlueprintEvent // @ game+0x32e590
	float ExecuteUbergraph_Buff_SpeedUp1(struct APawn* CallFunc__1bfc7d352f_ReturnValue, bool K2Node_DynamicCast_bSuccess, bool K2Node_Event_bCanceled, struct ATslCharacter* K2Node_DynamicCast_AsTsl_Character2); // Function Buff_SpeedUp1.Buff_SpeedUp1_C.ExecuteUbergraph_Buff_SpeedUp1 //  // @ game+0x32e590
};

