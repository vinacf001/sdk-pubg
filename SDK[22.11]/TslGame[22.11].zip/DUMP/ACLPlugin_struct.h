// Enum ACLPlugin.*ad2370af80
enum class *ad2370af80 : uint8 {
	*ac9dec7e12,
	*74a011789e,
	*40b617e9b8,
	*71a4baae75,
	*cb63574533,
	*b90dd30e0a,
	*ad2370af80_MAX,
};

// Enum ACLPlugin.*c29c2f4c4a
enum class *c29c2f4c4a : uint8 {
	*0390b20e6c,
	*ee7a59b54d,
	*aca2a60fce,
	*c29c2f4c4a_MAX,
};

// Enum ACLPlugin.*d6ed136a11
enum class *d6ed136a11 : uint8 {
	*67e3e3608d,
	*d3aa9f2125,
	*6cc0155faf,
	*ccac99ec75,
	*d6ed136a11_MAX,
};

