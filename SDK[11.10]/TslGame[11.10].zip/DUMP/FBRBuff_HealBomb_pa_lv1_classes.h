// BlueprintGeneratedClass FBRBuff_HealBomb_pa_lv1.FBRBuff_HealBomb_pa_lv1_C
// Size: 0x4d8 (Inherited: 0x4d0)
struct AFBRBuff_HealBomb_pa_lv1_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4d0(0x08)

	void UserConstructionScript(); // Function FBRBuff_HealBomb_pa_lv1.FBRBuff_HealBomb_pa_lv1_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

