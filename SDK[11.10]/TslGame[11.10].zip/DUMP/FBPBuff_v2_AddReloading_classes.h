// BlueprintGeneratedClass FBPBuff_v2_AddReloading.FBPBuff_v2_AddReloading_C
// Size: 0x4b8 (Inherited: 0x4b0)
struct AFBPBuff_v2_AddReloading_C : ATslFBRBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4b0(0x08)

	void UserConstructionScript(); // Function FBPBuff_v2_AddReloading.FBPBuff_v2_AddReloading_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

