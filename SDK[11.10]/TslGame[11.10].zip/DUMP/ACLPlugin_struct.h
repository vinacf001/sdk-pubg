// Enum ACLPlugin.*64d1ea9ef9
enum class *64d1ea9ef9 : uint8 {
	*ec6fcd854b,
	*efe3aef945,
	*888404962c,
	*417bd121b6,
	*7ed77ec8e9,
	*7fb36d14b8,
	*64d1ea9ef9_MAX,
};

// Enum ACLPlugin.*9b7e97d129
enum class *9b7e97d129 : uint8 {
	*3657ec7489,
	*69409f6a92,
	*78f51814c0,
	*9b7e97d129_MAX,
};

// Enum ACLPlugin.*a955d4225e
enum class *a955d4225e : uint8 {
	*cf2775ddb9,
	*5bed603962,
	*8eaa9a99b7,
	*10b68e34f6,
	*a955d4225e_MAX,
};

