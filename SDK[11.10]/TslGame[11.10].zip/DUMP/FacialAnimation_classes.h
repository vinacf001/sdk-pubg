// Class FacialAnimation.*e773cb3a40
// Size: 0x7f0 (Inherited: 0x7b0)
struct U*e773cb3a40 : UAudioComponent {
	char pad_7B0[0x8]; // 0x7b0(0x08)
	struct FName CurveSourceBindingName; // 0x7b8(0x08)
	float CurveSyncOffset; // 0x7c0(0x04)
	char pad_7C4[0x2c]; // 0x7c4(0x2c)
};

