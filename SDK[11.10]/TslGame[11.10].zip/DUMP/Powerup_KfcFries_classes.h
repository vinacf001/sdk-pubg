// BlueprintGeneratedClass Powerup_KfcFries.Powerup_KfcFries_C
// Size: 0x468 (Inherited: 0x458)
struct APowerup_KfcFries_C : APowerup_Base_C {
	struct F*abc8f374e0 UberGraphFrame; // 0x458(0x08)
	struct F*da672abddc Timer2Handle; // 0x460(0x08)

	void UserConstructionScript(); // Function Powerup_KfcFries.Powerup_KfcFries_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
	void ReceiveBeginPlay(); // Function Powerup_KfcFries.Powerup_KfcFries_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x273e04
	void CustomEvent_1(); // Function Powerup_KfcFries.Powerup_KfcFries_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x273e04
	void ReceiveDestroyed(); // Function Powerup_KfcFries.Powerup_KfcFries_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x273e04
	struct ATslCharacter* PlayAnim(); // Function Powerup_KfcFries.Powerup_KfcFries_C.PlayAnim // BlueprintCallable|BlueprintEvent // @ game+0x273e04
	float ReceiveTick(); // Function Powerup_KfcFries.Powerup_KfcFries_C.ReceiveTick // Event|Public|BlueprintEvent // @ game+0x273e04
	void Drop(); // Function Powerup_KfcFries.Powerup_KfcFries_C.Drop // BlueprintCallable|BlueprintEvent // @ game+0x273e04
	bool ExecuteUbergraph_Powerup_KfcFries(); // Function Powerup_KfcFries.Powerup_KfcFries_C.ExecuteUbergraph_Powerup_KfcFries // HasDefaults // @ game+0x273e04
};

