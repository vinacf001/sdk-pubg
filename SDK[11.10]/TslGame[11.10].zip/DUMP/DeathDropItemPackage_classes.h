// BlueprintGeneratedClass DeathDropItemPackage.DeathDropItemPackage_C
// Size: 0x620 (Inherited: 0x618)
struct ADeathDropItemPackage_C : AFloorSnapItemPackage {
	struct F*abc8f374e0 UberGraphFrame; // 0x618(0x08)

	struct FText GetCategory(); // Function DeathDropItemPackage.DeathDropItemPackage_C.GetCategory // Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x273e04
	void UserConstructionScript(); // Function DeathDropItemPackage.DeathDropItemPackage_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
	void ReceiveBeginPlay(); // Function DeathDropItemPackage.DeathDropItemPackage_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x273e04
	struct FText ExecuteUbergraph_DeathDropItemPackage(); // Function DeathDropItemPackage.DeathDropItemPackage_C.ExecuteUbergraph_DeathDropItemPackage // HasDefaults // @ game+0x273e04
};

