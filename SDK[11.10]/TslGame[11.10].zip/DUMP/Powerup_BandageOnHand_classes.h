// BlueprintGeneratedClass Powerup_BandageOnHand.Powerup_BandageOnHand_C
// Size: 0x458 (Inherited: 0x458)
struct APowerup_BandageOnHand_C : APowerup_Base_C {
};

