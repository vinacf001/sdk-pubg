// WidgetBlueprintGeneratedClass BP_KillLogVictimButton.BP_KillLogVictimButton_C
// Size: 0x708 (Inherited: 0x6f8)
struct UBP_KillLogVictimButton_C : U*44ac9ae1d3 {
	struct F*abc8f374e0 UberGraphFrame; // 0x6f8(0x08)
	struct UButton* Button_1; // 0x700(0x08)

	void BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function BP_KillLogVictimButton.BP_KillLogVictimButton_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x273e04
	int32 ExecuteUbergraph_BP_KillLogVictimButton(); // Function BP_KillLogVictimButton.BP_KillLogVictimButton_C.ExecuteUbergraph_BP_KillLogVictimButton //  // @ game+0x273e04
};

