// BlueprintGeneratedClass FBRBuff_Medikit_pa_lv4.FBRBuff_Medikit_pa_lv4_C
// Size: 0x4d8 (Inherited: 0x4d0)
struct AFBRBuff_Medikit_pa_lv4_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4d0(0x08)

	void UserConstructionScript(); // Function FBRBuff_Medikit_pa_lv4.FBRBuff_Medikit_pa_lv4_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

