// BlueprintGeneratedClass LaserPointerAttachment.LaserPointerAttachment_C
// Size: 0xcb0 (Inherited: 0xcb0)
struct ULaserPointerAttachment_C : U*f8454b8f33 {
};

