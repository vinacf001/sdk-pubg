// BlueprintGeneratedClass FBRBuff2021_Item_Bolt_ra_lv3.FBRBuff2021_Item_Bolt_ra_lv3_C
// Size: 0x4d8 (Inherited: 0x4d0)
struct AFBRBuff2021_Item_Bolt_ra_lv3_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4d0(0x08)

	void UserConstructionScript(); // Function FBRBuff2021_Item_Bolt_ra_lv3.FBRBuff2021_Item_Bolt_ra_lv3_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

