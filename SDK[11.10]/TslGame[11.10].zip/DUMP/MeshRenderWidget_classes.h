// WidgetBlueprintGeneratedClass MeshRenderWidget.MeshRenderWidget_C
// Size: 0x268 (Inherited: 0x258)
struct UMeshRenderWidget_C : UUserWidget {
	struct F*abc8f374e0 UberGraphFrame; // 0x258(0x08)
	struct UImage* MeshRenderImage; // 0x260(0x08)

	void Construct(); // Function MeshRenderWidget.MeshRenderWidget_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x273e04
	struct UMaterialInstanceDynamic* ExecuteUbergraph_MeshRenderWidget(); // Function MeshRenderWidget.MeshRenderWidget_C.ExecuteUbergraph_MeshRenderWidget //  // @ game+0x273e04
};

