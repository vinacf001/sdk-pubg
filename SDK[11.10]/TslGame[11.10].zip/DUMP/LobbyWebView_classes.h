// WidgetBlueprintGeneratedClass LobbyWebView.LobbyWebView_C
// Size: 0x440 (Inherited: 0x438)
struct ULobbyWebView_C : U*2b93ea56e7 {
	struct ULobbyRotationRectWidget_C* RotationRect; // 0x438(0x08)

	struct FString OnKeyUp(); // Function LobbyWebView.LobbyWebView_C.OnKeyUp // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x273e04
	struct FString OnKeyDown(); // Function LobbyWebView.LobbyWebView_C.OnKeyDown // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x273e04
	struct FString OnPreviewMouseButtonDown(); // Function LobbyWebView.LobbyWebView_C.OnPreviewMouseButtonDown // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x273e04
	struct U*9f227672ef* GetMainCoherentWidget(); // Function LobbyWebView.LobbyWebView_C.GetMainCoherentWidget // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const // @ game+0x273e04
	struct FString OnPreviewKeyDown(); // Function LobbyWebView.LobbyWebView_C.OnPreviewKeyDown // Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

