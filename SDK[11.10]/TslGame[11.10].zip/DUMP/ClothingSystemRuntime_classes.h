// Class ClothingSystemRuntime.*81a85dc7ae
// Size: 0x30 (Inherited: 0x30)
struct U*81a85dc7ae : UObject {
};

// Class ClothingSystemRuntime.ClothingAsset
// Size: 0x160 (Inherited: 0x50)
struct UClothingAsset : U*ac42304f2a {
	struct F*3b13593114 *3b13593114; // 0x50(0xbc)
	char pad_10C[0x4]; // 0x10c(0x04)
	struct TArray<struct F*2643f3aca7> *a09dd6c691; // 0x110(0x10)
	struct TArray<int32> *38207f2b95; // 0x120(0x10)
	struct TArray<struct FName> *39c466bccc; // 0x130(0x10)
	struct TArray<int32> *74308bc425; // 0x140(0x10)
	int32 *7f9991c46f; // 0x150(0x04)
	char pad_154[0x4]; // 0x154(0x04)
	struct U*81a85dc7ae* CustomData; // 0x158(0x08)
};

// Class ClothingSystemRuntime.*669c3e725f
// Size: 0x30 (Inherited: 0x30)
struct U*669c3e725f : U*aefcf253a9 {
};

