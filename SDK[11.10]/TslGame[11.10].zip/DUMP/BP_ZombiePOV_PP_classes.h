// BlueprintGeneratedClass BP_ZombiePOV_PP.BP_ZombiePOV_PP_C
// Size: 0x490 (Inherited: 0x488)
struct ABP_ZombiePOV_PP_C : ATslPostProcessEffect {
	struct USceneComponent* DefaultSceneRoot; // 0x488(0x08)

	void UserConstructionScript(); // Function BP_ZombiePOV_PP.BP_ZombiePOV_PP_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

