// BlueprintGeneratedClass BP_UnderwaterBulletTrailEffectShort.BP_UnderwaterBulletTrailEffectShort_C
// Size: 0x520 (Inherited: 0x520)
struct ABP_UnderwaterBulletTrailEffectShort_C : ATslParticleBulletTrail {
};

