// BlueprintGeneratedClass LobbyVehicleSequenceActor.LobbyVehicleSequenceActor_C
// Size: 0x4d0 (Inherited: 0x4d0)
struct ALobbyVehicleSequenceActor_C : ATslLobbyLevelVehicleSequenceActor {
};

