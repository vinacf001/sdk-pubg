// BlueprintGeneratedClass Powerup_Bandage.Powerup_Bandage_C
// Size: 0x458 (Inherited: 0x458)
struct APowerup_Bandage_C : APowerup_Base_C {
};

