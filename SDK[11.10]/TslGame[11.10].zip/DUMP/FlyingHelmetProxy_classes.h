// BlueprintGeneratedClass FlyingHelmetProxy.FlyingHelmetProxy_C
// Size: 0x5b8 (Inherited: 0x5b8)
struct AFlyingHelmetProxy_C : ATslFlyingHelmetProxy {
};

