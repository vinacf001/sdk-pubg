// WidgetBlueprintGeneratedClass MouseWidgetBP.MouseWidgetBP_C
// Size: 0x470 (Inherited: 0x470)
struct UMouseWidgetBP_C : U*5975ef1fd6 {
};

