// BlueprintGeneratedClass DBX_RibbonWheel_BL.DBX_RibbonWheel_BL_C
// Size: 0x3b0 (Inherited: 0x3b0)
struct UDBX_RibbonWheel_BL_C : UDBX_RibbonWheel_C {
};

