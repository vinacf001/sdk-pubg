// BlueprintGeneratedClass BP_DronePackage_Projectile.BP_DronePackage_Projectile_C
// Size: 0x7e0 (Inherited: 0x7e0)
struct ABP_DronePackage_Projectile_C : ATslProjectile_DroppedItem {
};

