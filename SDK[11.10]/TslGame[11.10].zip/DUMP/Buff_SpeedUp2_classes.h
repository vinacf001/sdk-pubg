// BlueprintGeneratedClass Buff_SpeedUp2.Buff_SpeedUp2_C
// Size: 0x49c (Inherited: 0x488)
struct ABuff_SpeedUp2_C : ATslBuff {
	struct F*abc8f374e0 UberGraphFrame; // 0x488(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x490(0x08)
	float AddSpeedUpFactor; // 0x498(0x04)

	void UserConstructionScript(); // Function Buff_SpeedUp2.Buff_SpeedUp2_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
	void StartBuffBlueprint(); // Function Buff_SpeedUp2.Buff_SpeedUp2_C.StartBuffBlueprint // Event|Public|BlueprintEvent // @ game+0x273e04
	bool StopBuffBlueprint(); // Function Buff_SpeedUp2.Buff_SpeedUp2_C.StopBuffBlueprint // Event|Public|BlueprintEvent // @ game+0x273e04
	struct ATslPlayerController* ExecuteUbergraph_Buff_SpeedUp2(); // Function Buff_SpeedUp2.Buff_SpeedUp2_C.ExecuteUbergraph_Buff_SpeedUp2 //  // @ game+0x273e04
};

