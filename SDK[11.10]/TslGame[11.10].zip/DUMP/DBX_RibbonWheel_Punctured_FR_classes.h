// BlueprintGeneratedClass DBX_RibbonWheel_Punctured_FR.DBX_RibbonWheel_Punctured_FR_C
// Size: 0x3b0 (Inherited: 0x3b0)
struct UDBX_RibbonWheel_Punctured_FR_C : UDBX_RibbonWheel_Punctured_FL_C {
};

