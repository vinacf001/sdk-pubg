// WidgetBlueprintGeneratedClass BP_PcOptionItemSliderWidget.BP_PcOptionItemSliderWidget_C
// Size: 0x878 (Inherited: 0x870)
struct UBP_PcOptionItemSliderWidget_C : U*09cb64dd50 {
	struct USizeBox* IndentationSizeBox; // 0x870(0x08)
};

