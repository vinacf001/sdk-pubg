// BlueprintGeneratedClass BP_MasteryPose_PanDeflect.BP_MasteryPose_PanDeflect_C
// Size: 0x4b0 (Inherited: 0x450)
struct ABP_MasteryPose_PanDeflect_C : ABP_MasteryPose_C {
	struct F*abc8f374e0 UberGraphFrame; // 0x450(0x08)
	struct UAsyncStaticMeshComponent* AsyncStaticMesh3; // 0x458(0x08)
	struct UAsyncStaticMeshComponent* AsyncStaticMesh2; // 0x460(0x08)
	struct UAsyncStaticMeshComponent* PlayerCardPanEffects; // 0x468(0x08)
	struct UAsyncStaticMeshComponent* AsyncStaticMesh; // 0x470(0x08)
	struct U*13053458a7* Pan; // 0x478(0x08)
	struct USpotLightComponent* SpotLightEyes; // 0x480(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x488(0x08)
	struct USpotLightComponent* PlayerCardBulletLight; // 0x490(0x08)
	struct USpotLightComponent* BulletLight; // 0x498(0x08)
	struct USpotLightComponent* LobbySpotLight; // 0x4a0(0x08)
	struct USpotLightComponent* spotlight; // 0x4a8(0x08)

	void UserConstructionScript(); // Function BP_MasteryPose_PanDeflect.BP_MasteryPose_PanDeflect_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
	void ReceiveBeginPlay(); // Function BP_MasteryPose_PanDeflect.BP_MasteryPose_PanDeflect_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x273e04
	int32 ExecuteUbergraph_BP_MasteryPose_PanDeflect(); // Function BP_MasteryPose_PanDeflect.BP_MasteryPose_PanDeflect_C.ExecuteUbergraph_BP_MasteryPose_PanDeflect //  // @ game+0x273e04
};

