// BlueprintGeneratedClass DmgType_Bear.DmgType_Bear_C
// Size: 0x100 (Inherited: 0x100)
struct UDmgType_Bear_C : UTslDamageType {
};

