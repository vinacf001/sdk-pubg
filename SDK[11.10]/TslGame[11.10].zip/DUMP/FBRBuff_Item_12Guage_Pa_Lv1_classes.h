// BlueprintGeneratedClass FBRBuff_Item_12Guage_Pa_Lv1.FBRBuff_Item_12Guage_Pa_Lv1_C
// Size: 0x4d8 (Inherited: 0x4d0)
struct AFBRBuff_Item_12Guage_Pa_Lv1_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4d0(0x08)

	void UserConstructionScript(); // Function FBRBuff_Item_12Guage_Pa_Lv1.FBRBuff_Item_12Guage_Pa_Lv1_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

