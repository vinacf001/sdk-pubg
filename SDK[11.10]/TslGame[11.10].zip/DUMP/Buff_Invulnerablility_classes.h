// BlueprintGeneratedClass Buff_Invulnerablility.Buff_Invulnerablility_C
// Size: 0x490 (Inherited: 0x488)
struct ABuff_Invulnerablility_C : ATslBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x488(0x08)

	void UserConstructionScript(); // Function Buff_Invulnerablility.Buff_Invulnerablility_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

