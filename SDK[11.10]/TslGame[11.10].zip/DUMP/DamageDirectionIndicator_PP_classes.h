// BlueprintGeneratedClass DamageDirectionIndicator_PP.DamageDirectionIndicator_PP_C
// Size: 0x498 (Inherited: 0x488)
struct ADamageDirectionIndicator_PP_C : ATslPostProcessEffect {
	struct F*abc8f374e0 UberGraphFrame; // 0x488(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x490(0x08)

	void UserConstructionScript(); // Function DamageDirectionIndicator_PP.DamageDirectionIndicator_PP_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
	int32 ExecuteUbergraph_DamageDirectionIndicator_PP(); // Function DamageDirectionIndicator_PP.DamageDirectionIndicator_PP_C.ExecuteUbergraph_DamageDirectionIndicator_PP //  // @ game+0x273e04
};

