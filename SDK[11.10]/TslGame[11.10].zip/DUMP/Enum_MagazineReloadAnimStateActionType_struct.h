// UserDefinedEnum Enum_MagazineReloadAnimStateActionType.Enum_MagazineReloadAnimStateActionType
enum class Enum_MagazineReloadAnimStateActionType : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	NewEnumerator3,
	NewEnumerator4,
	NewEnumerator5,
	Enum_MAX,
};

