// WidgetBlueprintGeneratedClass McLarenGTStanceWidget.McLarenGTStanceWidget_C
// Size: 0x518 (Inherited: 0x4f0)
struct UMcLarenGTStanceWidget_C : U*38088d1ea0 {
	struct UImage* McLarenGTImage; // 0x4f0(0x08)
	struct UVehicleWheelInfoWidget_C* VehicleTireSeatInfoWidget_FL; // 0x4f8(0x08)
	struct UVehicleWheelInfoWidget_C* VehicleTireSeatInfoWidget_FR; // 0x500(0x08)
	struct UVehicleWheelInfoWidget_C* VehicleTireSeatInfoWidget_RL; // 0x508(0x08)
	struct UVehicleWheelInfoWidget_C* VehicleTireSeatInfoWidget_RR; // 0x510(0x08)
};

