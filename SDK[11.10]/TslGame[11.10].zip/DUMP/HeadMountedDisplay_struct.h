// Enum HeadMountedDisplay.ETrackingStatus
enum class ETrackingStatus : uint8 {
	NotTracked,
	InertialOnly,
	Tracked,
	ETrackingStatus_MAX,
};

