// BlueprintGeneratedClass BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C
// Size: 0x698 (Inherited: 0x690)
struct ABP_TslBaseLobbySceneTravel_FadeInOut_C : ATslLobbySceneTravel_FadeInOut {
	struct USceneComponent* DefaultSceneRoot; // 0x690(0x08)

	void UserConstructionScript(); // Function BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

