// BlueprintGeneratedClass FBRBuff_ReduceMeleeDamageRatio.FBRBuff_ReduceMeleeDamageRatio_C
// Size: 0x4b8 (Inherited: 0x4b0)
struct AFBRBuff_ReduceMeleeDamageRatio_C : ATslFBRBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4b0(0x08)

	void UserConstructionScript(); // Function FBRBuff_ReduceMeleeDamageRatio.FBRBuff_ReduceMeleeDamageRatio_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

