// BlueprintGeneratedClass CS_WeapGun_Sniper_762_Kar98_Ironsight.CS_WeapGun_Sniper_762_Kar98_Ironsight_C
// Size: 0x170 (Inherited: 0x170)
struct UCS_WeapGun_Sniper_762_Kar98_Ironsight_C : UCameraShake {
};

