// BlueprintGeneratedClass BP_TslBaseLobbySceneTravel_CameraMove_Fast.BP_TslBaseLobbySceneTravel_CameraMove_Fast_C
// Size: 0x598 (Inherited: 0x590)
struct ABP_TslBaseLobbySceneTravel_CameraMove_Fast_C : ATslLobbySceneTravel_CameraMove {
	struct USceneComponent* DefaultSceneRoot; // 0x590(0x08)

	void UserConstructionScript(); // Function BP_TslBaseLobbySceneTravel_CameraMove_Fast.BP_TslBaseLobbySceneTravel_CameraMove_Fast_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

