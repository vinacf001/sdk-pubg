// BlueprintGeneratedClass DmgTypeExplosion_JerryCan.DmgTypeExplosion_JerryCan_C
// Size: 0x100 (Inherited: 0x100)
struct UDmgTypeExplosion_JerryCan_C : UTslDamageType {
};

