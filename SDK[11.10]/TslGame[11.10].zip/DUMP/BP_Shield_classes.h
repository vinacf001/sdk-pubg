// BlueprintGeneratedClass BP_Shield.BP_Shield_C
// Size: 0x418 (Inherited: 0x400)
struct ABP_Shield_C : AActor {
	struct UStaticMeshComponent* DecalMesh; // 0x400(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x408(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x410(0x08)

	void UserConstructionScript(); // Function BP_Shield.BP_Shield_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

