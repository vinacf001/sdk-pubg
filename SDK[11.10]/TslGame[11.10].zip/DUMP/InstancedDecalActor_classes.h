// BlueprintGeneratedClass InstancedDecalActor.InstancedDecalActor_C
// Size: 0x408 (Inherited: 0x408)
struct AInstancedDecalActor_C : ADecalActor {
};

