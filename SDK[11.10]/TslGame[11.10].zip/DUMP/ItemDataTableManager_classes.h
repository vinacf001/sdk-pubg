// BlueprintGeneratedClass ItemDataTableManager.ItemDataTableManager_C
// Size: 0x4f0 (Inherited: 0x4f0)
struct UItemDataTableManager_C : U*dd1f3b3b61 {
};

