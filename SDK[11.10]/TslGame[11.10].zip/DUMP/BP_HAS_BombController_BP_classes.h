// BlueprintGeneratedClass BP_HAS_BombController_BP.BP_HAS_BombController_BP_C
// Size: 0x490 (Inherited: 0x490)
struct ABP_HAS_BombController_BP_C : ATslAnimSpawnSkeletalObject {
};

