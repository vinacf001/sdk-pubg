// WidgetBlueprintGeneratedClass BP_PcSystemMenuButtonWidget.BP_PcSystemMenuButtonWidget_C
// Size: 0x4e8 (Inherited: 0x4c8)
struct UBP_PcSystemMenuButtonWidget_C : U*eab8a75440 {
	struct F*abc8f374e0 UberGraphFrame; // 0x4c8(0x08)
	struct UTextBlock* ButtonText; // 0x4d0(0x08)
	struct FMulticastDelegate OnClicked; // 0x4d8(0x10)

	bool PreConstruct(); // Function BP_PcSystemMenuButtonWidget.BP_PcSystemMenuButtonWidget_C.PreConstruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x273e04
	void BndEvt__Button_Internal_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function BP_PcSystemMenuButtonWidget.BP_PcSystemMenuButtonWidget_C.BndEvt__Button_Internal_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x273e04
	bool ExecuteUbergraph_BP_PcSystemMenuButtonWidget(); // Function BP_PcSystemMenuButtonWidget.BP_PcSystemMenuButtonWidget_C.ExecuteUbergraph_BP_PcSystemMenuButtonWidget //  // @ game+0x273e04
	void OnClicked__DelegateSignature(); // Function BP_PcSystemMenuButtonWidget.BP_PcSystemMenuButtonWidget_C.OnClicked__DelegateSignature // Public|Delegate|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

