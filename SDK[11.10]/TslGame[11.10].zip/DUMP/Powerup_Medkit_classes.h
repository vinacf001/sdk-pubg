// BlueprintGeneratedClass Powerup_Medkit.Powerup_Medkit_C
// Size: 0x458 (Inherited: 0x458)
struct APowerup_Medkit_C : APowerup_Base_C {
};

