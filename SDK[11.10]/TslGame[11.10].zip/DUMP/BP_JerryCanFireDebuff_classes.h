// BlueprintGeneratedClass BP_JerryCanFireDebuff.BP_JerryCanFireDebuff_C
// Size: 0x4c8 (Inherited: 0x4c0)
struct ABP_JerryCanFireDebuff_C : ATslMolotovFireDebuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4c0(0x08)

	void UserConstructionScript(); // Function BP_JerryCanFireDebuff.BP_JerryCanFireDebuff_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

