// BlueprintGeneratedClass BP_LobbyCharacterPivot.BP_LobbyCharacterPivot_C
// Size: 0x428 (Inherited: 0x420)
struct ABP_LobbyCharacterPivot_C : ALobbyCharacterPivot {
	struct USceneComponent* DefaultSceneRoot; // 0x420(0x08)

	void UserConstructionScript(); // Function BP_LobbyCharacterPivot.BP_LobbyCharacterPivot_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

