// WidgetBlueprintGeneratedClass LobbyCustomizeSpinnerWidget.LobbyCustomizeSpinnerWidget_C
// Size: 0x430 (Inherited: 0x428)
struct ULobbyCustomizeSpinnerWidget_C : U*7fa455d9e8 {
	struct UImage* LoadingSpinnerImage; // 0x428(0x08)
};

