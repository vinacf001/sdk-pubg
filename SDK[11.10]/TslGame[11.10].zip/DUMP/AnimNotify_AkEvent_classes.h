// BlueprintGeneratedClass AnimNotify_AkEvent.AnimNotify_AkEvent_C
// Size: 0x68 (Inherited: 0x68)
struct UAnimNotify_AkEvent_C : UAnimNotify_AkEvent {
};

