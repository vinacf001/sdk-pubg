// BlueprintGeneratedClass Powerup_AidKit.Powerup_AidKit_C
// Size: 0x468 (Inherited: 0x458)
struct APowerup_AidKit_C : APowerup_Base_C {
	struct F*abc8f374e0 UberGraphFrame; // 0x458(0x08)
	struct F*da672abddc Timer2Handle; // 0x460(0x08)

	void UserConstructionScript(); // Function Powerup_AidKit.Powerup_AidKit_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
	void ReceiveBeginPlay(); // Function Powerup_AidKit.Powerup_AidKit_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x273e04
	void ReceiveDestroyed(); // Function Powerup_AidKit.Powerup_AidKit_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x273e04
	void CustomEvent_1(); // Function Powerup_AidKit.Powerup_AidKit_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x273e04
	bool ExecuteUbergraph_Powerup_AidKit(); // Function Powerup_AidKit.Powerup_AidKit_C.ExecuteUbergraph_Powerup_AidKit // HasDefaults // @ game+0x273e04
};

