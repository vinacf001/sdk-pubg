// BlueprintGeneratedClass LobbyCharacterBase_v2.LobbyCharacterBase_v2_C
// Size: 0xdf0 (Inherited: 0xdf0)
struct ALobbyCharacterBase_v2_C : ALobbyCharacter {
};

