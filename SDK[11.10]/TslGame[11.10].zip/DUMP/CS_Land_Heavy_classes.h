// BlueprintGeneratedClass CS_Land_Heavy.CS_Land_Heavy_C
// Size: 0x170 (Inherited: 0x170)
struct UCS_Land_Heavy_C : UCameraShake {
};

