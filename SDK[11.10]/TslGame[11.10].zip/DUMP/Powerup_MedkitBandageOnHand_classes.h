// BlueprintGeneratedClass Powerup_MedkitBandageOnHand.Powerup_MedkitBandageOnHand_C
// Size: 0x458 (Inherited: 0x458)
struct APowerup_MedkitBandageOnHand_C : APowerup_Base_C {
};

