// BlueprintGeneratedClass M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C
// Size: 0x4a8 (Inherited: 0x488)
struct AM_ElectricWall_Inside_BP_C : ATslPostProcessEffect {
	struct F*abc8f374e0 UberGraphFrame; // 0x488(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x490(0x08)
	float _____0______0_F1196C2844F052526643A091F7753F02; // 0x498(0x04)
	enum class ETimelineDirection _____0__Direction_F1196C2844F052526643A091F7753F02; // 0x49c(0x01)
	char pad_49D[0x3]; // 0x49d(0x03)
	struct UTimelineComponent* �Є�|�x�_1; // 0x4a0(0x08)

	void UserConstructionScript(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
	void �Є�|�x�_(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.�Є�|�x�_ // BlueprintEvent // @ game+0x273e04
	void �Є�|�x�_(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.�Є�|�x�_ // BlueprintEvent // @ game+0x273e04
	void ReceiveBeginPlay(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x273e04
	void Custom Event_1(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.Custom Event_1 // BlueprintCallable|BlueprintEvent // @ game+0x273e04
	float OnSetEffectParameter(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.OnSetEffectParameter // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x273e04
	bool ExecuteUbergraph_M_ElectricWall_Inside_BP(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.ExecuteUbergraph_M_ElectricWall_Inside_BP // HasDefaults // @ game+0x273e04
};

