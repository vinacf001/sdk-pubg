// BlueprintGeneratedClass FBRBuff_v2_HealBomb_pa_lv2.FBRBuff_v2_HealBomb_pa_lv2_C
// Size: 0x4d8 (Inherited: 0x4d0)
struct AFBRBuff_v2_HealBomb_pa_lv2_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4d0(0x08)

	void UserConstructionScript(); // Function FBRBuff_v2_HealBomb_pa_lv2.FBRBuff_v2_HealBomb_pa_lv2_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

