// Class PacketHandler.*662c187ec2
// Size: 0x30 (Inherited: 0x30)
struct U*662c187ec2 : UObject {
};

