// WidgetBlueprintGeneratedClass BP_PcOptionSupplementaryPreviewMaterialWidget.BP_PcOptionSupplementaryPreviewMaterialWidget_C
// Size: 0x4a0 (Inherited: 0x4a0)
struct UBP_PcOptionSupplementaryPreviewMaterialWidget_C : U*8644017778 {
};

