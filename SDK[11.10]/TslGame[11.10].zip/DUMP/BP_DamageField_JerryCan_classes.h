// BlueprintGeneratedClass BP_DamageField_JerryCan.BP_DamageField_JerryCan_C
// Size: 0x4a8 (Inherited: 0x4a8)
struct ABP_DamageField_JerryCan_C : ATslDamageField {

	bool UserConstructionScript(); // Function BP_DamageField_JerryCan.BP_DamageField_JerryCan_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

