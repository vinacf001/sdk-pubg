// BlueprintGeneratedClass FBRBuff_Flare_wi_lv4.FBRBuff_Flare_wi_lv4_C
// Size: 0x4d8 (Inherited: 0x4d0)
struct AFBRBuff_Flare_wi_lv4_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4d0(0x08)

	void UserConstructionScript(); // Function FBRBuff_Flare_wi_lv4.FBRBuff_Flare_wi_lv4_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

