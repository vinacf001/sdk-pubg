// BlueprintGeneratedClass BP_DirectMessageManager.BP_DirectMessageManager_C
// Size: 0x240 (Inherited: 0x240)
struct UBP_DirectMessageManager_C : U*9b350e291f {
};

