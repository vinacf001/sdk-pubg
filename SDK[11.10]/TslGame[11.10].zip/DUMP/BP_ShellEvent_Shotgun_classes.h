// BlueprintGeneratedClass BP_ShellEvent_Shotgun.BP_ShellEvent_Shotgun_C
// Size: 0x90 (Inherited: 0x90)
struct UBP_ShellEvent_Shotgun_C : U*c9c8e931e8 {
};

