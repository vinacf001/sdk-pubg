// BlueprintGeneratedClass BP_UnderwaterBulletTrailEffectMid.BP_UnderwaterBulletTrailEffectMid_C
// Size: 0x520 (Inherited: 0x520)
struct ABP_UnderwaterBulletTrailEffectMid_C : ATslParticleBulletTrail {
};

