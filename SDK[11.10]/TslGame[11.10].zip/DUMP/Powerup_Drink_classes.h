// BlueprintGeneratedClass Powerup_Drink.Powerup_Drink_C
// Size: 0x460 (Inherited: 0x458)
struct APowerup_Drink_C : APowerup_Base_C {
	struct F*abc8f374e0 UberGraphFrame; // 0x458(0x08)

	void UserConstructionScript(); // Function Powerup_Drink.Powerup_Drink_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
	void ReceiveBeginPlay(); // Function Powerup_Drink.Powerup_Drink_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x273e04
	int32 ExecuteUbergraph_Powerup_Drink(); // Function Powerup_Drink.Powerup_Drink_C.ExecuteUbergraph_Powerup_Drink //  // @ game+0x273e04
};

