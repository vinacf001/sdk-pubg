// BlueprintGeneratedClass Powerup_PutFuel.Powerup_PutFuel_C
// Size: 0x458 (Inherited: 0x458)
struct APowerup_PutFuel_C : APowerup_Base_C {
};

