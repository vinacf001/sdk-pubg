// BlueprintGeneratedClass BP_PP_OutlineCustomDepthOcclusion_Inst.BP_PP_OutlineCustomDepthOcclusion_Inst_C
// Size: 0x490 (Inherited: 0x488)
struct ABP_PP_OutlineCustomDepthOcclusion_Inst_C : ATslPostProcessEffect {
	struct USceneComponent* DefaultSceneRoot; // 0x488(0x08)

	void UserConstructionScript(); // Function BP_PP_OutlineCustomDepthOcclusion_Inst.BP_PP_OutlineCustomDepthOcclusion_Inst_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x273e04
};

