// WidgetBlueprintGeneratedClass BP_DisplayOptionWidget.BP_DisplayOptionWidget_C
// Size: 0xa68 (Inherited: 0xa38)
struct UBP_DisplayOptionWidget_C : U*384955312b {
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget; // 0xa38(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget_1; // 0xa40(0x08)
	struct UTextBlock* BtnsKM_0_Text; // 0xa48(0x08)
	struct UTextBlock* BtnsKM_1_Text; // 0xa50(0x08)
	struct UBP_DisplayOptionSliderWidget_C* DisplayOptionSlider; // 0xa58(0x08)
	struct UImage* IconBgImage; // 0xa60(0x08)
};

