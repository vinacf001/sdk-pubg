// BlueprintGeneratedClass DmgType_Groggy.DmgType_Groggy_C
// Size: 0x100 (Inherited: 0x100)
struct UDmgType_Groggy_C : UTslDamageType {
};

