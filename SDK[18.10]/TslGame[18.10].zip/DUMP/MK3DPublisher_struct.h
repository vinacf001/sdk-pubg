// Enum MK3DPublisher.*f301a54d2b
enum class *f301a54d2b : uint8 {
	*220eeed59d,
	*1e2f92772d,
	*e2af270a38,
	*2a65b8fc17,
	*f301a54d2b_MAX,
};

