// Enum MK3DPublisher.*f301a54d2b
enum class *f301a54d2b : uint8 {
	None,
	None,
};

