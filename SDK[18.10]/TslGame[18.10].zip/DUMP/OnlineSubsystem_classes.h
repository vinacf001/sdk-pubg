// Class OnlineSubsystem.NamedInterfaces
// Size: 0xc0 (Inherited: 0x30)
struct UNamedInterfaces : UObject {
	struct TArray<struct F*c591fb3793> *c57225d61b; // 0x30(0x10)
	struct TArray<struct F*9b538c5435> NamedInterfaceDefs; // 0x40(0x10)
	char pad_50[0x70]; // 0x50(0x70)
};

// Class OnlineSubsystem.*537eb5ab91
// Size: 0x30 (Inherited: 0x30)
struct U*537eb5ab91 : UInterface {

	struct FString OnMatchEnded(); // Function OnlineSubsystem.*537eb5ab91.OnMatchEnded // Event|Public|BlueprintEvent // @ game+0x1b829c
	bool OnMatchReceivedTurn(); // Function OnlineSubsystem.*537eb5ab91.OnMatchReceivedTurn // Event|Public|BlueprintEvent // @ game+0x1b829c
};

