// BlueprintGeneratedClass Implement_Boost_Drink.Implement_Boost_Drink_C
// Size: 0x38 (Inherited: 0x38)
struct UImplement_Boost_Drink_C : U*e021139337 {
};

