// BlueprintGeneratedClass Buff_SpeedUp1.Buff_SpeedUp1_C
// Size: 0x48c (Inherited: 0x478)
struct ABuff_SpeedUp1_C : ATslBuff {
	struct F*abc8f374e0 UberGraphFrame; // 0x478(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x480(0x08)
	float AddSpeedUpFactor; // 0x488(0x04)

	void UserConstructionScript(); // Function Buff_SpeedUp1.Buff_SpeedUp1_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1b829c
	void StartBuffBlueprint(); // Function Buff_SpeedUp1.Buff_SpeedUp1_C.StartBuffBlueprint // Event|Public|BlueprintEvent // @ game+0x1b829c
	bool StopBuffBlueprint(); // Function Buff_SpeedUp1.Buff_SpeedUp1_C.StopBuffBlueprint // Event|Public|BlueprintEvent // @ game+0x1b829c
	struct ATslPlayerController* ExecuteUbergraph_Buff_SpeedUp1(); // Function Buff_SpeedUp1.Buff_SpeedUp1_C.ExecuteUbergraph_Buff_SpeedUp1 //  // @ game+0x1b829c
};

