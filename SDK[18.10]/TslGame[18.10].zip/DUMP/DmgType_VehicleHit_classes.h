// BlueprintGeneratedClass DmgType_VehicleHit.DmgType_VehicleHit_C
// Size: 0x100 (Inherited: 0x100)
struct UDmgType_VehicleHit_C : UTslDamageType {
};

