// Class InputCore.*fea540f4aa
// Size: 0x30 (Inherited: 0x30)
struct U*fea540f4aa : UObject {
};

