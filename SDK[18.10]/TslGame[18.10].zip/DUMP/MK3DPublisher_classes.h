// Class MK3DPublisher.AudioCapturer
// Size: 0x470 (Inherited: 0x3f0)
struct AAudioCapturer : AActor {
	char pad_3F0[0x80]; // 0x3f0(0x80)
};

// Class MK3DPublisher.*6e128d3bb3
// Size: 0x30 (Inherited: 0x30)
struct U*6e128d3bb3 : UBlueprintFunctionLibrary {

	int32 *fbd11c8a26(); // Function MK3DPublisher.*6e128d3bb3.*fbd11c8a26 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6631ab8
	int32 *3b4e31c975(); // Function MK3DPublisher.*6e128d3bb3.*3b4e31c975 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6631c08
	int32 *af2a23f308(); // Function MK3DPublisher.*6e128d3bb3.*af2a23f308 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x663198c
	bool *1bdb097bdf(); // Function MK3DPublisher.*6e128d3bb3.*1bdb097bdf // Final|Native|Static|Public|BlueprintCallable // @ game+0x6633028
	void *3a22b36ecb(); // Function MK3DPublisher.*6e128d3bb3.*3a22b36ecb // Final|Native|Static|Public|BlueprintCallable // @ game+0x66328b0
	void *248fcf30fc(); // Function MK3DPublisher.*6e128d3bb3.*248fcf30fc // Final|Native|Static|Public|BlueprintCallable // @ game+0x663284c
	float *33c2031987(); // Function MK3DPublisher.*6e128d3bb3.*33c2031987 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6631fc8
	bool *b81c8abfa3(); // Function MK3DPublisher.*6e128d3bb3.*b81c8abfa3 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6633288
	void *5d3d0fcc94(); // Function MK3DPublisher.*6e128d3bb3.*5d3d0fcc94 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6632910
	void *5c167dd49c(); // Function MK3DPublisher.*6e128d3bb3.*5c167dd49c // Final|Native|Static|Public|BlueprintCallable // @ game+0x66329f8
	int32 *398e7d9ba4(); // Function MK3DPublisher.*6e128d3bb3.*398e7d9ba4 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6631d2c
	float *f1872e58ba(); // Function MK3DPublisher.*6e128d3bb3.*f1872e58ba // Final|Native|Static|Public|BlueprintCallable // @ game+0x6632974
	void *2126b7ff7d(); // Function MK3DPublisher.*6e128d3bb3.*2126b7ff7d // Final|Native|Static|Public|BlueprintCallable // @ game+0x6631c94
	struct TArray<int32> *03e7a35727(); // Function MK3DPublisher.*6e128d3bb3.*03e7a35727 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x66323b0
	float *0a438fff8d(); // Function MK3DPublisher.*6e128d3bb3.*0a438fff8d // Final|Native|Static|Public|BlueprintCallable // @ game+0x6631b78
	void *f926c45c3a(); // Function MK3DPublisher.*6e128d3bb3.*f926c45c3a // Final|Native|Static|Public|BlueprintCallable // @ game+0x6633014
	int32 *204479987d(); // Function MK3DPublisher.*6e128d3bb3.*204479987d // Final|Native|Static|Public|BlueprintCallable // @ game+0x6632b6c
	struct TArray<float> *7006f60661(); // Function MK3DPublisher.*6e128d3bb3.*7006f60661 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6632620
	struct TArray<struct FString> *6d0b60443f(); // Function MK3DPublisher.*6e128d3bb3.*6d0b60443f // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x663256c
	bool *fa66a3a5e4(); // Function MK3DPublisher.*6e128d3bb3.*fa66a3a5e4 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6632ac0
	int32 *03d7280695(); // Function MK3DPublisher.*6e128d3bb3.*03d7280695 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6631874
	DelegateProperty *a59933c3cb(); // Function MK3DPublisher.*6e128d3bb3.*a59933c3cb // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x66315c4
	float *4cfa6d2f95(); // Function MK3DPublisher.*6e128d3bb3.*4cfa6d2f95 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6632300
	DelegateProperty *ad2c60d77c(); // Function MK3DPublisher.*6e128d3bb3.*ad2c60d77c // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6631670
	bool *c8a50e2aa7(); // Function MK3DPublisher.*6e128d3bb3.*c8a50e2aa7 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6632760
	void *e76e8bbeec(); // Function MK3DPublisher.*6e128d3bb3.*e76e8bbeec // Final|Native|Static|Public|BlueprintCallable // @ game+0x6632fac
	struct FString *4506b8c7cd(); // Function MK3DPublisher.*6e128d3bb3.*4506b8c7cd // Final|Native|Static|Public|BlueprintCallable // @ game+0x6633554
	struct FString *4fc021d0da(); // Function MK3DPublisher.*6e128d3bb3.*4fc021d0da // Final|Native|Static|Public|BlueprintCallable // @ game+0x6632328
	bool *e809755714(); // Function MK3DPublisher.*6e128d3bb3.*e809755714 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6631534
	bool *8375d1fe96(); // Function MK3DPublisher.*6e128d3bb3.*8375d1fe96 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6632c14
	struct FString *4ef94035a0(); // Function MK3DPublisher.*6e128d3bb3.*4ef94035a0 // Final|Native|Static|Public|BlueprintCallable // @ game+0x663363c
	void *adc0beba41(); // Function MK3DPublisher.*6e128d3bb3.*adc0beba41 // Final|Native|Static|Public|BlueprintCallable // @ game+0x66334e8
	DelegateProperty *22ffa0ce88(); // Function MK3DPublisher.*6e128d3bb3.*22ffa0ce88 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x663171c
	int32 *663d1c0f69(); // Function MK3DPublisher.*6e128d3bb3.*663d1c0f69 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6632270
	struct FString *203ecfa57f(); // Function MK3DPublisher.*6e128d3bb3.*203ecfa57f // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x66320d4
	float *331964a351(); // Function MK3DPublisher.*6e128d3bb3.*331964a351 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6631b50
	bool *7a2cd73beb(); // Function MK3DPublisher.*6e128d3bb3.*7a2cd73beb // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6632db0
	struct FString *18961060bf(); // Function MK3DPublisher.*6e128d3bb3.*18961060bf // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6631e34
	DelegateProperty *6a18810aeb(); // Function MK3DPublisher.*6e128d3bb3.*6a18810aeb // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x66317c8
	struct FString *c35d5e1e49(); // Function MK3DPublisher.*6e128d3bb3.*c35d5e1e49 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6633724
	bool *c816d53d3d(); // Function MK3DPublisher.*6e128d3bb3.*c816d53d3d // Final|Native|Static|Public|BlueprintCallable // @ game+0x66327c4
	void *d027265167(); // Function MK3DPublisher.*6e128d3bb3.*d027265167 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6632a5c
	struct TArray<struct FString> *bc40893864(); // Function MK3DPublisher.*6e128d3bb3.*bc40893864 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x66324b8
	bool *81f9f72787(); // Function MK3DPublisher.*6e128d3bb3.*81f9f72787 // Final|Native|Static|Public|BlueprintCallable // @ game+0x66327e8
	struct TArray<struct FString> *d068694a96(); // Function MK3DPublisher.*6e128d3bb3.*d068694a96 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6633820
	int32 *20cc247e80(); // Function MK3DPublisher.*6e128d3bb3.*20cc247e80 // Final|Native|Static|Public|BlueprintCallable // @ game+0x66322d0
};

// Class MK3DPublisher.ViewportCapturer
// Size: 0x488 (Inherited: 0x3f0)
struct AViewportCapturer : AActor {
	char pad_3F0[0x98]; // 0x3f0(0x98)
};

