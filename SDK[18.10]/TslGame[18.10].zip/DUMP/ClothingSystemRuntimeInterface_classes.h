// Class ClothingSystemRuntimeInterface.*ac42304f2a
// Size: 0x50 (Inherited: 0x30)
struct U*ac42304f2a : UObject {
	struct FString *173ce136a0; // 0x30(0x10)
	struct FGuid *05d65443e4; // 0x40(0x10)
};

// Class ClothingSystemRuntimeInterface.*aefcf253a9
// Size: 0x30 (Inherited: 0x30)
struct U*aefcf253a9 : UObject {
};

