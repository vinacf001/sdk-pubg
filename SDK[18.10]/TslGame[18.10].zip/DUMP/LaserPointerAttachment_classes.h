// BlueprintGeneratedClass LaserPointerAttachment.LaserPointerAttachment_C
// Size: 0xca0 (Inherited: 0xca0)
struct ULaserPointerAttachment_C : U*f8454b8f33 {
};

