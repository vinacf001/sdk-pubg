// WidgetBlueprintGeneratedClass LobbyBlurBackgroundWidjet.LobbyBlurBackgroundWidjet_C
// Size: 0x258 (Inherited: 0x258)
struct ULobbyBlurBackgroundWidjet_C : UUserWidget {
};

