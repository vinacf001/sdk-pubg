// ScriptStruct AssetRegistry.AssetBundleData
// Size: 0x10 (Inherited: 0x00)
struct FAssetBundleData {
	struct TArray<struct F*58ba50f869> *b3ffb3f874; // 0x00(0x10)
};

// ScriptStruct AssetRegistry.*58ba50f869
// Size: 0x28 (Inherited: 0x00)
struct F*58ba50f869 {
	struct FPrimaryAssetId *1485385112; // 0x00(0x10)
	struct FName BundleName; // 0x10(0x08)
	struct TArray<struct FStringAssetReference> *da3486fb00; // 0x18(0x10)
};

