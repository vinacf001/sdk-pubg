// BlueprintGeneratedClass DmgType_VehicleCrashHit.DmgType_VehicleCrashHit_C
// Size: 0x100 (Inherited: 0x100)
struct UDmgType_VehicleCrashHit_C : UTslDamageType {
};

