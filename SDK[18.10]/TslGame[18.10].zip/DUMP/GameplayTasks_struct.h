// Enum GameplayTasks.*80bc88b4fb
enum class *80bc88b4fb : uint8 {
	None,
	None,
};

// Enum GameplayTasks.EGameplayTaskRunResult
enum class EGameplayTaskRunResult : uint8 {
	None,
	None,
};

// Enum GameplayTasks.EGameplayTaskState
enum class EGameplayTaskState : uint8 {
	None,
	None,
};

// ScriptStruct GameplayTasks.*2a717b7917
// Size: 0x02 (Inherited: 0x00)
struct F*2a717b7917 {
	char pad_0[0x2]; // 0x00(0x02)
};

