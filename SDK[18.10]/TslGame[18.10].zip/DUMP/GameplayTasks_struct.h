// Enum GameplayTasks.*80bc88b4fb
enum class *80bc88b4fb : uint8 {
	*4f318fa0f8,
	*5ef326a8ae,
	*ab037fc1a5,
	*80bc88b4fb_MAX,
};

// Enum GameplayTasks.EGameplayTaskRunResult
enum class EGameplayTaskRunResult : uint8 {
	Error,
	Failed,
	Success_Paused,
	Success_Active,
	Success_Finished,
	EGameplayTaskRunResult_MAX,
};

// Enum GameplayTasks.EGameplayTaskState
enum class EGameplayTaskState : uint8 {
	Uninitialized,
	AwaitingActivation,
	Paused,
	Active,
	Finished,
	EGameplayTaskState_MAX,
};

// ScriptStruct GameplayTasks.*2a717b7917
// Size: 0x02 (Inherited: 0x00)
struct F*2a717b7917 {
	char pad_0[0x2]; // 0x00(0x02)
};

