// BlueprintGeneratedClass BP_Vantage_EP.BP_Vantage_EP_C
// Size: 0x1010 (Inherited: 0x1010)
struct ABP_Vantage_EP_C : ABP_Vantage_C {
};

