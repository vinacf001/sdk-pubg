// BlueprintGeneratedClass DefaultRifleSetting.DefaultRifleSetting_C
// Size: 0x1100 (Inherited: 0x1100)
struct ADefaultRifleSetting_C : ATslWeapon_Trajectory {
};

