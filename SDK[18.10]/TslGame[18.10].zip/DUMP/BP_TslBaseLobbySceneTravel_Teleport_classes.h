// BlueprintGeneratedClass BP_TslBaseLobbySceneTravel_Teleport.BP_TslBaseLobbySceneTravel_Teleport_C
// Size: 0x498 (Inherited: 0x490)
struct ABP_TslBaseLobbySceneTravel_Teleport_C : ATslLobbySceneTravel_Teleport {
	struct USceneComponent* DefaultSceneRoot; // 0x490(0x08)

	void UserConstructionScript(); // Function BP_TslBaseLobbySceneTravel_Teleport.BP_TslBaseLobbySceneTravel_Teleport_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1b829c
};

