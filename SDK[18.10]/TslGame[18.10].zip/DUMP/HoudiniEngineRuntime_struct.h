// Enum HoudiniEngineRuntime.*47e33d7646
enum class *47e33d7646 : uint8 {
	*1030a2eae9,
	*d265de425d,
	*d67823b3d1,
	*6b901476e7,
	*47e33d7646_MAX,
};

// Enum HoudiniEngineRuntime.*37ee8ed7d2
enum class *37ee8ed7d2 : uint8 {
	*1a7e6cbcfd,
	*8945c9a008,
	*9bf01ab14e,
	*539110fd43,
	*312d61d172,
	*37ee8ed7d2_MAX,
};

// Enum HoudiniEngineRuntime.*a7d9a8e2a1
enum class *a7d9a8e2a1 : uint8 {
	*c1f585682f,
	*d265b1ad67,
	*009a0b8f3f,
	*a7d9a8e2a1_MAX,
};

// Enum HoudiniEngineRuntime.*16417b9ec5
enum class *16417b9ec5 : uint8 {
	*cf9eeff210,
	*f916a08a44,
	*691cacdcea,
	*c3abbb7c2d,
	*16417b9ec5_MAX,
};

// Enum HoudiniEngineRuntime.*67cc437a88
enum class *67cc437a88 : uint8 {
	*c5c1ae9e5b,
	*b2b96dd544,
	*9955c0394e,
	*657d8f2e85,
	*67cc437a88_MAX,
};

// Enum HoudiniEngineRuntime.*cc8afcdfcf
enum class *cc8afcdfcf : uint8 {
	*692286408c,
	*4c565706ff,
	*f88e3483b6,
	*85654fa642,
	*cc8afcdfcf_MAX,
};

// Enum HoudiniEngineRuntime.EHoudiniHandleType
enum class EHoudiniHandleType : uint8 {
	Xform,
	Bounder,
	Unsupported,
	EHoudiniHandleType_MAX,
};

// ScriptStruct HoudiniEngineRuntime.*9f2306d7c5
// Size: 0x30 (Inherited: 0x00)
struct F*9f2306d7c5 {
	struct FString Name; // 0x00(0x10)
	struct FDirectoryPath path; // 0x10(0x10)
	struct FString ContentDirID; // 0x20(0x10)
};

