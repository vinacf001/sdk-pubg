// WidgetBlueprintGeneratedClass BP_PcOptionTabLabelWidget.BP_PcOptionTabLabelWidget_C
// Size: 0x4c0 (Inherited: 0x4c0)
struct UBP_PcOptionTabLabelWidget_C : U*ea67073620 {
};

