// BlueprintGeneratedClass BP_TslSLBMaxHpBuff.BP_TslSLBMaxHpBuff_C
// Size: 0x4a8 (Inherited: 0x4a0)
struct ABP_TslSLBMaxHpBuff_C : ATslIncreaseMaxHpBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4a0(0x08)

	void UserConstructionScript(); // Function BP_TslSLBMaxHpBuff.BP_TslSLBMaxHpBuff_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1b829c
};

