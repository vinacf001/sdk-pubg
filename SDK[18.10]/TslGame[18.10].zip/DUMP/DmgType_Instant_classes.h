// BlueprintGeneratedClass DmgType_Instant.DmgType_Instant_C
// Size: 0x100 (Inherited: 0x100)
struct UDmgType_Instant_C : UTslDamageType {
};

