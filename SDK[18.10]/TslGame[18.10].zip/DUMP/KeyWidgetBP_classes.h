// WidgetBlueprintGeneratedClass KeyWidgetBP.KeyWidgetBP_C
// Size: 0x568 (Inherited: 0x550)
struct UKeyWidgetBP_C : U*60032840a2 {
	struct F*abc8f374e0 UberGraphFrame; // 0x550(0x08)
	struct UImage* BorderImage; // 0x558(0x08)
	struct UTextBlock* KeyNameTextBlock; // 0x560(0x08)

	bool PreConstruct(); // Function KeyWidgetBP.KeyWidgetBP_C.PreConstruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x1b829c
	struct FSlateColor ExecuteUbergraph_KeyWidgetBP(); // Function KeyWidgetBP.KeyWidgetBP_C.ExecuteUbergraph_KeyWidgetBP // HasDefaults // @ game+0x1b829c
};

