// WidgetBlueprintGeneratedClass KeyGuideContentBP.KeyGuideContentBP_C
// Size: 0x4a0 (Inherited: 0x480)
struct UKeyGuideContentBP_C : U*63e570857c {
	struct UKeyImageWIdgetBP_C* KeyImageWIdgetBP_1; // 0x480(0x08)
	struct UKeyImageWIdgetBP_C* KeyImageWIdgetBP_2; // 0x488(0x08)
	struct UKeyImageWIdgetBP_C* KeyImageWIdgetBP_3; // 0x490(0x08)
	struct UKeyImageWIdgetBP_C* KeyImageWIdgetBP_4; // 0x498(0x08)
};

