// WidgetBlueprintGeneratedClass BP_KillLogViewWidget.BP_KillLogViewWidget_C
// Size: 0x458 (Inherited: 0x440)
struct UBP_KillLogViewWidget_C : U*6df7937d7e {
	struct F*abc8f374e0 UberGraphFrame; // 0x440(0x08)
	struct UButton* Button_1; // 0x448(0x08)
	struct UImage* DebugCrosshair; // 0x450(0x08)

	void BndEvt__Button_0_K2Node_ComponentBoundEvent_116_OnButtonClickedEvent__DelegateSignature(); // Function BP_KillLogViewWidget.BP_KillLogViewWidget_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_116_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x1b829c
	bool ExecuteUbergraph_BP_KillLogViewWidget(); // Function BP_KillLogViewWidget.BP_KillLogViewWidget_C.ExecuteUbergraph_BP_KillLogViewWidget //  // @ game+0x1b829c
};

