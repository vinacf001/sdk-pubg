// WidgetBlueprintGeneratedClass KeyGuideTabWidget.KeyGuideTabWidget_C
// Size: 0x470 (Inherited: 0x470)
struct UKeyGuideTabWidget_C : U*470d1af080 {
};

