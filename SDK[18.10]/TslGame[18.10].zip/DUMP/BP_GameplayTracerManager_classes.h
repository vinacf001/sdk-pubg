// BlueprintGeneratedClass BP_GameplayTracerManager.BP_GameplayTracerManager_C
// Size: 0x458 (Inherited: 0x450)
struct ABP_GameplayTracerManager_C : AGameplayTracerManager {
	struct USceneComponent* DefaultSceneRoot; // 0x450(0x08)

	void UserConstructionScript(); // Function BP_GameplayTracerManager.BP_GameplayTracerManager_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1b829c
};

