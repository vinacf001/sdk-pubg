// WidgetBlueprintGeneratedClass BP_PcOptionCloudSavingAlertWidget.BP_PcOptionCloudSavingAlertWidget_C
// Size: 0x490 (Inherited: 0x490)
struct UBP_PcOptionCloudSavingAlertWidget_C : U*85de85f6a1 {
};

