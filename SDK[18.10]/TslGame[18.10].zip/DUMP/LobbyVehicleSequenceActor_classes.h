// BlueprintGeneratedClass LobbyVehicleSequenceActor.LobbyVehicleSequenceActor_C
// Size: 0x4c0 (Inherited: 0x4c0)
struct ALobbyVehicleSequenceActor_C : ATslLobbyLevelVehicleSequenceActor {
};

