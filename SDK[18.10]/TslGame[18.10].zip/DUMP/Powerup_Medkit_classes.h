// BlueprintGeneratedClass Powerup_Medkit.Powerup_Medkit_C
// Size: 0x448 (Inherited: 0x448)
struct APowerup_Medkit_C : APowerup_Base_C {
};

