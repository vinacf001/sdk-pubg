// BlueprintGeneratedClass BP_MortarInstall.BP_MortarInstall_C
// Size: 0x450 (Inherited: 0x448)
struct ABP_MortarInstall_C : APowerup_Base_C {
	struct F*abc8f374e0 UberGraphFrame; // 0x448(0x08)

	void UserConstructionScript(); // Function BP_MortarInstall.BP_MortarInstall_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1b829c
	void ReceiveBeginPlay(); // Function BP_MortarInstall.BP_MortarInstall_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x1b829c
	void PlayAnim_MortarInstall(); // Function BP_MortarInstall.BP_MortarInstall_C.PlayAnim_MortarInstall // BlueprintCallable|BlueprintEvent // @ game+0x1b829c
	int32 ExecuteUbergraph_BP_MortarInstall(); // Function BP_MortarInstall.BP_MortarInstall_C.ExecuteUbergraph_BP_MortarInstall //  // @ game+0x1b829c
};

