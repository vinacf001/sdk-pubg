// Class LightPropagationVolumeRuntime.LightPropagationVolumeBlendable
// Size: 0x80 (Inherited: 0x30)
struct ULightPropagationVolumeBlendable : UObject {
	char pad_30[0x8]; // 0x30(0x08)
	struct F*f944f80077 Settings; // 0x38(0x40)
	float BlendWeight; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
};

