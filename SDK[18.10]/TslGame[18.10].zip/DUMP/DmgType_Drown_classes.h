// BlueprintGeneratedClass DmgType_Drown.DmgType_Drown_C
// Size: 0x100 (Inherited: 0x100)
struct UDmgType_Drown_C : UTslDamageType {
};

