// BlueprintGeneratedClass DmgTypeExplosion_Vehicle.DmgTypeExplosion_Vehicle_C
// Size: 0x100 (Inherited: 0x100)
struct UDmgTypeExplosion_Vehicle_C : UTslDamageType {
};

