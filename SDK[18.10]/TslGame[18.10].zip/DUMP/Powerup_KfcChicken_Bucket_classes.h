// BlueprintGeneratedClass Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C
// Size: 0x458 (Inherited: 0x448)
struct APowerup_KfcChicken_Bucket_C : APowerup_Base_C {
	struct F*abc8f374e0 UberGraphFrame; // 0x448(0x08)
	struct F*da672abddc Timer2Handle; // 0x450(0x08)

	void UserConstructionScript(); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1b829c
	void ReceiveBeginPlay(); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x1b829c
	void CustomEvent_1(); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x1b829c
	void ReceiveDestroyed(); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x1b829c
	struct ATslCharacter* PlayAnim(); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.PlayAnim // BlueprintCallable|BlueprintEvent // @ game+0x1b829c
	float ReceiveTick(); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.ReceiveTick // Event|Public|BlueprintEvent // @ game+0x1b829c
	void Drop(); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.Drop // BlueprintCallable|BlueprintEvent // @ game+0x1b829c
	bool ExecuteUbergraph_Powerup_KfcChicken_Bucket(); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.ExecuteUbergraph_Powerup_KfcChicken_Bucket // HasDefaults // @ game+0x1b829c
};

