// BlueprintGeneratedClass BP_ItemRecommendManager.BP_ItemRecommendManager_C
// Size: 0x120 (Inherited: 0x120)
struct UBP_ItemRecommendManager_C : U*28b7300e1f {
};

