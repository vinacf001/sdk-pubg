// Class JsonUtilities.*549d3900b5
// Size: 0x30 (Inherited: 0x30)
struct U*549d3900b5 : UObject {
};

