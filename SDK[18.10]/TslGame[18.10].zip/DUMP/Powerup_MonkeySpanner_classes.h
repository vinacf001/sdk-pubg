// BlueprintGeneratedClass Powerup_MonkeySpanner.Powerup_MonkeySpanner_C
// Size: 0x450 (Inherited: 0x448)
struct APowerup_MonkeySpanner_C : APowerup_Base_C {
	struct F*abc8f374e0 UberGraphFrame; // 0x448(0x08)

	void UserConstructionScript(); // Function Powerup_MonkeySpanner.Powerup_MonkeySpanner_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1b829c
	void ReceiveBeginPlay(); // Function Powerup_MonkeySpanner.Powerup_MonkeySpanner_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x1b829c
	int32 ExecuteUbergraph_Powerup_MonkeySpanner(); // Function Powerup_MonkeySpanner.Powerup_MonkeySpanner_C.ExecuteUbergraph_Powerup_MonkeySpanner //  // @ game+0x1b829c
};

