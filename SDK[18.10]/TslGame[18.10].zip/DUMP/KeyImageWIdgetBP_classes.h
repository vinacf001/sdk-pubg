// WidgetBlueprintGeneratedClass KeyImageWIdgetBP.KeyImageWIdgetBP_C
// Size: 0x470 (Inherited: 0x470)
struct UKeyImageWIdgetBP_C : U*7d71d941dd {
};

