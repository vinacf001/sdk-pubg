// BlueprintGeneratedClass BP_ShellEvent_Smg.BP_ShellEvent_SMG_C
// Size: 0x90 (Inherited: 0x90)
struct UBP_ShellEvent_SMG_C : U*c9c8e931e8 {
};

