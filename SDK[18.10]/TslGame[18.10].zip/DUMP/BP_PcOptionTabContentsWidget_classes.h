// WidgetBlueprintGeneratedClass BP_PcOptionTabContentsWidget.BP_PcOptionTabContentsWidget_C
// Size: 0x458 (Inherited: 0x450)
struct UBP_PcOptionTabContentsWidget_C : U*e9e93be8a5 {
	struct UWidgetSwitcher* SubTabContentSwitcher; // 0x450(0x08)
};

