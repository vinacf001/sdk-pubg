// BlueprintGeneratedClass BP_TslSLBGroggyResistanceBuff.BP_TslSLBGroggyResistanceBuff_C
// Size: 0x4b8 (Inherited: 0x4b0)
struct ABP_TslSLBGroggyResistanceBuff_C : ATslResistanceBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4b0(0x08)

	void UserConstructionScript(); // Function BP_TslSLBGroggyResistanceBuff.BP_TslSLBGroggyResistanceBuff_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1b829c
};

