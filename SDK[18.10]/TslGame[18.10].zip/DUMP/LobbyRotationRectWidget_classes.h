// WidgetBlueprintGeneratedClass LobbyRotationRectWidget.LobbyRotationRectWidget_C
// Size: 0x428 (Inherited: 0x420)
struct ULobbyRotationRectWidget_C : U*b6db81511e {
	struct UImage* RotationRect; // 0x420(0x08)
};

