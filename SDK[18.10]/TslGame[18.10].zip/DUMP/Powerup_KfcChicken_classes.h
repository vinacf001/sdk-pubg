// BlueprintGeneratedClass Powerup_KfcChicken.Powerup_KfcChicken_C
// Size: 0x450 (Inherited: 0x448)
struct APowerup_KfcChicken_C : APowerup_Base_C {
	struct F*da672abddc Timer2Handle; // 0x448(0x08)

	void UserConstructionScript(); // Function Powerup_KfcChicken.Powerup_KfcChicken_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1b829c
};

