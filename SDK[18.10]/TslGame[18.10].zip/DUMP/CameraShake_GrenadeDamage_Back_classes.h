// BlueprintGeneratedClass CameraShake_GrenadeDamage_Back.CameraShake_GrenadeDamage_Back_C
// Size: 0x170 (Inherited: 0x170)
struct UCameraShake_GrenadeDamage_Back_C : UCameraShake {
};

