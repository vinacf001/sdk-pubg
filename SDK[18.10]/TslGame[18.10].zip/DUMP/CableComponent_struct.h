// ScriptStruct CableComponent.*74dda64bfe
// Size: 0x10 (Inherited: 0x00)
struct F*74dda64bfe {
	int32 ParticleIndex; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FName SocketName; // 0x08(0x08)
};

