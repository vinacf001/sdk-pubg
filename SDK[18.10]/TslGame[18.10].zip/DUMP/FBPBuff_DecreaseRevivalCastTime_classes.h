// BlueprintGeneratedClass FBPBuff_DecreaseRevivalCastTime.FBPBuff_DecreaseRevivalCastTime_C
// Size: 0x4a8 (Inherited: 0x4a0)
struct AFBPBuff_DecreaseRevivalCastTime_C : ATslFBRBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4a0(0x08)

	void UserConstructionScript(); // Function FBPBuff_DecreaseRevivalCastTime.FBPBuff_DecreaseRevivalCastTime_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1b829c
};

