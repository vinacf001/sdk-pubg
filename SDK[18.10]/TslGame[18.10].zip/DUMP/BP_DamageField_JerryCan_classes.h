// BlueprintGeneratedClass BP_DamageField_JerryCan.BP_DamageField_JerryCan_C
// Size: 0x498 (Inherited: 0x498)
struct ABP_DamageField_JerryCan_C : ATslDamageField {

	bool UserConstructionScript(); // Function BP_DamageField_JerryCan.BP_DamageField_JerryCan_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1b829c
};

