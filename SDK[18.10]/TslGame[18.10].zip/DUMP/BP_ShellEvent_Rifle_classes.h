// BlueprintGeneratedClass BP_ShellEvent_Rifle.BP_ShellEvent_Rifle_C
// Size: 0x90 (Inherited: 0x90)
struct UBP_ShellEvent_Rifle_C : U*c9c8e931e8 {
};

