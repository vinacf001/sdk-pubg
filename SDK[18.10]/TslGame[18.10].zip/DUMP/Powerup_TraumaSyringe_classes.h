// BlueprintGeneratedClass Powerup_TraumaSyringe.Powerup_TraumaSyringe_C
// Size: 0x458 (Inherited: 0x448)
struct APowerup_TraumaSyringe_C : APowerup_Base_C {
	struct F*abc8f374e0 UberGraphFrame; // 0x448(0x08)
	struct F*da672abddc Timer2Handle; // 0x450(0x08)

	void UserConstructionScript(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1b829c
	void Throw Syringe Cap Away(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.Throw Syringe Cap Away // BlueprintCallable|BlueprintEvent // @ game+0x1b829c
	void ReceiveDestroyed(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x1b829c
	float Init Syringe Delay(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.Init Syringe Delay // BlueprintCallable|BlueprintEvent // @ game+0x1b829c
	struct FName ExecuteUbergraph_Powerup_TraumaSyringe(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.ExecuteUbergraph_Powerup_TraumaSyringe // HasDefaults // @ game+0x1b829c
};

