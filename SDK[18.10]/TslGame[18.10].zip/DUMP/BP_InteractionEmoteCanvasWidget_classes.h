// WidgetBlueprintGeneratedClass BP_InteractionEmoteCanvasWidget.BP_InteractionEmoteCanvasWidget_C
// Size: 0x440 (Inherited: 0x440)
struct UBP_InteractionEmoteCanvasWidget_C : U*bfc2bc5ae2 {
};

