// BlueprintGeneratedClass CameraShake_HitReaction.CameraShake_HitReaction_C
// Size: 0x170 (Inherited: 0x170)
struct UCameraShake_HitReaction_C : UCameraShake {
};

