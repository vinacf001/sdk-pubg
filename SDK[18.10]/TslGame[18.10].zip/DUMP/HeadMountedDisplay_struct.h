// Enum HeadMountedDisplay.ETrackingStatus
enum class ETrackingStatus : uint8 {
	None,
	None,
};

