// BlueprintGeneratedClass BP_JerryCan_CastableImplement.BP_JerryCan_CastableImplement_C
// Size: 0x168 (Inherited: 0x168)
struct UBP_JerryCan_CastableImplement_C : U*9332cc3a51 {
};

