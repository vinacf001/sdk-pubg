// BlueprintGeneratedClass BP_DBX_LGD.BP_DBX_LGD_C
// Size: 0x1038 (Inherited: 0x1038)
struct ABP_DBX_LGD_C : ABP_DBX_C {
};

