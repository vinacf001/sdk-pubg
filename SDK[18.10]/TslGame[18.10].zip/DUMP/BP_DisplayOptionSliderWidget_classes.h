// WidgetBlueprintGeneratedClass BP_DisplayOptionSliderWidget.BP_DisplayOptionSliderWidget_C
// Size: 0x898 (Inherited: 0x870)
struct UBP_DisplayOptionSliderWidget_C : U*09cb64dd50 {
	struct F*abc8f374e0 UberGraphFrame; // 0x870(0x08)
	struct UProgressBar* BrightnessProgressBar; // 0x878(0x08)
	struct USlider* BrightnessSlider; // 0x880(0x08)
	struct UEditableText* BrightnessText; // 0x888(0x08)
	struct UProgressBar* NewVar_1; // 0x890(0x08)

	float Tick(); // Function BP_DisplayOptionSliderWidget.BP_DisplayOptionSliderWidget_C.Tick // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x1b829c
	float ExecuteUbergraph_BP_DisplayOptionSliderWidget(); // Function BP_DisplayOptionSliderWidget.BP_DisplayOptionSliderWidget_C.ExecuteUbergraph_BP_DisplayOptionSliderWidget // HasDefaults // @ game+0x1b829c
};

