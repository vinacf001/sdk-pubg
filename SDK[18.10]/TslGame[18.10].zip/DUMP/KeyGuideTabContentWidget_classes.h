// WidgetBlueprintGeneratedClass KeyGuideTabContentWidget.KeyGuideTabContentWidget_C
// Size: 0x520 (Inherited: 0x508)
struct UKeyGuideTabContentWidget_C : U*3945e9cacf {
	struct F*abc8f374e0 UberGraphFrame; // 0x508(0x08)
	struct UTextBlock* TitleNormal; // 0x510(0x08)
	struct UTextBlock* TitleSelected; // 0x518(0x08)

	bool PreConstruct(); // Function KeyGuideTabContentWidget.KeyGuideTabContentWidget_C.PreConstruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x1b829c
	bool ExecuteUbergraph_KeyGuideTabContentWidget(); // Function KeyGuideTabContentWidget.KeyGuideTabContentWidget_C.ExecuteUbergraph_KeyGuideTabContentWidget //  // @ game+0x1b829c
};

