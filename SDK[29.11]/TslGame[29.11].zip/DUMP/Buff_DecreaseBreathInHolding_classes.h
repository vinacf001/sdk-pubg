// BlueprintGeneratedClass Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C
// Size: 0x4a0 (Inherited: 0x480)
struct ABuff_DecreaseBreathInHolding_C : ACharacterBreathBuff {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x480(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x488(0x08)
	struct F*9147081c37 BuffClass; // 0x490(0x10)

	struct ATslCharacter* UserConstructionScript(); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	struct ATslCharacter* TickBuff(); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.TickBuff // Event|Public|BlueprintEvent // @ game+0x1dcd78
	struct ATslBuff* ExecuteUbergraph_Buff_DecreaseBreathInHolding(); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.ExecuteUbergraph_Buff_DecreaseBreathInHolding //  // @ game+0x1dcd78
};

