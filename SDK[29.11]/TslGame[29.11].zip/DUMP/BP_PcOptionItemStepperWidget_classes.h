// WidgetBlueprintGeneratedClass BP_PcOptionItemStepperWidget.BP_PcOptionItemStepperWidget_C
// Size: 0x8e8 (Inherited: 0x8e0)
struct UBP_PcOptionItemStepperWidget_C : U*53d36b2825 {
	struct USizeBox* IndentationSizeBox; // 0x8e0(0x08)
};

