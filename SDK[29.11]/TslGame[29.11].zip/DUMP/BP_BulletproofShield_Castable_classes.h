// BlueprintGeneratedClass BP_BulletproofShield_Castable.BP_BulletproofShield_Castable_C
// Size: 0xb8 (Inherited: 0xb8)
struct UBP_BulletproofShield_Castable_C : U*df865d429e {
};

