// BlueprintGeneratedClass LobbyHUD_Default.LobbyHUD_Default_C
// Size: 0x19f8 (Inherited: 0x19f0)
struct ALobbyHUD_Default_C : ALobbyHUD {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x19f0(0x08)

	void UserConstructionScript(); // Function LobbyHUD_Default.LobbyHUD_Default_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	void ReceivePostBeginPlay(); // Function LobbyHUD_Default.LobbyHUD_Default_C.ReceivePostBeginPlay // Event|Public|BlueprintEvent // @ game+0x1dcd78
	int32 ExecuteUbergraph_LobbyHUD_Default(); // Function LobbyHUD_Default.LobbyHUD_Default_C.ExecuteUbergraph_LobbyHUD_Default //  // @ game+0x1dcd78
};

