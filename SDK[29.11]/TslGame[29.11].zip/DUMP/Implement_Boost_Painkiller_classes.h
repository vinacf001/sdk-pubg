// BlueprintGeneratedClass Implement_Boost_Painkiller.Implement_Boost_Painkiller_C
// Size: 0x38 (Inherited: 0x38)
struct UImplement_Boost_Painkiller_C : U*59e91b371f {
};

