// BlueprintGeneratedClass JerryCan_Explosion.JerryCan_Explosion_C
// Size: 0x1100 (Inherited: 0x1100)
struct AJerryCan_Explosion_C : ATslExplosionEffect {
};

