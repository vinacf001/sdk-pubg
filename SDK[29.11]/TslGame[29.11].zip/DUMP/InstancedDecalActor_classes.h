// BlueprintGeneratedClass InstancedDecalActor.InstancedDecalActor_C
// Size: 0x3f8 (Inherited: 0x3f8)
struct AInstancedDecalActor_C : ADecalActor {
};

