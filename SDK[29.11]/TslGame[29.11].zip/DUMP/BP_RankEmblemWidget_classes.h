// WidgetBlueprintGeneratedClass BP_RankEmblemWidget.BP_RankEmblemWidget_C
// Size: 0x4f0 (Inherited: 0x4e8)
struct UBP_RankEmblemWidget_C : U*f86887334f {
	struct UImage* EmblemImage; // 0x4e8(0x08)
};

