// BlueprintGeneratedClass LootTruckItemSpawnProcessor_Savage_UniqueGunBag.LootTruckItemSpawnProcessor_Savage_UniqueGunBag_C
// Size: 0x138 (Inherited: 0x138)
struct ULootTruckItemSpawnProcessor_Savage_UniqueGunBag_C : U*7964217ea6 {
};

