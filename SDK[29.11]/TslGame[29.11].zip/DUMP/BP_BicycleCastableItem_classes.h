// BlueprintGeneratedClass BP_BicycleCastableItem.BP_BicycleCastableItem_C
// Size: 0xa0 (Inherited: 0xa0)
struct UBP_BicycleCastableItem_C : U*7694c9e7bc {
};

