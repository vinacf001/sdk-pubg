// BlueprintGeneratedClass Powerup_PutFuel.Powerup_PutFuel_C
// Size: 0x448 (Inherited: 0x448)
struct APowerup_PutFuel_C : APowerup_Base_C {
};

