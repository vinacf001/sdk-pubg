// BlueprintGeneratedClass FBRBuff_v2_Flash_ra_lv5.FBRBuff_v2_Flash_ra_lv5_C
// Size: 0x4c8 (Inherited: 0x4c0)
struct AFBRBuff_v2_Flash_ra_lv5_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4c0(0x08)

	void UserConstructionScript(); // Function FBRBuff_v2_Flash_ra_lv5.FBRBuff_v2_Flash_ra_lv5_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
};

