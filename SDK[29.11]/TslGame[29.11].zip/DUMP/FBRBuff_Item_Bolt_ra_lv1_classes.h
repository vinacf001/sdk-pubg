// BlueprintGeneratedClass FBRBuff_Item_Bolt_ra_lv1.FBRBuff_Item_Bolt_ra_lv1_C
// Size: 0x4c8 (Inherited: 0x4c0)
struct AFBRBuff_Item_Bolt_ra_lv1_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4c0(0x08)

	void UserConstructionScript(); // Function FBRBuff_Item_Bolt_ra_lv1.FBRBuff_Item_Bolt_ra_lv1_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
};

