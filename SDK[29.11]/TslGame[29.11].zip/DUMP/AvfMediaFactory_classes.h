// Class AvfMediaFactory.AvfMediaSettings
// Size: 0x38 (Inherited: 0x30)
struct UAvfMediaSettings : UObject {
	bool NativeAudioOut; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

