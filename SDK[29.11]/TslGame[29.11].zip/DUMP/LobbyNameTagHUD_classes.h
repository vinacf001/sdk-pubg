// WidgetBlueprintGeneratedClass LobbyNameTagHUD.LobbyNameTagHUD_C
// Size: 0x460 (Inherited: 0x460)
struct ULobbyNameTagHUD_C : U*6d52358df4 {

	int32 CleanUpNameTagWidget(); // Function LobbyNameTagHUD.LobbyNameTagHUD_C.CleanUpNameTagWidget // Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	int32 SetupNameTagWidget(); // Function LobbyNameTagHUD.LobbyNameTagHUD_C.SetupNameTagWidget // Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	struct U*396f8af97a* GetNameTagWidget(); // Function LobbyNameTagHUD.LobbyNameTagHUD_C.GetNameTagWidget // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
};

