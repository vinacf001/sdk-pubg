// BlueprintGeneratedClass LaserPointerAttachment.LaserPointerAttachment_C
// Size: 0xc50 (Inherited: 0xc50)
struct ULaserPointerAttachment_C : U*8dcf0e5779 {
};

