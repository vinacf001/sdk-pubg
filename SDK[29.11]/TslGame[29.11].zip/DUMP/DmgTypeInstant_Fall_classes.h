// BlueprintGeneratedClass DmgTypeInstant_Fall.DmgTypeInstant_Fall_C
// Size: 0x100 (Inherited: 0x100)
struct UDmgTypeInstant_Fall_C : UDmgType_Instant_C {
};

