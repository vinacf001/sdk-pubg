// BlueprintGeneratedClass BP_EmPickup_Castable.BP_EmPickup_Castable_C
// Size: 0x98 (Inherited: 0x98)
struct UBP_EmPickup_Castable_C : U*eece3abc78 {
};

