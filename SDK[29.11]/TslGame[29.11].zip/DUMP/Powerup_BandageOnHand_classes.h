// BlueprintGeneratedClass Powerup_BandageOnHand.Powerup_BandageOnHand_C
// Size: 0x448 (Inherited: 0x448)
struct APowerup_BandageOnHand_C : APowerup_Base_C {
};

