// BlueprintGeneratedClass DmgTypeFire_JerryCan.DmgTypeFire_JerryCan_C
// Size: 0x100 (Inherited: 0x100)
struct UDmgTypeFire_JerryCan_C : UTslDamageType {
};

