// BlueprintGeneratedClass BP_RevivalTransmitter.BP_RevivalTransmitter_C
// Size: 0x160 (Inherited: 0x160)
struct UBP_RevivalTransmitter_C : U*8a7909852f {
};

