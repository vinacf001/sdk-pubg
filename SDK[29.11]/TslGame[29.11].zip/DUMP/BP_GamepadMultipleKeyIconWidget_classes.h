// WidgetBlueprintGeneratedClass BP_GamepadMultipleKeyIconWidget.BP_GamepadMultipleKeyIconWidget_C
// Size: 0x548 (Inherited: 0x528)
struct UBP_GamepadMultipleKeyIconWidget_C : U*9f8efe6c51 {
	struct UImage* PlusImage; // 0x528(0x08)
	struct UImage* PlusImage2; // 0x530(0x08)
	struct UImage* SlashImage; // 0x538(0x08)
	struct UImage* SlashImage2; // 0x540(0x08)
};

