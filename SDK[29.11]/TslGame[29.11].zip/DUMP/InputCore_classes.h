// Class InputCore.*b05cdb4c14
// Size: 0x30 (Inherited: 0x30)
struct U*b05cdb4c14 : UObject {
};

