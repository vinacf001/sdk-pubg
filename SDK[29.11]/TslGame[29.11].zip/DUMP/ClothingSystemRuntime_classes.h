// Class ClothingSystemRuntime.*9553a762fe
// Size: 0x30 (Inherited: 0x30)
struct U*9553a762fe : UObject {
};

// Class ClothingSystemRuntime.ClothingAsset
// Size: 0x160 (Inherited: 0x50)
struct UClothingAsset : U*00b0d3ce78 {
	struct F*b3b8f7e1f6 *b3b8f7e1f6; // 0x50(0xbc)
	char pad_10C[0x4]; // 0x10c(0x04)
	struct TArray<struct F*0a50355043> *db24bbedf0; // 0x110(0x10)
	struct TArray<int32> *e4d79f51c7; // 0x120(0x10)
	struct TArray<struct FName> *31ac041cbd; // 0x130(0x10)
	struct TArray<int32> *5bacc4851f; // 0x140(0x10)
	int32 *2326ef9ff1; // 0x150(0x04)
	char pad_154[0x4]; // 0x154(0x04)
	struct U*9553a762fe* CustomData; // 0x158(0x08)
};

// Class ClothingSystemRuntime.*8169aff6f9
// Size: 0x30 (Inherited: 0x30)
struct U*8169aff6f9 : U*41d1d8804c {
};

