// Class ClothingSystemRuntimeInterface.*00b0d3ce78
// Size: 0x50 (Inherited: 0x30)
struct U*00b0d3ce78 : UObject {
	struct FString *2f1340b1c5; // 0x30(0x10)
	struct FGuid *7b35ebe2e3; // 0x40(0x10)
};

// Class ClothingSystemRuntimeInterface.*41d1d8804c
// Size: 0x30 (Inherited: 0x30)
struct U*41d1d8804c : UObject {
};

