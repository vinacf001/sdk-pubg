// BlueprintGeneratedClass BP_MasteryPose_PanDeflect.BP_MasteryPose_PanDeflect_C
// Size: 0x4a0 (Inherited: 0x440)
struct ABP_MasteryPose_PanDeflect_C : ABP_MasteryPose_C {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x440(0x08)
	struct UAsyncStaticMeshComponent* AsyncStaticMesh3; // 0x448(0x08)
	struct UAsyncStaticMeshComponent* AsyncStaticMesh2; // 0x450(0x08)
	struct UAsyncStaticMeshComponent* PlayerCardPanEffects; // 0x458(0x08)
	struct UAsyncStaticMeshComponent* AsyncStaticMesh; // 0x460(0x08)
	struct U*175d673fff* Pan; // 0x468(0x08)
	struct USpotLightComponent* SpotLightEyes; // 0x470(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x478(0x08)
	struct USpotLightComponent* PlayerCardBulletLight; // 0x480(0x08)
	struct USpotLightComponent* BulletLight; // 0x488(0x08)
	struct USpotLightComponent* LobbySpotLight; // 0x490(0x08)
	struct USpotLightComponent* spotlight; // 0x498(0x08)

	void UserConstructionScript(); // Function BP_MasteryPose_PanDeflect.BP_MasteryPose_PanDeflect_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	void ReceiveBeginPlay(); // Function BP_MasteryPose_PanDeflect.BP_MasteryPose_PanDeflect_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x1dcd78
	int32 ExecuteUbergraph_BP_MasteryPose_PanDeflect(); // Function BP_MasteryPose_PanDeflect.BP_MasteryPose_PanDeflect_C.ExecuteUbergraph_BP_MasteryPose_PanDeflect //  // @ game+0x1dcd78
};

