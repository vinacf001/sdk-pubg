// Class FacialAnimation.*1e4453e6ec
// Size: 0x790 (Inherited: 0x750)
struct U*1e4453e6ec : UAudioComponent {
	char pad_750[0x8]; // 0x750(0x08)
	struct FName CurveSourceBindingName; // 0x758(0x08)
	float CurveSyncOffset; // 0x760(0x04)
	char pad_764[0x2c]; // 0x764(0x2c)
};

