// BlueprintGeneratedClass BP_DefaultTslSingleton.BP_DefaultTslSingleton_C
// Size: 0x12e0 (Inherited: 0x12e0)
struct UBP_DefaultTslSingleton_C : U*21d7aec80c {
};

