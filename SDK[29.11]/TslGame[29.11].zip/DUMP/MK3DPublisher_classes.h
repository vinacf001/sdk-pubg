// Class MK3DPublisher.AudioCapturer
// Size: 0x470 (Inherited: 0x3f0)
struct AAudioCapturer : AActor {
	char pad_3F0[0x80]; // 0x3f0(0x80)
};

// Class MK3DPublisher.*d340a69cdb
// Size: 0x30 (Inherited: 0x30)
struct U*d340a69cdb : UBlueprintFunctionLibrary {

	DelegateProperty *f51f7c3053(); // Function MK3DPublisher.*d340a69cdb.*f51f7c3053 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x67448d0
	void *8239d16133(); // Function MK3DPublisher.*d340a69cdb.*8239d16133 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745d68
	bool *d8fbc089a3(); // Function MK3DPublisher.*d340a69cdb.*d8fbc089a3 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746594
	bool *236c91f525(); // Function MK3DPublisher.*d340a69cdb.*236c91f525 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x67460bc
	DelegateProperty *5b69d3d575(); // Function MK3DPublisher.*d340a69cdb.*5b69d3d575 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6744ad4
	struct FString *3725c796f5(); // Function MK3DPublisher.*d340a69cdb.*3725c796f5 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745634
	float *aade74eb6e(); // Function MK3DPublisher.*d340a69cdb.*aade74eb6e // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x67452d4
	int32 *9faa1720ab(); // Function MK3DPublisher.*d340a69cdb.*9faa1720ab // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745e78
	bool *2a8f3eaa0d(); // Function MK3DPublisher.*d340a69cdb.*2a8f3eaa0d // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745af4
	struct TArray<int32> *2d9e03186b(); // Function MK3DPublisher.*d340a69cdb.*2d9e03186b // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x67456bc
	int32 *c1674adf43(); // Function MK3DPublisher.*d340a69cdb.*c1674adf43 // Final|Native|Static|Public|BlueprintCallable // @ game+0x674557c
	struct TArray<struct FString> *24a6d16d39(); // Function MK3DPublisher.*d340a69cdb.*24a6d16d39 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6745878
	void *72c374ae64(); // Function MK3DPublisher.*d340a69cdb.*72c374ae64 // Final|Native|Static|Public|BlueprintCallable // @ game+0x67462b8
	bool *e6823d6970(); // Function MK3DPublisher.*d340a69cdb.*e6823d6970 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745ad0
	bool *4c312458ba(); // Function MK3DPublisher.*d340a69cdb.*4c312458ba // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746334
	void *e72e52dc8f(); // Function MK3DPublisher.*d340a69cdb.*e72e52dc8f // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745bbc
	struct FString *51a1ac92cc(); // Function MK3DPublisher.*d340a69cdb.*51a1ac92cc // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6745140
	int32 *5635330ad3(); // Function MK3DPublisher.*d340a69cdb.*5635330ad3 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6744f14
	void *0f77220a7b(); // Function MK3DPublisher.*d340a69cdb.*0f77220a7b // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745c1c
	bool *ef40c99ac4(); // Function MK3DPublisher.*d340a69cdb.*ef40c99ac4 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745dcc
	struct TArray<struct FString> *8c667b961f(); // Function MK3DPublisher.*d340a69cdb.*8c667b961f // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x67457c4
	float *8ecc4e4773(); // Function MK3DPublisher.*d340a69cdb.*8ecc4e4773 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745c80
	struct TArray<struct FString> *dd8493fa2a(); // Function MK3DPublisher.*d340a69cdb.*dd8493fa2a // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6746b2c
	int32 *3bedc1c81d(); // Function MK3DPublisher.*d340a69cdb.*3bedc1c81d // Final|Native|Static|Public|BlueprintCallable // @ game+0x6744b80
	float *4ba3798cc7(); // Function MK3DPublisher.*d340a69cdb.*4ba3798cc7 // Final|Native|Static|Public|BlueprintCallable // @ game+0x674560c
	void *62c99f76b0(); // Function MK3DPublisher.*d340a69cdb.*62c99f76b0 // Final|Native|Static|Public|BlueprintCallable // @ game+0x67467f4
	struct FString *8e9944cf63(); // Function MK3DPublisher.*d340a69cdb.*8e9944cf63 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746a30
	void *885f580d45(); // Function MK3DPublisher.*d340a69cdb.*885f580d45 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746320
	bool *66f35dbe77(); // Function MK3DPublisher.*d340a69cdb.*66f35dbe77 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745a6c
	bool *fab4ef9aeb(); // Function MK3DPublisher.*d340a69cdb.*fab4ef9aeb // Final|Native|Static|Public|BlueprintCallable // @ game+0x6744840
	void *b55e7440af(); // Function MK3DPublisher.*d340a69cdb.*b55e7440af // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745b58
	int32 *6d54beafda(); // Function MK3DPublisher.*d340a69cdb.*6d54beafda // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6745038
	int32 *8a00777bc0(); // Function MK3DPublisher.*d340a69cdb.*8a00777bc0 // Final|Native|Static|Public|BlueprintCallable // @ game+0x67455dc
	float *36d810ce16(); // Function MK3DPublisher.*d340a69cdb.*36d810ce16 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6744e84
	bool *82519c6c0e(); // Function MK3DPublisher.*d340a69cdb.*82519c6c0e // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6745f20
	int32 *5c58eaa378(); // Function MK3DPublisher.*d340a69cdb.*5c58eaa378 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6744c98
	struct FString *a7a2f277bc(); // Function MK3DPublisher.*d340a69cdb.*a7a2f277bc // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746948
	float *f5b00bdc7e(); // Function MK3DPublisher.*d340a69cdb.*f5b00bdc7e // Final|Native|Static|Public|BlueprintCallable // @ game+0x6744e5c
	DelegateProperty *1d9afe09f4(); // Function MK3DPublisher.*d340a69cdb.*1d9afe09f4 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6744a28
	int32 *26eefef501(); // Function MK3DPublisher.*d340a69cdb.*26eefef501 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6744dc4
	struct FString *cf6d1c5d08(); // Function MK3DPublisher.*d340a69cdb.*cf6d1c5d08 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6746860
	struct TArray<float> *dec5e093e9(); // Function MK3DPublisher.*d340a69cdb.*dec5e093e9 // Final|Native|Static|Public|BlueprintCallable // @ game+0x674592c
	DelegateProperty *0e1307f80d(); // Function MK3DPublisher.*d340a69cdb.*0e1307f80d // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x674497c
	void *8ccdc3df17(); // Function MK3DPublisher.*d340a69cdb.*8ccdc3df17 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6744fa0
	void *34576e9f63(); // Function MK3DPublisher.*d340a69cdb.*34576e9f63 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6745d04
	struct FString *b12c16bc50(); // Function MK3DPublisher.*d340a69cdb.*b12c16bc50 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x67453e0
};

// Class MK3DPublisher.ViewportCapturer
// Size: 0x488 (Inherited: 0x3f0)
struct AViewportCapturer : AActor {
	char pad_3F0[0x98]; // 0x3f0(0x98)
};

