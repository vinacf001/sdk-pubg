// BlueprintGeneratedClass Powerup_TraumaSyringe.Powerup_TraumaSyringe_C
// Size: 0x458 (Inherited: 0x448)
struct APowerup_TraumaSyringe_C : APowerup_Base_C {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x448(0x08)
	struct F*b2f5f3e08e Timer2Handle; // 0x450(0x08)

	void UserConstructionScript(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	void Throw Syringe Cap Away(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.Throw Syringe Cap Away // BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	void ReceiveDestroyed(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x1dcd78
	float Init Syringe Delay(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.Init Syringe Delay // BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	struct FName ExecuteUbergraph_Powerup_TraumaSyringe(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.ExecuteUbergraph_Powerup_TraumaSyringe // HasDefaults // @ game+0x1dcd78
};

