// WidgetBlueprintGeneratedClass BP_PcOption_SubTabLabelWidget.BP_PcOption_SubTabLabelWidget_C
// Size: 0x468 (Inherited: 0x468)
struct UBP_PcOption_SubTabLabelWidget_C : U*aa580ab1a3 {
};

