// WidgetBlueprintGeneratedClass BP_PubgIdWidget.BP_PubgIdWidget_C
// Size: 0x630 (Inherited: 0x628)
struct UBP_PubgIdWidget_C : U*bd5a2cbd9c {
	struct UTextBlock* PlayerNameText; // 0x628(0x08)
};

