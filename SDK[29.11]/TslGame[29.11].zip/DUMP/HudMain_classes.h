// WidgetBlueprintGeneratedClass HudMain.HudMain_C
// Size: 0x4e0 (Inherited: 0x4e0)
struct UHudMain_C : U*7c63edf398 {
};

