// BlueprintGeneratedClass BP_ItemRequestProjectile.BP_ItemRequestProjectile_C
// Size: 0x6a0 (Inherited: 0x6a0)
struct ABP_ItemRequestProjectile_C : ATslItemRequestProjectile {
};

