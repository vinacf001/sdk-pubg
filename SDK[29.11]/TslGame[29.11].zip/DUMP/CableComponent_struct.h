// ScriptStruct CableComponent.*f0f77a160b
// Size: 0x10 (Inherited: 0x00)
struct F*f0f77a160b {
	int32 ParticleIndex; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FName SocketName; // 0x08(0x08)
};

