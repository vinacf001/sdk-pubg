// BlueprintGeneratedClass Buff_Invulnerablility.Buff_Invulnerablility_C
// Size: 0x480 (Inherited: 0x478)
struct ABuff_Invulnerablility_C : ATslBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x478(0x08)

	void UserConstructionScript(); // Function Buff_Invulnerablility.Buff_Invulnerablility_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
};

