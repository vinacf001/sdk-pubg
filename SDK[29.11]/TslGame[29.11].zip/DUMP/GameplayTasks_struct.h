// Enum GameplayTasks.*27b03ddb1d
enum class *27b03ddb1d : uint8 {
	*a2547b6ee2,
	*d9f5f489a5,
	*34267812d4,
	*27b03ddb1d_MAX,
};

// Enum GameplayTasks.EGameplayTaskRunResult
enum class EGameplayTaskRunResult : uint8 {
	Error,
	Failed,
	Success_Paused,
	Success_Active,
	Success_Finished,
	EGameplayTaskRunResult_MAX,
};

// Enum GameplayTasks.EGameplayTaskState
enum class EGameplayTaskState : uint8 {
	Uninitialized,
	AwaitingActivation,
	Paused,
	Active,
	Finished,
	EGameplayTaskState_MAX,
};

// ScriptStruct GameplayTasks.*dcc564d94b
// Size: 0x02 (Inherited: 0x00)
struct F*dcc564d94b {
	char pad_0[0x2]; // 0x00(0x02)
};

