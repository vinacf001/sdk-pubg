// BlueprintGeneratedClass DmgType_OPChicken.DmgType_OPChicken_C
// Size: 0x100 (Inherited: 0x100)
struct UDmgType_OPChicken_C : UTslDamageType {
};

