// WidgetBlueprintGeneratedClass BP_PcOptionTabContentsWidget.BP_PcOptionTabContentsWidget_C
// Size: 0x458 (Inherited: 0x450)
struct UBP_PcOptionTabContentsWidget_C : U*766eca1edd {
	struct UWidgetSwitcher* SubTabContentSwitcher; // 0x450(0x08)
};

