// BlueprintGeneratedClass Powerup_AidKit.Powerup_AidKit_C
// Size: 0x458 (Inherited: 0x448)
struct APowerup_AidKit_C : APowerup_Base_C {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x448(0x08)
	struct F*b2f5f3e08e Timer2Handle; // 0x450(0x08)

	void UserConstructionScript(); // Function Powerup_AidKit.Powerup_AidKit_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	void ReceiveBeginPlay(); // Function Powerup_AidKit.Powerup_AidKit_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x1dcd78
	void ReceiveDestroyed(); // Function Powerup_AidKit.Powerup_AidKit_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x1dcd78
	void CustomEvent_1(); // Function Powerup_AidKit.Powerup_AidKit_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	bool ExecuteUbergraph_Powerup_AidKit(); // Function Powerup_AidKit.Powerup_AidKit_C.ExecuteUbergraph_Powerup_AidKit // HasDefaults // @ game+0x1dcd78
};

