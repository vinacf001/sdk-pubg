// Class HTML5Networking.WebSocketConnection
// Size: 0x65860 (Inherited: 0x65850)
struct UWebSocketConnection : UNetConnection {
	char pad_65850[0x10]; // 0x65850(0x10)
};

// Class HTML5Networking.WebSocketNetDriver
// Size: 0x4d8 (Inherited: 0x4c8)
struct UWebSocketNetDriver : UNetDriver {
	int32 WebSocketPort; // 0x4c8(0x04)
	char pad_4CC[0xc]; // 0x4cc(0x0c)
};

