// Enum MK3DPublisher.*064cf6fe90
enum class *064cf6fe90 : uint8 {
	*3f3ffe45c6,
	*5bafd42a30,
	*601c075c7d,
	*eda80a6860,
	*064cf6fe90_MAX,
};

