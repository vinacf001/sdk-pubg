// BlueprintGeneratedClass DBX_ForgedWheel.DBX_ForgedWheel_C
// Size: 0x3b0 (Inherited: 0x3b0)
struct UDBX_ForgedWheel_C : U*179c2e5850 {
};

