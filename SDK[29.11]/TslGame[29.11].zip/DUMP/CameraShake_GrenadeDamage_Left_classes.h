// BlueprintGeneratedClass CameraShake_GrenadeDamage_Left.CameraShake_GrenadeDamage_Left_C
// Size: 0x170 (Inherited: 0x170)
struct UCameraShake_GrenadeDamage_Left_C : UCameraShake {
};

