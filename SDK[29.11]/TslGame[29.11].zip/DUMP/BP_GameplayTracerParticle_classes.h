// BlueprintGeneratedClass BP_GameplayTracerParticle.BP_GameplayTracerParticle_C
// Size: 0x4f0 (Inherited: 0x4f0)
struct ABP_GameplayTracerParticle_C : ATslParticle {
};

