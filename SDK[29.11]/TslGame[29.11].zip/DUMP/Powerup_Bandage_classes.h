// BlueprintGeneratedClass Powerup_Bandage.Powerup_Bandage_C
// Size: 0x448 (Inherited: 0x448)
struct APowerup_Bandage_C : APowerup_Base_C {
};

