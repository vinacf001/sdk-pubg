// BlueprintGeneratedClass FBPBuff_GetBoostOnDeal.FBPBuff_GetBoostOnDeal_C
// Size: 0x4a8 (Inherited: 0x4a0)
struct AFBPBuff_GetBoostOnDeal_C : ATslFBRBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4a0(0x08)

	void UserConstructionScript(); // Function FBPBuff_GetBoostOnDeal.FBPBuff_GetBoostOnDeal_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
};

