// Class ACLPlugin.ACLStatsDumpCommandlet
// Size: 0x88 (Inherited: 0x88)
struct UACLStatsDumpCommandlet : UCommandlet {
};

// Class ACLPlugin.AnimCompress_ACLAuto
// Size: 0x50 (Inherited: 0x50)
struct UAnimCompress_ACLAuto : UAnimCompress {
};

// Class ACLPlugin.*1911ce9a49
// Size: 0x50 (Inherited: 0x50)
struct U*1911ce9a49 : UAnimCompress {
};

// Class ACLPlugin.*4315474c99
// Size: 0x68 (Inherited: 0x50)
struct U*4315474c99 : U*1911ce9a49 {
	enum class *ad2370af80 *3757378078; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	float *c71f636049; // 0x54(0x04)
	float *8f794b2d8d; // 0x58(0x04)
	float *c7d7e14991; // 0x5c(0x04)
	float *8da2dd631a; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// Class ACLPlugin.*a3c19cfb8f
// Size: 0x78 (Inherited: 0x50)
struct U*a3c19cfb8f : U*1911ce9a49 {
	float *c71f636049; // 0x50(0x04)
	float *8f794b2d8d; // 0x54(0x04)
	enum class *ad2370af80 *3757378078; // 0x58(0x01)
	enum class *d6ed136a11 *86b2e70509; // 0x59(0x01)
	enum class *c29c2f4c4a *87c033e468; // 0x5a(0x01)
	enum class *c29c2f4c4a *96ea561868; // 0x5b(0x01)
	float *8da2dd631a; // 0x5c(0x04)
	float *589d5f292a; // 0x60(0x04)
	float *d48c4b1a61; // 0x64(0x04)
	float *ee62185dcb; // 0x68(0x04)
	char *aeb0fb0a48 : 1; // 0x6c(0x01)
	char *d8423fe8b1 : 1; // 0x6c(0x01)
	char *7cb10ae296 : 1; // 0x6c(0x01)
	char *dcfede3530 : 1; // 0x6c(0x01)
	char *202e5bb98a : 1; // 0x6c(0x01)
	char *39722d2bcf : 1; // 0x6c(0x01)
	char *aa62d170de : 1; // 0x6c(0x01)
	char pad_6C_7 : 1; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
	uint16 *9433cd4efe; // 0x70(0x02)
	uint16 *e4bf96b856; // 0x72(0x02)
	char pad_74[0x4]; // 0x74(0x04)
};

