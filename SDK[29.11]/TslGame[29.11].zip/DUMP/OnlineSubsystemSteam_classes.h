// Class OnlineSubsystemSteam.SteamNetConnection
// Size: 0x65878 (Inherited: 0x65870)
struct USteamNetConnection : UIpConnection {
	bool *1489b7db99; // 0x65870(0x01)
	char pad_65871[0x7]; // 0x65871(0x07)
};

// Class OnlineSubsystemSteam.SteamNetDriver
// Size: 0x510 (Inherited: 0x4f8)
struct USteamNetDriver : UIpNetDriver {
	char pad_4F8[0x18]; // 0x4f8(0x18)
};

