// WidgetBlueprintGeneratedClass DetailReportCauseManagerWidget.DetailReportCauseManagerWidget_C
// Size: 0x440 (Inherited: 0x440)
struct UDetailReportCauseManagerWidget_C : U*70be0312c2 {
};

