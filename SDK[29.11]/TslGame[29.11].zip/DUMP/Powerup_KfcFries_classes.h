// BlueprintGeneratedClass Powerup_KfcFries.Powerup_KfcFries_C
// Size: 0x458 (Inherited: 0x448)
struct APowerup_KfcFries_C : APowerup_Base_C {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x448(0x08)
	struct F*b2f5f3e08e Timer2Handle; // 0x450(0x08)

	void UserConstructionScript(); // Function Powerup_KfcFries.Powerup_KfcFries_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	void ReceiveBeginPlay(); // Function Powerup_KfcFries.Powerup_KfcFries_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x1dcd78
	void CustomEvent_1(); // Function Powerup_KfcFries.Powerup_KfcFries_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	void ReceiveDestroyed(); // Function Powerup_KfcFries.Powerup_KfcFries_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x1dcd78
	struct ATslCharacter* PlayAnim(); // Function Powerup_KfcFries.Powerup_KfcFries_C.PlayAnim // BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	float ReceiveTick(); // Function Powerup_KfcFries.Powerup_KfcFries_C.ReceiveTick // Event|Public|BlueprintEvent // @ game+0x1dcd78
	void Drop(); // Function Powerup_KfcFries.Powerup_KfcFries_C.Drop // BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	bool ExecuteUbergraph_Powerup_KfcFries(); // Function Powerup_KfcFries.Powerup_KfcFries_C.ExecuteUbergraph_Powerup_KfcFries // HasDefaults // @ game+0x1dcd78
};

