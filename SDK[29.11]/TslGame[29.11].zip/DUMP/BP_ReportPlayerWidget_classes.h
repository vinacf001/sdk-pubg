// WidgetBlueprintGeneratedClass BP_ReportPlayerWidget.BP_ReportPlayerWidget_C
// Size: 0x608 (Inherited: 0x5e0)
struct UBP_ReportPlayerWidget_C : U*cbe030de8f {
	struct UTextBlock* NoSubjectTextBlock; // 0x5e0(0x08)
	struct UTextBlock* TextCancel; // 0x5e8(0x08)
	struct UTextBlock* TextOK; // 0x5f0(0x08)
	struct FMulticastDelegate ButtonEvent; // 0x5f8(0x10)

	enum class *1d74716a1b ButtonEvent__DelegateSignature(); // Function BP_ReportPlayerWidget.BP_ReportPlayerWidget_C.ButtonEvent__DelegateSignature // Public|Delegate|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
};

