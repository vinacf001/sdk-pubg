// BlueprintGeneratedClass GunImpact_Med.GunImpact_Med_C
// Size: 0x12e8 (Inherited: 0x12e0)
struct AGunImpact_Med_C : ATslGunImpact {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x12e0(0x08)

	void UserConstructionScript(); // Function GunImpact_Med.GunImpact_Med_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	int32 ExecuteUbergraph_GunImpact_Med(); // Function GunImpact_Med.GunImpact_Med_C.ExecuteUbergraph_GunImpact_Med //  // @ game+0x1dcd78
};

