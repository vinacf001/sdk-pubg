// WidgetBlueprintGeneratedClass BP_PcOptionHoverWidget.BP_PcOptionHoverWidget_C
// Size: 0x478 (Inherited: 0x468)
struct UBP_PcOptionHoverWidget_C : U*ff1d25560c {
	struct U*3335e92189* Out; // 0x468(0x08)
	struct U*3335e92189* Hover; // 0x470(0x08)
};

