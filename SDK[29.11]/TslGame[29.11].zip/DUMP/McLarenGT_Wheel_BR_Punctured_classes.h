// BlueprintGeneratedClass McLarenGT_Wheel_BR_Punctured.McLarenGT_Wheel_BR_Punctured_C
// Size: 0x3b0 (Inherited: 0x3b0)
struct UMcLarenGT_Wheel_BR_Punctured_C : UMcLarenGT_Wheel_Punctured_C {
};

