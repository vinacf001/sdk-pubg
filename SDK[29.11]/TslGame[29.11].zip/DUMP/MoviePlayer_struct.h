// Enum MoviePlayer.*5ffdeb9eb2
enum class *5ffdeb9eb2 : uint8 {
	*7d2f33d031,
	*19fda5f6ef,
	*65b778a07d,
	*794d9eff7f,
	*5ffdeb9eb2_MAX,
};

