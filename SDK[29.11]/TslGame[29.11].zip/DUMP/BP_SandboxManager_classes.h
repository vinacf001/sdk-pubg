// BlueprintGeneratedClass BP_SandboxManager.BP_SandboxManager_C
// Size: 0x5cc (Inherited: 0x5b0)
struct UBP_SandboxManager_C : U*c2e0d482cc {
	struct UCurveFloat* Flying_Threshold; // 0x5b0(0x08)
	float OldWeight; // 0x5b8(0x04)
	float CurWeight; // 0x5bc(0x04)
	struct UParticleSystemComponent* LocPSC; // 0x5c0(0x08)
	float LocDeltaSeconds; // 0x5c8(0x04)
};

