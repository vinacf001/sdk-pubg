// BlueprintGeneratedClass DBX_ForgedWheel_Punctured_FL.DBX_ForgedWheel_Punctured_FL_C
// Size: 0x3b0 (Inherited: 0x3b0)
struct UDBX_ForgedWheel_Punctured_FL_C : UDBX_ForgedWheel_Punctured_C {
};

