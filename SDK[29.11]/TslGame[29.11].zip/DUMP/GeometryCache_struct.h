// ScriptStruct GeometryCache.*602e71b095
// Size: 0x50 (Inherited: 0x00)
struct F*602e71b095 {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct GeometryCache.*faa0ac8f34
// Size: 0x50 (Inherited: 0x00)
struct F*faa0ac8f34 {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct GeometryCache.*eab8b4ea34
// Size: 0x0c (Inherited: 0x00)
struct F*eab8b4ea34 {
	char pad_0[0xc]; // 0x00(0x0c)
};

