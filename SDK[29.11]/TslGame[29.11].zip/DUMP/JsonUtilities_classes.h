// Class JsonUtilities.*234db94519
// Size: 0x30 (Inherited: 0x30)
struct U*234db94519 : UObject {
};

