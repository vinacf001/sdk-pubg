// WidgetBlueprintGeneratedClass BP_FlowTextWidget.BP_FlowTextWidget_C
// Size: 0x450 (Inherited: 0x450)
struct UBP_FlowTextWidget_C : U*d426ac14c0 {
};

