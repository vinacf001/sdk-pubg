// BlueprintGeneratedClass LobbyPostPorcessEffect.LobbyPostPorcessEffect_C
// Size: 0x480 (Inherited: 0x478)
struct ALobbyPostPorcessEffect_C : ATslPostProcessEffect {
	struct USceneComponent* DefaultSceneRoot; // 0x478(0x08)

	void UserConstructionScript(); // Function LobbyPostPorcessEffect.LobbyPostPorcessEffect_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
};

