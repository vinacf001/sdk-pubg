// BlueprintGeneratedClass Powerup_SelfRevive.Powerup_SelfRevive_C
// Size: 0x450 (Inherited: 0x448)
struct APowerup_SelfRevive_C : APowerup_Base_C {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x448(0x08)

	void UserConstructionScript(); // Function Powerup_SelfRevive.Powerup_SelfRevive_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
	void ReceiveBeginPlay(); // Function Powerup_SelfRevive.Powerup_SelfRevive_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x1dcd78
	int32 ExecuteUbergraph_Powerup_SelfRevive(); // Function Powerup_SelfRevive.Powerup_SelfRevive_C.ExecuteUbergraph_Powerup_SelfRevive //  // @ game+0x1dcd78
};

