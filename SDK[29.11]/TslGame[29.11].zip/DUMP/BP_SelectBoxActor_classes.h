// BlueprintGeneratedClass BP_SelectBoxActor.BP_SelectBoxActor_C
// Size: 0x400 (Inherited: 0x3f0)
struct ABP_SelectBoxActor_C : AActor {
	struct UStaticMeshComponent* StaticMesh; // 0x3f0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x3f8(0x08)

	void UserConstructionScript(); // Function BP_SelectBoxActor.BP_SelectBoxActor_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1dcd78
};

