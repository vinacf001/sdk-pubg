// WidgetBlueprintGeneratedClass HoldableKeyImageWIdgetBP.HoldableKeyImageWidgetBP_C
// Size: 0x4d0 (Inherited: 0x4d0)
struct UHoldableKeyImageWidgetBP_C : U*832c7aefcc {
};

