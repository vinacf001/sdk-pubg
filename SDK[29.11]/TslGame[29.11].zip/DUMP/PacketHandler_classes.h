// Class PacketHandler.*8da8a44e5c
// Size: 0x30 (Inherited: 0x30)
struct U*8da8a44e5c : UObject {
};

