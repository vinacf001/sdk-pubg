// BlueprintGeneratedClass DBX_RibbonWheel_FL.DBX_RibbonWheel_FL_C
// Size: 0x3b0 (Inherited: 0x3b0)
struct UDBX_RibbonWheel_FL_C : UDBX_RibbonWheel_C {
};

