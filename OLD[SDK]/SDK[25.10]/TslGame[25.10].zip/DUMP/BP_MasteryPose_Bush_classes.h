// BlueprintGeneratedClass BP_MasteryPose_Bush.BP_MasteryPose_Bush_C
// Size: 0x460 (Inherited: 0x448)
struct ABP_MasteryPose_Bush_C : ABP_MasteryPose_C {
	struct UAsyncStaticMeshComponent* GrassMesh; // 0x448(0x08)
	struct UAsyncStaticMeshComponent* BushMesh; // 0x450(0x08)
	struct USpotLightComponent* spotlight; // 0x458(0x08)

	void UserConstructionScript(); // Function BP_MasteryPose_Bush.BP_MasteryPose_Bush_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

