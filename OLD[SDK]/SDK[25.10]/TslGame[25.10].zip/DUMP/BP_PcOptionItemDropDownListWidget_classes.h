// WidgetBlueprintGeneratedClass BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C
// Size: 0x8c8 (Inherited: 0x898)
struct UBP_PcOptionItemDropDownListWidget_C : U*befee03514 {
	struct F*abc8f374e0 UberGraphFrame; // 0x898(0x08)
	struct U*692e3f208b* ComboBox; // 0x8a0(0x08)
	struct UButton* ComboBoxButton; // 0x8a8(0x08)
	struct USizeBox* IndentationSizeBox; // 0x8b0(0x08)
	struct FMulticastDelegate OnSelectionChanged; // 0x8b8(0x10)

	enum class ESelectInfo BndEvt__ComboBox_K2Node_ComponentBoundEvent_21_OnSelectionChangedEvent__DelegateSignature(); // Function BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C.BndEvt__ComboBox_K2Node_ComponentBoundEvent_21_OnSelectionChangedEvent__DelegateSignature // BlueprintEvent // @ game+0x2ad9d8
	enum class ESelectInfo ExecuteUbergraph_BP_PcOptionItemDropDownListWidget(); // Function BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C.ExecuteUbergraph_BP_PcOptionItemDropDownListWidget //  // @ game+0x2ad9d8
	enum class ESelectInfo OnSelectionChanged__DelegateSignature(); // Function BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C.OnSelectionChanged__DelegateSignature // Public|Delegate|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

