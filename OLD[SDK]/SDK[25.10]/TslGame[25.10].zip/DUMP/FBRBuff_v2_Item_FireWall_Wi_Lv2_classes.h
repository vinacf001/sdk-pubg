// BlueprintGeneratedClass FBRBuff_v2_Item_FireWall_Wi_Lv2.FBRBuff_v2_Item_FireWall_Wi_Lv2_C
// Size: 0x4d0 (Inherited: 0x4c8)
struct AFBRBuff_v2_Item_FireWall_Wi_Lv2_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4c8(0x08)

	void UserConstructionScript(); // Function FBRBuff_v2_Item_FireWall_Wi_Lv2.FBRBuff_v2_Item_FireWall_Wi_Lv2_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

