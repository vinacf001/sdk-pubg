// BlueprintGeneratedClass BP_HAS_BombController_BP.BP_HAS_BombController_BP_C
// Size: 0x488 (Inherited: 0x488)
struct ABP_HAS_BombController_BP_C : ATslAnimSpawnSkeletalObject {
};

