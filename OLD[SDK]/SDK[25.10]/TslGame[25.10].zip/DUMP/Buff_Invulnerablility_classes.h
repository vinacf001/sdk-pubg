// BlueprintGeneratedClass Buff_Invulnerablility.Buff_Invulnerablility_C
// Size: 0x488 (Inherited: 0x480)
struct ABuff_Invulnerablility_C : ATslBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x480(0x08)

	void UserConstructionScript(); // Function Buff_Invulnerablility.Buff_Invulnerablility_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

