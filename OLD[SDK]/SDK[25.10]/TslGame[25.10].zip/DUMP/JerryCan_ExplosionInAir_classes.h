// BlueprintGeneratedClass JerryCan_ExplosionInAir.JerryCan_ExplosionInAir_C
// Size: 0x1108 (Inherited: 0x1108)
struct AJerryCan_ExplosionInAir_C : ATslExplosionEffect {

	bool UserConstructionScript(); // Function JerryCan_ExplosionInAir.JerryCan_ExplosionInAir_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

