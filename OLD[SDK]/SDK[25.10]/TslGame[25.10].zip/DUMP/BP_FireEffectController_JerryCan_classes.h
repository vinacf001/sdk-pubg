// BlueprintGeneratedClass BP_FireEffectController_JerryCan.BP_FireEffectController_JerryCan_C
// Size: 0x5f0 (Inherited: 0x5f0)
struct ABP_FireEffectController_JerryCan_C : ATslEffectController {
};

