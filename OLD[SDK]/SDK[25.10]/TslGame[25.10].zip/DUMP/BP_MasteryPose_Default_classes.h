// BlueprintGeneratedClass BP_MasteryPose_Default.BP_MasteryPose_Default_C
// Size: 0x460 (Inherited: 0x448)
struct ABP_MasteryPose_Default_C : ABP_MasteryPose_C {
	struct USpotLightComponent* SpotLightEyes; // 0x448(0x08)
	struct USpotLightComponent* LobbySpotLight; // 0x450(0x08)
	struct USpotLightComponent* spotlight; // 0x458(0x08)

	void UserConstructionScript(); // Function BP_MasteryPose_Default.BP_MasteryPose_Default_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

