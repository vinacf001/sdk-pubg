// WidgetBlueprintGeneratedClass LobbyNameTagHUD.LobbyNameTagHUD_C
// Size: 0x460 (Inherited: 0x460)
struct ULobbyNameTagHUD_C : U*93a25d4218 {

	int32 CleanUpNameTagWidget(); // Function LobbyNameTagHUD.LobbyNameTagHUD_C.CleanUpNameTagWidget // Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
	int32 SetupNameTagWidget(); // Function LobbyNameTagHUD.LobbyNameTagHUD_C.SetupNameTagWidget // Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
	struct U*dbd2366bbb* GetNameTagWidget(); // Function LobbyNameTagHUD.LobbyNameTagHUD_C.GetNameTagWidget // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

