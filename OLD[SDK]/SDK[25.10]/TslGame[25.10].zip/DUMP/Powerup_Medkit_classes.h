// BlueprintGeneratedClass Powerup_Medkit.Powerup_Medkit_C
// Size: 0x450 (Inherited: 0x450)
struct APowerup_Medkit_C : APowerup_Base_C {
};

