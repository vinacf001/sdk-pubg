// BlueprintGeneratedClass BP_ViewModeStudio.BP_ViewModeStudio_C
// Size: 0x468 (Inherited: 0x460)
struct ABP_ViewModeStudio_C : AViewModeStudio {
	struct F*abc8f374e0 UberGraphFrame; // 0x460(0x08)

	void UserConstructionScript(); // Function BP_ViewModeStudio.BP_ViewModeStudio_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
	struct AActor* SetViewModeAbleActor(); // Function BP_ViewModeStudio.BP_ViewModeStudio_C.SetViewModeAbleActor // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
	struct AActor* ExecuteUbergraph_BP_ViewModeStudio(); // Function BP_ViewModeStudio.BP_ViewModeStudio_C.ExecuteUbergraph_BP_ViewModeStudio //  // @ game+0x2ad9d8
};

