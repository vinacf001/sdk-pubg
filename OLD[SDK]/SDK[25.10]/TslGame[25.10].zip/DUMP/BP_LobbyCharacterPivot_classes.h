// BlueprintGeneratedClass BP_LobbyCharacterPivot.BP_LobbyCharacterPivot_C
// Size: 0x420 (Inherited: 0x418)
struct ABP_LobbyCharacterPivot_C : ALobbyCharacterPivot {
	struct USceneComponent* DefaultSceneRoot; // 0x418(0x08)

	void UserConstructionScript(); // Function BP_LobbyCharacterPivot.BP_LobbyCharacterPivot_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

