// BlueprintGeneratedClass Powerup_AdrenalineSyringe.Powerup_AdrenalineSyringe_C
// Size: 0x460 (Inherited: 0x450)
struct APowerup_AdrenalineSyringe_C : APowerup_Base_C {
	struct F*abc8f374e0 UberGraphFrame; // 0x450(0x08)
	struct F*da672abddc Timer2Handle; // 0x458(0x08)

	void UserConstructionScript(); // Function Powerup_AdrenalineSyringe.Powerup_AdrenalineSyringe_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
	void ReceiveBeginPlay(); // Function Powerup_AdrenalineSyringe.Powerup_AdrenalineSyringe_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x2ad9d8
	void CustomEvent_1(); // Function Powerup_AdrenalineSyringe.Powerup_AdrenalineSyringe_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
	void ReceiveDestroyed(); // Function Powerup_AdrenalineSyringe.Powerup_AdrenalineSyringe_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x2ad9d8
	bool ExecuteUbergraph_Powerup_AdrenalineSyringe(); // Function Powerup_AdrenalineSyringe.Powerup_AdrenalineSyringe_C.ExecuteUbergraph_Powerup_AdrenalineSyringe // HasDefaults // @ game+0x2ad9d8
};

