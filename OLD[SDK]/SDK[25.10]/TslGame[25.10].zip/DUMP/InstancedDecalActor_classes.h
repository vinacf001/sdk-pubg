// BlueprintGeneratedClass InstancedDecalActor.InstancedDecalActor_C
// Size: 0x400 (Inherited: 0x400)
struct AInstancedDecalActor_C : ADecalActor {
};

