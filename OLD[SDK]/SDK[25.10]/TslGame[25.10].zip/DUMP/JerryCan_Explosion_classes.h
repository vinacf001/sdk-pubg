// BlueprintGeneratedClass JerryCan_Explosion.JerryCan_Explosion_C
// Size: 0x1108 (Inherited: 0x1108)
struct AJerryCan_Explosion_C : ATslExplosionEffect {
};

