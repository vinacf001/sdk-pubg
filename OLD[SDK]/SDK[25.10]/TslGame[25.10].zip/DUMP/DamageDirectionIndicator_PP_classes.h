// BlueprintGeneratedClass DamageDirectionIndicator_PP.DamageDirectionIndicator_PP_C
// Size: 0x490 (Inherited: 0x480)
struct ADamageDirectionIndicator_PP_C : ATslPostProcessEffect {
	struct F*abc8f374e0 UberGraphFrame; // 0x480(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x488(0x08)

	void UserConstructionScript(); // Function DamageDirectionIndicator_PP.DamageDirectionIndicator_PP_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
	int32 ExecuteUbergraph_DamageDirectionIndicator_PP(); // Function DamageDirectionIndicator_PP.DamageDirectionIndicator_PP_C.ExecuteUbergraph_DamageDirectionIndicator_PP //  // @ game+0x2ad9d8
};

