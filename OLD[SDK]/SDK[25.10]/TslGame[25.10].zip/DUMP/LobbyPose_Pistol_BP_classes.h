// BlueprintGeneratedClass LobbyPose_Pistol_BP.LobbyPose_Pistol_BP_C
// Size: 0x488 (Inherited: 0x488)
struct ALobbyPose_Pistol_BP_C : ATslAnimSpawnSkeletalObject {
};

