// BlueprintGeneratedClass FBRBuff2021_Item_Bolt_ra_lv2.FBRBuff2021_Item_Bolt_ra_lv2_C
// Size: 0x4d0 (Inherited: 0x4c8)
struct AFBRBuff2021_Item_Bolt_ra_lv2_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4c8(0x08)

	void UserConstructionScript(); // Function FBRBuff2021_Item_Bolt_ra_lv2.FBRBuff2021_Item_Bolt_ra_lv2_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

