// BlueprintGeneratedClass FBPBuff_v2_IncreaseMaxHp.FBPBuff_v2_IncreaseMaxHp_C
// Size: 0x4b0 (Inherited: 0x4a8)
struct AFBPBuff_v2_IncreaseMaxHp_C : ATslIncreaseMaxHpBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4a8(0x08)

	void UserConstructionScript(); // Function FBPBuff_v2_IncreaseMaxHp.FBPBuff_v2_IncreaseMaxHp_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

