// BlueprintGeneratedClass LobbyVehicleSequenceActor.LobbyVehicleSequenceActor_C
// Size: 0x4c8 (Inherited: 0x4c8)
struct ALobbyVehicleSequenceActor_C : ATslLobbyLevelVehicleSequenceActor {
};

