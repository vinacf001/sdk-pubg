// BlueprintGeneratedClass BP_Impact_DronePackage.BP_Impact_DronePackage_C
// Size: 0x12e8 (Inherited: 0x12e0)
struct ABP_Impact_DronePackage_C : ATslImpactEffect {
	struct UParticleSystem* FleshFX; // 0x12e0(0x08)

	bool UserConstructionScript(); // Function BP_Impact_DronePackage.BP_Impact_DronePackage_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

