// BlueprintGeneratedClass M_OutPlayArea2.M_OutPlayArea2_C
// Size: 0x490 (Inherited: 0x480)
struct AM_OutPlayArea2_C : ATslPostProcessEffect {
	struct F*abc8f374e0 UberGraphFrame; // 0x480(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x488(0x08)

	void UserConstructionScript(); // Function M_OutPlayArea2.M_OutPlayArea2_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
	float OnSetEffectParameter(); // Function M_OutPlayArea2.M_OutPlayArea2_C.OnSetEffectParameter // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x2ad9d8
	bool ExecuteUbergraph_M_OutPlayArea2(); // Function M_OutPlayArea2.M_OutPlayArea2_C.ExecuteUbergraph_M_OutPlayArea2 //  // @ game+0x2ad9d8
};

