// BlueprintGeneratedClass BP_Vantage_LGD.BP_Vantage_LGD_C
// Size: 0x1020 (Inherited: 0x1010)
struct ABP_Vantage_LGD_C : ABP_Vantage_C {
	struct U*fb6e32e66e* VehicleSpecialActionInteraction; // 0x1010(0x08)
	struct UStaticMeshComponent* Windscreen_Special; // 0x1018(0x08)

	void UserConstructionScript(); // Function BP_Vantage_LGD.BP_Vantage_LGD_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

