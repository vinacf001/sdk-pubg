// BlueprintGeneratedClass BP_ZombiePOV_PP.BP_ZombiePOV_PP_C
// Size: 0x488 (Inherited: 0x480)
struct ABP_ZombiePOV_PP_C : ATslPostProcessEffect {
	struct USceneComponent* DefaultSceneRoot; // 0x480(0x08)

	void UserConstructionScript(); // Function BP_ZombiePOV_PP.BP_ZombiePOV_PP_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

