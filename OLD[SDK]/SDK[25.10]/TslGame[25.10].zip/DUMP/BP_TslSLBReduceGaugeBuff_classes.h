// BlueprintGeneratedClass BP_TslSLBReduceGaugeBuff.BP_TslSLBReduceGaugeBuff_C
// Size: 0x4b0 (Inherited: 0x4a8)
struct ABP_TslSLBReduceGaugeBuff_C : ATslFBRBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4a8(0x08)

	void UserConstructionScript(); // Function BP_TslSLBReduceGaugeBuff.BP_TslSLBReduceGaugeBuff_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

