// BlueprintGeneratedClass BP_SelectBoxActor.BP_SelectBoxActor_C
// Size: 0x408 (Inherited: 0x3f8)
struct ABP_SelectBoxActor_C : AActor {
	struct UStaticMeshComponent* StaticMesh; // 0x3f8(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x400(0x08)

	void UserConstructionScript(); // Function BP_SelectBoxActor.BP_SelectBoxActor_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

