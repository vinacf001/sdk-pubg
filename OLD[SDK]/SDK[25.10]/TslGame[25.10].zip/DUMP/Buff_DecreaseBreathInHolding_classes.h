// BlueprintGeneratedClass Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C
// Size: 0x4a8 (Inherited: 0x488)
struct ABuff_DecreaseBreathInHolding_C : ACharacterBreathBuff {
	struct F*abc8f374e0 UberGraphFrame; // 0x488(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x490(0x08)
	struct F*dbf31c1c98 BuffClass; // 0x498(0x10)

	struct ATslCharacter* UserConstructionScript(); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
	struct ATslCharacter* TickBuff(); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.TickBuff // Event|Public|BlueprintEvent // @ game+0x2ad9d8
	struct ATslBuff* ExecuteUbergraph_Buff_DecreaseBreathInHolding(); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.ExecuteUbergraph_Buff_DecreaseBreathInHolding //  // @ game+0x2ad9d8
};

