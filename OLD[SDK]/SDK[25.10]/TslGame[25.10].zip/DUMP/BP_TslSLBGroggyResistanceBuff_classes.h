// BlueprintGeneratedClass BP_TslSLBGroggyResistanceBuff.BP_TslSLBGroggyResistanceBuff_C
// Size: 0x4c0 (Inherited: 0x4b8)
struct ABP_TslSLBGroggyResistanceBuff_C : ATslResistanceBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4b8(0x08)

	void UserConstructionScript(); // Function BP_TslSLBGroggyResistanceBuff.BP_TslSLBGroggyResistanceBuff_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

