// BlueprintGeneratedClass Buff_SpeedUp1.Buff_SpeedUp1_C
// Size: 0x494 (Inherited: 0x480)
struct ABuff_SpeedUp1_C : ATslBuff {
	struct F*abc8f374e0 UberGraphFrame; // 0x480(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x488(0x08)
	float AddSpeedUpFactor; // 0x490(0x04)

	void UserConstructionScript(); // Function Buff_SpeedUp1.Buff_SpeedUp1_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
	void StartBuffBlueprint(); // Function Buff_SpeedUp1.Buff_SpeedUp1_C.StartBuffBlueprint // Event|Public|BlueprintEvent // @ game+0x2ad9d8
	bool StopBuffBlueprint(); // Function Buff_SpeedUp1.Buff_SpeedUp1_C.StopBuffBlueprint // Event|Public|BlueprintEvent // @ game+0x2ad9d8
	struct ATslPlayerController* ExecuteUbergraph_Buff_SpeedUp1(); // Function Buff_SpeedUp1.Buff_SpeedUp1_C.ExecuteUbergraph_Buff_SpeedUp1 //  // @ game+0x2ad9d8
};

