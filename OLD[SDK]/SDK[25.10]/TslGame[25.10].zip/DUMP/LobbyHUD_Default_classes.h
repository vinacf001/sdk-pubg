// BlueprintGeneratedClass LobbyHUD_Default.LobbyHUD_Default_C
// Size: 0x1a08 (Inherited: 0x1a00)
struct ALobbyHUD_Default_C : ALobbyHUD {
	struct F*abc8f374e0 UberGraphFrame; // 0x1a00(0x08)

	void UserConstructionScript(); // Function LobbyHUD_Default.LobbyHUD_Default_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
	void ReceivePostBeginPlay(); // Function LobbyHUD_Default.LobbyHUD_Default_C.ReceivePostBeginPlay // Event|Public|BlueprintEvent // @ game+0x2ad9d8
	int32 ExecuteUbergraph_LobbyHUD_Default(); // Function LobbyHUD_Default.LobbyHUD_Default_C.ExecuteUbergraph_LobbyHUD_Default //  // @ game+0x2ad9d8
};

