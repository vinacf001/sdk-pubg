// BlueprintGeneratedClass Buff_BoostHealOverTime.Buff_BoostHealOverTime_C
// Size: 0x4a0 (Inherited: 0x498)
struct ABuff_BoostHealOverTime_C : ABuff_BoostHealOverTime {
	struct USceneComponent* DefaultSceneRoot; // 0x498(0x08)

	void UserConstructionScript(); // Function Buff_BoostHealOverTime.Buff_BoostHealOverTime_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

