// BlueprintGeneratedClass FlyingHelmetProxy.FlyingHelmetProxy_C
// Size: 0x5b0 (Inherited: 0x5b0)
struct AFlyingHelmetProxy_C : ATslFlyingHelmetProxy {
};

