// BlueprintGeneratedClass FBPBuff_MuteSoundOfCharacter.FBPBuff_MuteSoundOfCharacter_C
// Size: 0x4c0 (Inherited: 0x4b8)
struct AFBPBuff_MuteSoundOfCharacter_C : ATslFBRSoundBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4b8(0x08)

	void UserConstructionScript(); // Function FBPBuff_MuteSoundOfCharacter.FBPBuff_MuteSoundOfCharacter_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2ad9d8
};

