// BlueprintGeneratedClass DmgType_Instant.DmgType_Instant_C
// Size: 0xf8 (Inherited: 0xf8)
struct UDmgType_Instant_C : UTslDamageType {
};

