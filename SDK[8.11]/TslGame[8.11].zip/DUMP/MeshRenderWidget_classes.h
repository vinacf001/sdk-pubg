// WidgetBlueprintGeneratedClass MeshRenderWidget.MeshRenderWidget_C
// Size: 0x260 (Inherited: 0x250)
struct UMeshRenderWidget_C : UUserWidget {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x250(0x08)
	struct UImage* MeshRenderImage; // 0x258(0x08)

	void Construct(); // Function MeshRenderWidget.MeshRenderWidget_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x293938
	void ExecuteUbergraph_MeshRenderWidget(); // Function MeshRenderWidget.MeshRenderWidget_C.ExecuteUbergraph_MeshRenderWidget //  // @ game+0x293938
};

