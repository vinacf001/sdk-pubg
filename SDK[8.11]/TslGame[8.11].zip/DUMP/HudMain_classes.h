// WidgetBlueprintGeneratedClass HudMain.HudMain_C
// Size: 0x4d8 (Inherited: 0x4d8)
struct UHudMain_C : U*7c63edf398 {
};

