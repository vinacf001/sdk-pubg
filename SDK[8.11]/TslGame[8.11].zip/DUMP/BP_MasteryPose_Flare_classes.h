// BlueprintGeneratedClass BP_MasteryPose_Flare.BP_MasteryPose_Flare_C
// Size: 0x468 (Inherited: 0x438)
struct ABP_MasteryPose_Flare_C : ABP_MasteryPose_C {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x438(0x08)
	struct USpotLightComponent* spotlight; // 0x440(0x08)
	struct UPointLightComponent* PointLight; // 0x448(0x08)
	struct UParticleSystemComponent* ParticleSystemPlayerCard; // 0x450(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x458(0x08)
	struct USkeletalMeshComponent* FlareMesh; // 0x460(0x08)

	void UserConstructionScript(); // Function BP_MasteryPose_Flare.BP_MasteryPose_Flare_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
	void AttachObjects(); // Function BP_MasteryPose_Flare.BP_MasteryPose_Flare_C.AttachObjects // Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
	struct FPoseCharacterAttachments ExecuteUbergraph_BP_MasteryPose_Flare(); // Function BP_MasteryPose_Flare.BP_MasteryPose_Flare_C.ExecuteUbergraph_BP_MasteryPose_Flare // HasDefaults // @ game+0x293938
};

