// BlueprintGeneratedClass DmgType_Groggy.DmgType_Groggy_C
// Size: 0xf8 (Inherited: 0xf8)
struct UDmgType_Groggy_C : UTslDamageType {
};

