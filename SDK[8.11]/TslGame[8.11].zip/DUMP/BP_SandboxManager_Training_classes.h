// BlueprintGeneratedClass BP_SandboxManager_Training.BP_SandboxManager_Training_C
// Size: 0x5c0 (Inherited: 0x5c0)
struct UBP_SandboxManager_Training_C : U*db3f6a4437 {
};

