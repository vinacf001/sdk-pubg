// BlueprintGeneratedClass BP_DirectMessageManager.BP_DirectMessageManager_C
// Size: 0x230 (Inherited: 0x230)
struct UBP_DirectMessageManager_C : U*862511bbce {
};

