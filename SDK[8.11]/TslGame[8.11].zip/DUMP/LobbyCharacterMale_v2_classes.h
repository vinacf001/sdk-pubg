// BlueprintGeneratedClass LobbyCharacterMale_v2.LobbyCharacterMale_v2_C
// Size: 0xde0 (Inherited: 0xde0)
struct ALobbyCharacterMale_v2_C : ALobbyCharacterBase_v2_C {
};

