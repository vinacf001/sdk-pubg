// UserDefinedStruct PoseCharacterAttachments.PoseCharacterAttachments
// Size: 0x10 (Inherited: 0x00)
struct FPoseCharacterAttachments {
	struct USceneComponent* Component_2_B4D8E7E24EE39E5CD0B044B226EF8D0C; // 0x00(0x08)
	struct FName SocketName_5_B4FDAA2D4655317EE5253F8A009EC469; // 0x08(0x08)
};

