// BlueprintGeneratedClass FBRBuff2021_Flare_wi_lv2.FBRBuff2021_Flare_wi_lv2_C
// Size: 0x4c0 (Inherited: 0x4b8)
struct AFBRBuff2021_Flare_wi_lv2_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4b8(0x08)

	void UserConstructionScript(); // Function FBRBuff2021_Flare_wi_lv2.FBRBuff2021_Flare_wi_lv2_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
};

