// BlueprintGeneratedClass BP_Vantage_LGD.BP_Vantage_LGD_C
// Size: 0x1010 (Inherited: 0x1000)
struct ABP_Vantage_LGD_C : ABP_Vantage_C {
	struct U*c50ade3878* VehicleSpecialActionInteraction; // 0x1000(0x08)
	struct UStaticMeshComponent* Windscreen_Special; // 0x1008(0x08)

	void UserConstructionScript(); // Function BP_Vantage_LGD.BP_Vantage_LGD_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
};

