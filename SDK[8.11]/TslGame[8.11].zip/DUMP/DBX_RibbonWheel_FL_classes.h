// BlueprintGeneratedClass DBX_RibbonWheel_FL.DBX_RibbonWheel_FL_C
// Size: 0x3a8 (Inherited: 0x3a8)
struct UDBX_RibbonWheel_FL_C : UDBX_RibbonWheel_C {
};

