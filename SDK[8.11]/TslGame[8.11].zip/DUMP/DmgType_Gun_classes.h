// BlueprintGeneratedClass DmgType_Gun.DmgType_Gun_C
// Size: 0xf8 (Inherited: 0xf8)
struct UDmgType_Gun_C : UTslDamageType {
};

