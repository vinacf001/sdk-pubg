// BlueprintGeneratedClass FBRBuff_Medikit_pa_lv1.FBRBuff_Medikit_pa_lv1_C
// Size: 0x4c0 (Inherited: 0x4b8)
struct AFBRBuff_Medikit_pa_lv1_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4b8(0x08)

	void UserConstructionScript(); // Function FBRBuff_Medikit_pa_lv1.FBRBuff_Medikit_pa_lv1_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
};

