// Enum HoudiniEngineRuntime.*00fdc0735f
enum class *00fdc0735f : uint8 {
	*280cbaaa7d,
	*c26afb087a,
	*65cf44198c,
	*6b4e1cbbe3,
	*00fdc0735f_MAX,
};

// Enum HoudiniEngineRuntime.*4d05d50f4b
enum class *4d05d50f4b : uint8 {
	*db344fba4c,
	*4bfac50154,
	*41609a628b,
	*5372c90ced,
	*3f53804fae,
	*4d05d50f4b_MAX,
};

// Enum HoudiniEngineRuntime.*8e1272711b
enum class *8e1272711b : uint8 {
	*7561fe6c60,
	*2105e51c34,
	*996b2a3512,
	*8e1272711b_MAX,
};

// Enum HoudiniEngineRuntime.*18222d9c8c
enum class *18222d9c8c : uint8 {
	*dc77e82922,
	*626207e005,
	*e270380e62,
	*9f647505ba,
	*18222d9c8c_MAX,
};

// Enum HoudiniEngineRuntime.*fdc64c1624
enum class *fdc64c1624 : uint8 {
	*60aed6ecae,
	*e96dc58d76,
	*053dd71b7f,
	*f85b29692b,
	*fdc64c1624_MAX,
};

// Enum HoudiniEngineRuntime.*9c128594ff
enum class *9c128594ff : uint8 {
	*416a702961,
	*2421ca2797,
	*00e0027141,
	*097b1ca848,
	*9c128594ff_MAX,
};

// Enum HoudiniEngineRuntime.EHoudiniHandleType
enum class EHoudiniHandleType : uint8 {
	Xform,
	Bounder,
	Unsupported,
	EHoudiniHandleType_MAX,
};

// ScriptStruct HoudiniEngineRuntime.*edb67ecb96
// Size: 0x30 (Inherited: 0x00)
struct F*edb67ecb96 {
	struct FString Name; // 0x00(0x10)
	struct FDirectoryPath path; // 0x10(0x10)
	struct FString ContentDirID; // 0x20(0x10)
};

