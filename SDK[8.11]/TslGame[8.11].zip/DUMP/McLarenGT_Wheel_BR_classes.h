// BlueprintGeneratedClass McLarenGT_Wheel_BR.McLarenGT_Wheel_BR_C
// Size: 0x3a8 (Inherited: 0x3a8)
struct UMcLarenGT_Wheel_BR_C : UMcLarenGT_Wheel_C {
};

