// BlueprintGeneratedClass Powerup_Nipper.Powerup_Nipper_C
// Size: 0x448 (Inherited: 0x440)
struct APowerup_Nipper_C : APowerup_Base_C {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x440(0x08)

	void UserConstructionScript(); // Function Powerup_Nipper.Powerup_Nipper_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
	void ReceiveBeginPlay(); // Function Powerup_Nipper.Powerup_Nipper_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x293938
	void ExecuteUbergraph_Powerup_Nipper(); // Function Powerup_Nipper.Powerup_Nipper_C.ExecuteUbergraph_Powerup_Nipper //  // @ game+0x293938
};

