// BlueprintGeneratedClass DmgTypeExplosion_Vehicle.DmgTypeExplosion_Vehicle_C
// Size: 0xf8 (Inherited: 0xf8)
struct UDmgTypeExplosion_Vehicle_C : UTslDamageType {
};

