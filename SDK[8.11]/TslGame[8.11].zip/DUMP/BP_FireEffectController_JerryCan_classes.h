// BlueprintGeneratedClass BP_FireEffectController_JerryCan.BP_FireEffectController_JerryCan_C
// Size: 0x5e0 (Inherited: 0x5e0)
struct ABP_FireEffectController_JerryCan_C : ATslEffectController {
};

