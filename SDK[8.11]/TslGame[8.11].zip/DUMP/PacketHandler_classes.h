// Class PacketHandler.*8da8a44e5c
// Size: 0x28 (Inherited: 0x28)
struct U*8da8a44e5c : UObject {
};

