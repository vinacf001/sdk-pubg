// WidgetBlueprintGeneratedClass MouseWidgetBP.MouseWidgetBP_C
// Size: 0x468 (Inherited: 0x468)
struct UMouseWidgetBP_C : U*b01c481f96 {
};

