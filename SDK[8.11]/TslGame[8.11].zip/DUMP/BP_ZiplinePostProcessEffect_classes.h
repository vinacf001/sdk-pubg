// BlueprintGeneratedClass BP_ZiplinePostProcessEffect.BP_ZiplinePostProcessEffect_C
// Size: 0x478 (Inherited: 0x470)
struct ABP_ZiplinePostProcessEffect_C : ATslPostProcessEffect {
	struct USceneComponent* DefaultSceneRoot; // 0x470(0x08)

	void UserConstructionScript(); // Function BP_ZiplinePostProcessEffect.BP_ZiplinePostProcessEffect_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
};

