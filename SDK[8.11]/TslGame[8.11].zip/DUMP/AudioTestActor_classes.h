// BlueprintGeneratedClass AudioTestActor.AudioTestActor_C
// Size: 0x3f0 (Inherited: 0x3e8)
struct AAudioTestActor_C : AActor {
	struct USceneComponent* DefaultSceneRoot; // 0x3e8(0x08)

	void PrintDistance(); // Function AudioTestActor.AudioTestActor_C.PrintDistance // Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
	void Destroy(); // Function AudioTestActor.AudioTestActor_C.Destroy // Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
	void PrintText(); // Function AudioTestActor.AudioTestActor_C.PrintText // Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
	struct FString SetSwitch(); // Function AudioTestActor.AudioTestActor_C.SetSwitch // Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
	void SetNextSound(); // Function AudioTestActor.AudioTestActor_C.SetNextSound // Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
	void Retrigger(); // Function AudioTestActor.AudioTestActor_C.Retrigger // Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
	void PlayAudioRetrigger(); // Function AudioTestActor.AudioTestActor_C.PlayAudioRetrigger // Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
	void PlayAudio(); // Function AudioTestActor.AudioTestActor_C.PlayAudio // Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
	void Initialize(); // Function AudioTestActor.AudioTestActor_C.Initialize // Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
	void UserConstructionScript(); // Function AudioTestActor.AudioTestActor_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
};

