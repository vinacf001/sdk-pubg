// BlueprintGeneratedClass BP_EmergencyPickup_ClosedBag.BP_EmergencyPickup_ClosedBag_C
// Size: 0x400 (Inherited: 0x3f8)
struct ABP_EmergencyPickup_ClosedBag_C : ATslEmPickupBag {
	struct UStaticMeshComponent* StaticMesh; // 0x3f8(0x08)

	void UserConstructionScript(); // Function BP_EmergencyPickup_ClosedBag.BP_EmergencyPickup_ClosedBag_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
};

