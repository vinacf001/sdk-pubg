// BlueprintGeneratedClass BP_ShellEvent_Pistol.BP_ShellEvent_Pistol_C
// Size: 0x88 (Inherited: 0x88)
struct UBP_ShellEvent_Pistol_C : U*02828cfc0e {
};

