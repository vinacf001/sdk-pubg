// BlueprintGeneratedClass Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C
// Size: 0x498 (Inherited: 0x478)
struct ABuff_DecreaseBreathInHolding_C : ACharacterBreathBuff {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x478(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x480(0x08)
	struct F*9147081c37 BuffClass; // 0x488(0x10)

	enum class EBreathType UserConstructionScript(); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
	void TickBuff(); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.TickBuff // Event|Public|BlueprintEvent // @ game+0x293938
	bool ExecuteUbergraph_Buff_DecreaseBreathInHolding(int32 EntryPoint, struct APawn* CallFunc__1bfc7d352f_ReturnValue, struct ATslCharacter* K2Node_DynamicCast_AsTsl_Character); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.ExecuteUbergraph_Buff_DecreaseBreathInHolding //  // @ game+0x293938
};

