// WidgetBlueprintGeneratedClass KeyWidgetBP.KeyWidgetBP_C
// Size: 0x560 (Inherited: 0x548)
struct UKeyWidgetBP_C : U*93e455dd98 {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x548(0x08)
	struct UImage* BorderImage; // 0x550(0x08)
	struct UTextBlock* KeyNameTextBlock; // 0x558(0x08)

	void PreConstruct(); // Function KeyWidgetBP.KeyWidgetBP_C.PreConstruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x293938
	struct U*587f12c230* ExecuteUbergraph_KeyWidgetBP(bool ___bool_Variable2, struct FLinearColor K2Node_Select_Default); // Function KeyWidgetBP.KeyWidgetBP_C.ExecuteUbergraph_KeyWidgetBP // HasDefaults // @ game+0x293938
};

