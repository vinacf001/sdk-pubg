// BlueprintGeneratedClass DmgType_BleedOut.DmgType_BleedOut_C
// Size: 0xf8 (Inherited: 0xf8)
struct UDmgType_BleedOut_C : UTslDamageType {
};

