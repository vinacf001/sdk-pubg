// WidgetBlueprintGeneratedClass BP_PcOptionCategoryGroupWidget.BP_PcOptionCategoryGroupWidget_C
// Size: 0x4b0 (Inherited: 0x4b0)
struct UBP_PcOptionCategoryGroupWidget_C : U*058e456364 {
};

