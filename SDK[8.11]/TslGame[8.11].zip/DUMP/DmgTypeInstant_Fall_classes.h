// BlueprintGeneratedClass DmgTypeInstant_Fall.DmgTypeInstant_Fall_C
// Size: 0xf8 (Inherited: 0xf8)
struct UDmgTypeInstant_Fall_C : UDmgType_Instant_C {
};

