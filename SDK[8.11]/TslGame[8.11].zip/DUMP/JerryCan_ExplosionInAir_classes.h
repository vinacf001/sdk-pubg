// BlueprintGeneratedClass JerryCan_ExplosionInAir.JerryCan_ExplosionInAir_C
// Size: 0x10f8 (Inherited: 0x10f8)
struct AJerryCan_ExplosionInAir_C : ATslExplosionEffect {

	void UserConstructionScript(); // Function JerryCan_ExplosionInAir.JerryCan_ExplosionInAir_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
};

