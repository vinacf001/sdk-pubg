// Class ClothingSystemRuntimeInterface.*00b0d3ce78
// Size: 0x48 (Inherited: 0x28)
struct U*00b0d3ce78 : UObject {
	struct FString *2f1340b1c5; // 0x28(0x10)
	struct FGuid *7b35ebe2e3; // 0x38(0x10)
};

// Class ClothingSystemRuntimeInterface.*41d1d8804c
// Size: 0x28 (Inherited: 0x28)
struct U*41d1d8804c : UObject {
};

