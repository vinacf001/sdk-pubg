// WidgetBlueprintGeneratedClass BP_PcOptionItemVolumeSliderWidget.BP_PcOptionItemVolumeSliderWidget_C
// Size: 0x8c0 (Inherited: 0x8b0)
struct UBP_PcOptionItemVolumeSliderWidget_C : U*186d637819 {
	struct USizeBox* IndentationSizeBox; // 0x8b0(0x08)
	struct U*1293241049* TslUniversalInputVisibilitySwitcher_1; // 0x8b8(0x08)
};

