// BlueprintGeneratedClass LobbyCharacterBase_v2.LobbyCharacterBase_v2_C
// Size: 0xde0 (Inherited: 0xde0)
struct ALobbyCharacterBase_v2_C : ALobbyCharacter {
};

