// WidgetBlueprintGeneratedClass HoldableKeyImageWIdgetBP.HoldableKeyImageWidgetBP_C
// Size: 0x4c8 (Inherited: 0x4c8)
struct UHoldableKeyImageWidgetBP_C : U*832c7aefcc {
};

