// BlueprintGeneratedClass Buff_BoostHealOverTime.Buff_BoostHealOverTime_C
// Size: 0x490 (Inherited: 0x488)
struct ABuff_BoostHealOverTime_C : ABuff_BoostHealOverTime {
	struct USceneComponent* DefaultSceneRoot; // 0x488(0x08)

	void UserConstructionScript(); // Function Buff_BoostHealOverTime.Buff_BoostHealOverTime_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
};

