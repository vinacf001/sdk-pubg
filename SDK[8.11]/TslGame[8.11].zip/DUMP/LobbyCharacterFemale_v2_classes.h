// BlueprintGeneratedClass LobbyCharacterFemale_v2.LobbyCharacterFemale_v2_C
// Size: 0xde0 (Inherited: 0xde0)
struct ALobbyCharacterFemale_v2_C : ALobbyCharacterBase_v2_C {
};

