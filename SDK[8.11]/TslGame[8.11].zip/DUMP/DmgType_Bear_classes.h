// BlueprintGeneratedClass DmgType_Bear.DmgType_Bear_C
// Size: 0xf8 (Inherited: 0xf8)
struct UDmgType_Bear_C : UTslDamageType {
};

