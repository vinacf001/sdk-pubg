// WidgetBlueprintGeneratedClass BP_PcOptionSupplementaryPreviewMaterialWidget.BP_PcOptionSupplementaryPreviewMaterialWidget_C
// Size: 0x498 (Inherited: 0x498)
struct UBP_PcOptionSupplementaryPreviewMaterialWidget_C : U*10e3da1836 {
};

