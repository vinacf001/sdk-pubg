// WidgetBlueprintGeneratedClass BP_PcOptionDetailWidget.BP_PcOptionDetailWidget_C
// Size: 0x5e8 (Inherited: 0x5b0)
struct UBP_PcOptionDetailWidget_C : U*c4352ca226 {
	struct F*a3d8ff36c0 UberGraphFrame; // 0x5b0(0x08)
	struct URichTextBlockWidget_C* DescriptionText; // 0x5b8(0x08)
	struct URichTextBlockWidget_C* DetailedDescriptionText; // 0x5c0(0x08)
	struct UTextBlock* DisplayTitleText; // 0x5c8(0x08)
	struct UImage* LinkButtonImage; // 0x5d0(0x08)
	struct USizeBox* SupplementaryWidgetSizeBox; // 0x5d8(0x08)
	struct UWidgetSwitcher* SupplementaryWidgetSwitcher; // 0x5e0(0x08)

	void ExecuteUbergraph_BP_PcOptionDetailWidget(); // Function BP_PcOptionDetailWidget.BP_PcOptionDetailWidget_C.ExecuteUbergraph_BP_PcOptionDetailWidget //  // @ game+0x293938
};

