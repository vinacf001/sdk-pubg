// WidgetBlueprintGeneratedClass LobbyNameTagHUD.LobbyNameTagHUD_C
// Size: 0x458 (Inherited: 0x458)
struct ULobbyNameTagHUD_C : U*6d52358df4 {

	void CleanUpNameTagWidget(); // Function LobbyNameTagHUD.LobbyNameTagHUD_C.CleanUpNameTagWidget // Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
	void SetupNameTagWidget(); // Function LobbyNameTagHUD.LobbyNameTagHUD_C.SetupNameTagWidget // Public|BlueprintCallable|BlueprintEvent // @ game+0x293938
	struct U*396f8af97a* GetNameTagWidget(); // Function LobbyNameTagHUD.LobbyNameTagHUD_C.GetNameTagWidget // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x293938
};

