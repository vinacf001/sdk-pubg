// BlueprintGeneratedClass DmgType_Drown.DmgType_Drown_C
// Size: 0xf8 (Inherited: 0xf8)
struct UDmgType_Drown_C : UTslDamageType {
};

