// BlueprintGeneratedClass McLarenGT_Wheel_BL.McLarenGT_Wheel_BL_C
// Size: 0x3a8 (Inherited: 0x3a8)
struct UMcLarenGT_Wheel_BL_C : UMcLarenGT_Wheel_C {
};

