// BlueprintGeneratedClass CS_AntiLeanLeft.CS_AntiLeanLeft_C
// Size: 0x160 (Inherited: 0x160)
struct UCS_AntiLeanLeft_C : UCameraShake {
};

