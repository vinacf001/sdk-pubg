// BlueprintGeneratedClass M_DBNOPostProcessEffect.M_DBNOPostProcessEffect_C
// Size: 0x478 (Inherited: 0x470)
struct AM_DBNOPostProcessEffect_C : ATslPostProcessEffect {
	struct USceneComponent* DefaultSceneRoot; // 0x470(0x08)

	void UserConstructionScript(); // Function M_DBNOPostProcessEffect.M_DBNOPostProcessEffect_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

