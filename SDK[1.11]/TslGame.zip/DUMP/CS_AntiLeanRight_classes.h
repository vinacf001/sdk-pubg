// BlueprintGeneratedClass CS_AntiLeanRight.CS_AntiLeanRight_C
// Size: 0x160 (Inherited: 0x160)
struct UCS_AntiLeanRight_C : UCS_AntiLeanLeft_C {
};

