// BlueprintGeneratedClass Powerup_TraumaSyringe.Powerup_TraumaSyringe_C
// Size: 0x450 (Inherited: 0x440)
struct APowerup_TraumaSyringe_C : APowerup_Base_C {
	struct F*abc8f374e0 UberGraphFrame; // 0x440(0x08)
	struct F*da672abddc Timer2Handle; // 0x448(0x08)

	void UserConstructionScript(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void Throw Syringe Cap Away(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.Throw Syringe Cap Away // BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void ReceiveDestroyed(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x2cd4ac
	void Init Syringe Delay(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.Init Syringe Delay // BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	bool ExecuteUbergraph_Powerup_TraumaSyringe(float K2Node_CustomEvent_Cap_Throw_Delay, DelegateProperty _61b405a872_OutputDelegate); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.ExecuteUbergraph_Powerup_TraumaSyringe // HasDefaults // @ game+0x2cd4ac
};

