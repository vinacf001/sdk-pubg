// BlueprintGeneratedClass BP_ShellEvent_DMR.BP_ShellEvent_DMR_C
// Size: 0x88 (Inherited: 0x88)
struct UBP_ShellEvent_DMR_C : U*c9c8e931e8 {
};

