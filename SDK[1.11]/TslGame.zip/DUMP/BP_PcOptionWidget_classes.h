// WidgetBlueprintGeneratedClass BP_PcOptionWidget.BP_PcOptionWidget_C
// Size: 0xa60 (Inherited: 0x9d8)
struct UBP_PcOptionWidget_C : U*a2aefa7165 {
	struct U*5a9e6ea43b* ApplyButton; // 0x9d8(0x08)
	struct UBackgroundBlur* BgBlurLayer; // 0x9e0(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget; // 0x9e8(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget_1; // 0x9f0(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget_2; // 0x9f8(0x08)
	struct U*5a9e6ea43b* CancelButton; // 0xa00(0x08)
	struct UTextBlock* CancelText; // 0xa08(0x08)
	struct U*5a9e6ea43b* DefaultButton; // 0xa10(0x08)
	struct UTextBlock* DefaultText; // 0xa18(0x08)
	struct UBP_PcOptionDetailWidget_C* DetailWidget; // 0xa20(0x08)
	struct UHorizontalBox* GamepadApplyButton; // 0xa28(0x08)
	struct UHorizontalBox* GamepadCancelButton; // 0xa30(0x08)
	struct UHorizontalBox* GamepadDefaultButton; // 0xa38(0x08)
	struct UBP_PcOptionInputBlockerWidget_C* InputBlocker; // 0xa40(0x08)
	struct UBP_PcOptionSubTabSelectorWidget_C* SubTabSelectorWidget; // 0xa48(0x08)
	struct UWidgetSwitcher* TabContentSwitcher; // 0xa50(0x08)
	struct UBP_PcOptionTabSelectorWidget_C* TabSelectorWidget; // 0xa58(0x08)
};

