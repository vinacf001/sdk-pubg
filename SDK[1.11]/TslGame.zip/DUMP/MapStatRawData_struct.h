// UserDefinedStruct MapStatRawData.MapStatRawData
// Size: 0x30 (Inherited: 0x00)
struct FMapStatRawData {
	struct TArray<int32> CallCounts_21_1E4A149C4ED100BE09F3B7A4DFAE2BF0; // 0x00(0x10)
	struct TArray<float> InclusiveAvg_16_915CDEF346F9BAE776076EBDFF05FA37; // 0x10(0x10)
	struct TArray<float> InclusiveMax_20_C56D7A7A46996139B7DC36A10A3FA276; // 0x20(0x10)
};

