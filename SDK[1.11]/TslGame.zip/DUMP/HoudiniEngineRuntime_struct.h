// ScriptStruct HoudiniEngineRuntime.*9f2306d7c5
// Size: 0x30 (Inherited: 0x00)
struct F*9f2306d7c5 {
	struct FString Name; // 0x00(0x10)
	struct FDirectoryPath path; // 0x10(0x10)
	struct FString ContentDirID; // 0x20(0x10)
};

