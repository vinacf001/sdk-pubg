// BlueprintGeneratedClass BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C
// Size: 0x688 (Inherited: 0x680)
struct ABP_TslBaseLobbySceneTravel_FadeInOut_C : ATslLobbySceneTravel_FadeInOut {
	struct USceneComponent* DefaultSceneRoot; // 0x680(0x08)

	void UserConstructionScript(); // Function BP_TslBaseLobbySceneTravel_FadeInOut.BP_TslBaseLobbySceneTravel_FadeInOut_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

