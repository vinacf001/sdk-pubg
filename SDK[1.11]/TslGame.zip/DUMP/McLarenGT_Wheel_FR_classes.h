// BlueprintGeneratedClass McLarenGT_Wheel_FR.McLarenGT_Wheel_FR_C
// Size: 0x3a8 (Inherited: 0x3a8)
struct UMcLarenGT_Wheel_FR_C : UMcLarenGT_Wheel_FL_C {
};

