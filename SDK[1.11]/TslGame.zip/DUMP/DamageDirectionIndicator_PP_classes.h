// BlueprintGeneratedClass DamageDirectionIndicator_PP.DamageDirectionIndicator_PP_C
// Size: 0x480 (Inherited: 0x470)
struct ADamageDirectionIndicator_PP_C : ATslPostProcessEffect {
	struct F*abc8f374e0 UberGraphFrame; // 0x470(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x478(0x08)

	void UserConstructionScript(); // Function DamageDirectionIndicator_PP.DamageDirectionIndicator_PP_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void ExecuteUbergraph_DamageDirectionIndicator_PP(); // Function DamageDirectionIndicator_PP.DamageDirectionIndicator_PP_C.ExecuteUbergraph_DamageDirectionIndicator_PP //  // @ game+0x2cd4ac
};

