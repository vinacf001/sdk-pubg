// BlueprintGeneratedClass Powerup_AidKit.Powerup_AidKit_C
// Size: 0x450 (Inherited: 0x440)
struct APowerup_AidKit_C : APowerup_Base_C {
	struct F*abc8f374e0 UberGraphFrame; // 0x440(0x08)
	struct F*da672abddc Timer2Handle; // 0x448(0x08)

	void UserConstructionScript(); // Function Powerup_AidKit.Powerup_AidKit_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void ReceiveBeginPlay(); // Function Powerup_AidKit.Powerup_AidKit_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x2cd4ac
	void ReceiveDestroyed(); // Function Powerup_AidKit.Powerup_AidKit_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x2cd4ac
	void CustomEvent_1(); // Function Powerup_AidKit.Powerup_AidKit_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	struct FName ExecuteUbergraph_Powerup_AidKit(); // Function Powerup_AidKit.Powerup_AidKit_C.ExecuteUbergraph_Powerup_AidKit // HasDefaults // @ game+0x2cd4ac
};

