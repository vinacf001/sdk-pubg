// BlueprintGeneratedClass BP_ItemRequestProjectile.BP_ItemRequestProjectile_C
// Size: 0x690 (Inherited: 0x690)
struct ABP_ItemRequestProjectile_C : ATslItemRequestProjectile {
};

