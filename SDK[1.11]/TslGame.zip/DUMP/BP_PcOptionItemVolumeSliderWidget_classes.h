// WidgetBlueprintGeneratedClass BP_PcOptionItemVolumeSliderWidget.BP_PcOptionItemVolumeSliderWidget_C
// Size: 0x8c0 (Inherited: 0x8b0)
struct UBP_PcOptionItemVolumeSliderWidget_C : U*0d6e75e856 {
	struct USizeBox* IndentationSizeBox; // 0x8b0(0x08)
	struct U*290fc681a4* TslUniversalInputVisibilitySwitcher_1; // 0x8b8(0x08)
};

