// Class OnlineSubsystemSteam.SteamNetConnection
// Size: 0x65870 (Inherited: 0x65868)
struct USteamNetConnection : UIpConnection {
	bool *23bea22325; // 0x65868(0x01)
	char pad_65869[0x7]; // 0x65869(0x07)
};

// Class OnlineSubsystemSteam.SteamNetDriver
// Size: 0x508 (Inherited: 0x4f0)
struct USteamNetDriver : UIpNetDriver {
	char pad_4F0[0x18]; // 0x4f0(0x18)
};

