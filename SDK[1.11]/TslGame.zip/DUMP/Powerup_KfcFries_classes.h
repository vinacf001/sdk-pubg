// BlueprintGeneratedClass Powerup_KfcFries.Powerup_KfcFries_C
// Size: 0x450 (Inherited: 0x440)
struct APowerup_KfcFries_C : APowerup_Base_C {
	struct F*abc8f374e0 UberGraphFrame; // 0x440(0x08)
	struct F*da672abddc Timer2Handle; // 0x448(0x08)

	void UserConstructionScript(); // Function Powerup_KfcFries.Powerup_KfcFries_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void ReceiveBeginPlay(); // Function Powerup_KfcFries.Powerup_KfcFries_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x2cd4ac
	void CustomEvent_1(); // Function Powerup_KfcFries.Powerup_KfcFries_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void ReceiveDestroyed(); // Function Powerup_KfcFries.Powerup_KfcFries_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x2cd4ac
	void PlayAnim(); // Function Powerup_KfcFries.Powerup_KfcFries_C.PlayAnim // BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void ReceiveTick(); // Function Powerup_KfcFries.Powerup_KfcFries_C.ReceiveTick // Event|Public|BlueprintEvent // @ game+0x2cd4ac
	void Drop(); // Function Powerup_KfcFries.Powerup_KfcFries_C.Drop // BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	bool ExecuteUbergraph_Powerup_KfcFries(int32 EntryPoint, struct FName CallFunc__c2f69187f8_ReturnValue, struct ATslCharacter* K2Node_Event_Char_Ref, struct UChar_AnimBP_C* K2Node_DynamicCast_AsChar_Anim_BP); // Function Powerup_KfcFries.Powerup_KfcFries_C.ExecuteUbergraph_Powerup_KfcFries // HasDefaults // @ game+0x2cd4ac
};

