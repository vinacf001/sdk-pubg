// BlueprintGeneratedClass FBRBuff_v2_Meteo_wi_lv5.FBRBuff_v2_Meteo_wi_lv5_C
// Size: 0x4c0 (Inherited: 0x4b8)
struct AFBRBuff_v2_Meteo_wi_lv5_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4b8(0x08)

	void UserConstructionScript(); // Function FBRBuff_v2_Meteo_wi_lv5.FBRBuff_v2_Meteo_wi_lv5_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

