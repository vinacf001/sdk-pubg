// BlueprintGeneratedClass BP_TslSLBDizzinessResistanceBuff.BP_TslSLBDizzinessResistanceBuff_C
// Size: 0x4b0 (Inherited: 0x4a8)
struct ABP_TslSLBDizzinessResistanceBuff_C : ATslResistanceBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4a8(0x08)

	void UserConstructionScript(); // Function BP_TslSLBDizzinessResistanceBuff.BP_TslSLBDizzinessResistanceBuff_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

