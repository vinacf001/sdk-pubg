// BlueprintGeneratedClass DmgTypeExplosion_Grenade.DmgTypeExplosion_Grenade_C
// Size: 0xf8 (Inherited: 0xf8)
struct UDmgTypeExplosion_Grenade_C : UTslDamageType {
};

