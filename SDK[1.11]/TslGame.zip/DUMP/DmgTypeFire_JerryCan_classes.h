// BlueprintGeneratedClass DmgTypeFire_JerryCan.DmgTypeFire_JerryCan_C
// Size: 0xf8 (Inherited: 0xf8)
struct UDmgTypeFire_JerryCan_C : UTslDamageType {
};

