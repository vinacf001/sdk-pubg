// BlueprintGeneratedClass Buff_SpeedUp2.Buff_SpeedUp2_C
// Size: 0x484 (Inherited: 0x470)
struct ABuff_SpeedUp2_C : ATslBuff {
	struct F*abc8f374e0 UberGraphFrame; // 0x470(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x478(0x08)
	float AddSpeedUpFactor; // 0x480(0x04)

	void UserConstructionScript(); // Function Buff_SpeedUp2.Buff_SpeedUp2_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void StartBuffBlueprint(); // Function Buff_SpeedUp2.Buff_SpeedUp2_C.StartBuffBlueprint // Event|Public|BlueprintEvent // @ game+0x2cd4ac
	void StopBuffBlueprint(); // Function Buff_SpeedUp2.Buff_SpeedUp2_C.StopBuffBlueprint // Event|Public|BlueprintEvent // @ game+0x2cd4ac
	struct ATslCharacter* ExecuteUbergraph_Buff_SpeedUp2(bool K2Node_DynamicCast_bSuccess, bool K2Node_Event_bCanceled, struct ATslCharacter* K2Node_DynamicCast_AsTsl_Character2, float CallFunc__f907b55d86_ReturnValue); // Function Buff_SpeedUp2.Buff_SpeedUp2_C.ExecuteUbergraph_Buff_SpeedUp2 //  // @ game+0x2cd4ac
};

