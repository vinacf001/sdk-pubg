// WidgetBlueprintGeneratedClass BP_KillLogViewWidget.BP_KillLogViewWidget_C
// Size: 0x450 (Inherited: 0x438)
struct UBP_KillLogViewWidget_C : U*6df7937d7e {
	struct F*abc8f374e0 UberGraphFrame; // 0x438(0x08)
	struct UButton* Button_1; // 0x440(0x08)
	struct UImage* DebugCrosshair; // 0x448(0x08)

	void BndEvt__Button_0_K2Node_ComponentBoundEvent_116_OnButtonClickedEvent__DelegateSignature(); // Function BP_KillLogViewWidget.BP_KillLogViewWidget_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_116_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x2cd4ac
	struct APlayerController* ExecuteUbergraph_BP_KillLogViewWidget(); // Function BP_KillLogViewWidget.BP_KillLogViewWidget_C.ExecuteUbergraph_BP_KillLogViewWidget //  // @ game+0x2cd4ac
};

