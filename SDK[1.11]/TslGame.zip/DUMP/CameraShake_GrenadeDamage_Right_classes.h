// BlueprintGeneratedClass CameraShake_GrenadeDamage_Right.CameraShake_GrenadeDamage_Right_C
// Size: 0x160 (Inherited: 0x160)
struct UCameraShake_GrenadeDamage_Right_C : UCameraShake {
};

