// WidgetBlueprintGeneratedClass BP_PcOptionItemStepperIndicatorWidget.BP_PcOptionItemStepperIndicatorWidget_C
// Size: 0x4b8 (Inherited: 0x4b8)
struct UBP_PcOptionItemStepperIndicatorWidget_C : U*884afd0a54 {
};

