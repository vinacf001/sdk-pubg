// BlueprintGeneratedClass LobbyPose_Pistol_BP.LobbyPose_Pistol_BP_C
// Size: 0x478 (Inherited: 0x478)
struct ALobbyPose_Pistol_BP_C : ATslAnimSpawnSkeletalObject {
};

