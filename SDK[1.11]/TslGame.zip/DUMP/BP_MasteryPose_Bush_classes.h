// BlueprintGeneratedClass BP_MasteryPose_Bush.BP_MasteryPose_Bush_C
// Size: 0x450 (Inherited: 0x438)
struct ABP_MasteryPose_Bush_C : ABP_MasteryPose_C {
	struct UAsyncStaticMeshComponent* GrassMesh; // 0x438(0x08)
	struct UAsyncStaticMeshComponent* BushMesh; // 0x440(0x08)
	struct USpotLightComponent* spotlight; // 0x448(0x08)

	void UserConstructionScript(); // Function BP_MasteryPose_Bush.BP_MasteryPose_Bush_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

