// BlueprintGeneratedClass Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C
// Size: 0x450 (Inherited: 0x440)
struct APowerup_KfcChicken_Bucket_C : APowerup_Base_C {
	struct F*abc8f374e0 UberGraphFrame; // 0x440(0x08)
	struct F*da672abddc Timer2Handle; // 0x448(0x08)

	void UserConstructionScript(); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void ReceiveBeginPlay(); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x2cd4ac
	void CustomEvent_1(); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void ReceiveDestroyed(); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x2cd4ac
	void PlayAnim(); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.PlayAnim // BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void ReceiveTick(); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.ReceiveTick // Event|Public|BlueprintEvent // @ game+0x2cd4ac
	void Drop(); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.Drop // BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	struct UChar_AnimBP_C* ExecuteUbergraph_Powerup_KfcChicken_Bucket(struct FName CallFunc__c2f69187f8_ReturnValue, struct ATslCharacter* K2Node_Event_Char_Ref, float CallFunc__846c340432_ReturnValue, struct F*da672abddc CallFunc__a1f38c3428_ReturnValue); // Function Powerup_KfcChicken_Bucket.Powerup_KfcChicken_Bucket_C.ExecuteUbergraph_Powerup_KfcChicken_Bucket // HasDefaults // @ game+0x2cd4ac
};

