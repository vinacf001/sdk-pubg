// BlueprintGeneratedClass DmgType_DronePackage.DmgType_DronePackage_C
// Size: 0xf8 (Inherited: 0xf8)
struct UDmgType_DronePackage_C : UTslDamageType {
};

