// BlueprintGeneratedClass DBX_RibbonWheel_Punctured_FR.DBX_RibbonWheel_Punctured_FR_C
// Size: 0x3a8 (Inherited: 0x3a8)
struct UDBX_RibbonWheel_Punctured_FR_C : UDBX_RibbonWheel_Punctured_FL_C {
};

