// WidgetBlueprintGeneratedClass LobbyBlurBackgroundWidjet.LobbyBlurBackgroundWidjet_C
// Size: 0x250 (Inherited: 0x250)
struct ULobbyBlurBackgroundWidjet_C : UUserWidget {
};

