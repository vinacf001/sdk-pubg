// BlueprintGeneratedClass DBX_ForgedWheel.DBX_ForgedWheel_C
// Size: 0x3a8 (Inherited: 0x3a8)
struct UDBX_ForgedWheel_C : U*4a37714075 {
};

