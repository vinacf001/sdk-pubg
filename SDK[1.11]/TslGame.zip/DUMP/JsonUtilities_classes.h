// Class JsonUtilities.*549d3900b5
// Size: 0x28 (Inherited: 0x28)
struct U*549d3900b5 : UObject {
};

