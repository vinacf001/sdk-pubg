// BlueprintGeneratedClass BP_BicycleCastableItem.BP_BicycleCastableItem_C
// Size: 0x98 (Inherited: 0x98)
struct UBP_BicycleCastableItem_C : U*50bdf0645a {
};

