// BlueprintGeneratedClass FBPBuff_IncreaseMaxHp.FBPBuff_IncreaseMaxHp_C
// Size: 0x4a0 (Inherited: 0x498)
struct AFBPBuff_IncreaseMaxHp_C : ATslIncreaseMaxHpBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x498(0x08)

	void UserConstructionScript(); // Function FBPBuff_IncreaseMaxHp.FBPBuff_IncreaseMaxHp_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

