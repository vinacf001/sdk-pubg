// WidgetBlueprintGeneratedClass LobbyNameTagHUD.LobbyNameTagHUD_C
// Size: 0x458 (Inherited: 0x458)
struct ULobbyNameTagHUD_C : U*93a25d4218 {

	void CleanUpNameTagWidget(); // Function LobbyNameTagHUD.LobbyNameTagHUD_C.CleanUpNameTagWidget // Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void SetupNameTagWidget(); // Function LobbyNameTagHUD.LobbyNameTagHUD_C.SetupNameTagWidget // Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	struct U*dbd2366bbb* GetNameTagWidget(int32 SlotIndex); // Function LobbyNameTagHUD.LobbyNameTagHUD_C.GetNameTagWidget // Public|HasOutParms|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

