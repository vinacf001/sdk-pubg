// WidgetBlueprintGeneratedClass KeyImageWIdgetBP.KeyImageWIdgetBP_C
// Size: 0x468 (Inherited: 0x468)
struct UKeyImageWIdgetBP_C : U*7d71d941dd {
};

