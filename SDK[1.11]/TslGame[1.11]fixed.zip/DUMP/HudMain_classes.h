// WidgetBlueprintGeneratedClass HudMain.HudMain_C
// Size: 0x4d8 (Inherited: 0x4d8)
struct UHudMain_C : U*bcb397d1be {
};

