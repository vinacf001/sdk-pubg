// BlueprintGeneratedClass DBX_RibbonWheel_FR.DBX_RibbonWheel_FR_C
// Size: 0x3a8 (Inherited: 0x3a8)
struct UDBX_RibbonWheel_FR_C : UDBX_RibbonWheel_FL_C {
};

