// BlueprintGeneratedClass Powerup_KfcPotato.Powerup_KfcPotato_C
// Size: 0x448 (Inherited: 0x440)
struct APowerup_KfcPotato_C : APowerup_Base_C {
	struct F*da672abddc Timer2Handle; // 0x440(0x08)

	void UserConstructionScript(); // Function Powerup_KfcPotato.Powerup_KfcPotato_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

