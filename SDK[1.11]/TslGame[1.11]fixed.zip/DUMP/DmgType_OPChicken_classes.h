// BlueprintGeneratedClass DmgType_OPChicken.DmgType_OPChicken_C
// Size: 0xf8 (Inherited: 0xf8)
struct UDmgType_OPChicken_C : UTslDamageType {
};

