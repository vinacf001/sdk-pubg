// BlueprintGeneratedClass DBX_ForgedWheel_FR.DBX_ForgedWheel_FR_C
// Size: 0x3a8 (Inherited: 0x3a8)
struct UDBX_ForgedWheel_FR_C : UDBX_ForgedWheel_FL_C {
};

