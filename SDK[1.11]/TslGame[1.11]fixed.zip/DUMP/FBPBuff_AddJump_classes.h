// BlueprintGeneratedClass FBPBuff_AddJump.FBPBuff_AddJump_C
// Size: 0x4a0 (Inherited: 0x498)
struct AFBPBuff_AddJump_C : ATslFBRBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x498(0x08)

	void UserConstructionScript(); // Function FBPBuff_AddJump.FBPBuff_AddJump_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

