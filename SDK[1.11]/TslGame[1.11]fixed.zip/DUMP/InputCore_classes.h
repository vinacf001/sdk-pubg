// Class InputCore.*fea540f4aa
// Size: 0x28 (Inherited: 0x28)
struct U*fea540f4aa : UObject {
};

