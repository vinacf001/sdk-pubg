// BlueprintGeneratedClass CS_Land_Heavy.CS_Land_Heavy_C
// Size: 0x160 (Inherited: 0x160)
struct UCS_Land_Heavy_C : UCameraShake {
};

