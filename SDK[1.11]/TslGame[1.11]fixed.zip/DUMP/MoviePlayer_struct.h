// Enum MoviePlayer.*a1fa1877f7
enum class *a1fa1877f7 : uint8 {
	*8d3a27a566,
	*6ad2125366,
	*7c08ed2412,
	*caba60dc82,
	*a1fa1877f7_MAX,
};

