// BlueprintGeneratedClass BP_BulletproofShield_Castable.BP_BulletproofShield_Castable_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBP_BulletproofShield_Castable_C : U*c4ec8ca559 {
};

