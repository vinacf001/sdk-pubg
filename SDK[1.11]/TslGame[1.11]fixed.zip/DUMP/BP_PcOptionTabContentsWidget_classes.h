// WidgetBlueprintGeneratedClass BP_PcOptionTabContentsWidget.BP_PcOptionTabContentsWidget_C
// Size: 0x450 (Inherited: 0x448)
struct UBP_PcOptionTabContentsWidget_C : U*e9e93be8a5 {
	struct UWidgetSwitcher* SubTabContentSwitcher; // 0x448(0x08)
};

