// BlueprintGeneratedClass Powerup_PutFuel.Powerup_PutFuel_C
// Size: 0x440 (Inherited: 0x440)
struct APowerup_PutFuel_C : APowerup_Base_C {
};

