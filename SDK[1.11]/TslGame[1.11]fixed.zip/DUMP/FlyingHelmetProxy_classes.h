// BlueprintGeneratedClass FlyingHelmetProxy.FlyingHelmetProxy_C
// Size: 0x5a0 (Inherited: 0x5a0)
struct AFlyingHelmetProxy_C : ATslFlyingHelmetProxy {
};

