// BlueprintGeneratedClass DmgType_Fist.DmgType_Fist_C
// Size: 0xf8 (Inherited: 0xf8)
struct UDmgType_Fist_C : UTslDamageType {
};

