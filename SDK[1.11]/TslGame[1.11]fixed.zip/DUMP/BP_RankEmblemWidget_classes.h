// WidgetBlueprintGeneratedClass BP_RankEmblemWidget.BP_RankEmblemWidget_C
// Size: 0x4e8 (Inherited: 0x4e0)
struct UBP_RankEmblemWidget_C : U*1d3b90ef0e {
	struct UImage* EmblemImage; // 0x4e0(0x08)
};

