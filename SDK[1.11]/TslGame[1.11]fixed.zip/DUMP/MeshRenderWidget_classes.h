// WidgetBlueprintGeneratedClass MeshRenderWidget.MeshRenderWidget_C
// Size: 0x260 (Inherited: 0x250)
struct UMeshRenderWidget_C : UUserWidget {
	struct F*abc8f374e0 UberGraphFrame; // 0x250(0x08)
	struct UImage* MeshRenderImage; // 0x258(0x08)

	void Construct(); // Function MeshRenderWidget.MeshRenderWidget_C.Construct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x2cd4ac
	void ExecuteUbergraph_MeshRenderWidget(int32 EntryPoint); // Function MeshRenderWidget.MeshRenderWidget_C.ExecuteUbergraph_MeshRenderWidget //  // @ game+0x2cd4ac
};

