// BlueprintGeneratedClass LootTruckItemSpawnProcessor_Savage_UniqueGunBag.LootTruckItemSpawnProcessor_Savage_UniqueGunBag_C
// Size: 0x130 (Inherited: 0x130)
struct ULootTruckItemSpawnProcessor_Savage_UniqueGunBag_C : U*0cee1dd56f {
};

