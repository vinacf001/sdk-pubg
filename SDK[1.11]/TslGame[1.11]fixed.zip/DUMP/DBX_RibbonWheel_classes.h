// BlueprintGeneratedClass DBX_RibbonWheel.DBX_RibbonWheel_C
// Size: 0x3a8 (Inherited: 0x3a8)
struct UDBX_RibbonWheel_C : U*4a37714075 {
};

