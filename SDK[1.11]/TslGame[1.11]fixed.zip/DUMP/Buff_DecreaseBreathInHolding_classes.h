// BlueprintGeneratedClass Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C
// Size: 0x498 (Inherited: 0x478)
struct ABuff_DecreaseBreathInHolding_C : ACharacterBreathBuff {
	struct F*abc8f374e0 UberGraphFrame; // 0x478(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x480(0x08)
	struct F*dbf31c1c98 BuffClass; // 0x488(0x10)

	enum class EBreathType UserConstructionScript(); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void TickBuff(); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.TickBuff // Event|Public|BlueprintEvent // @ game+0x2cd4ac
	float ExecuteUbergraph_Buff_DecreaseBreathInHolding(int32 EntryPoint, struct UClass* CallFunc__c907b0c934_ReturnValue, struct UClass* K2Node_ClassDynamicCast_AsTsl_Buff); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.ExecuteUbergraph_Buff_DecreaseBreathInHolding //  // @ game+0x2cd4ac
};

