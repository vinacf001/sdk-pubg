// BlueprintGeneratedClass BP_MasteryBannerController.BP_MasteryBannerController_C
// Size: 0x470 (Inherited: 0x470)
struct ABP_MasteryBannerController_C : AMasteryBannerController {
};

