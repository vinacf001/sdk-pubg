// ScriptStruct MapStatCollector.*818c885fc3
// Size: 0x48 (Inherited: 0x00)
struct F*818c885fc3 {
	struct FName Name; // 0x00(0x08)
	struct FBox2D SamplingArea; // 0x08(0x14)
	char pad_1C[0x4]; // 0x1c(0x04)
	double GroundHeight; // 0x20(0x08)
	double PointInterval; // 0x28(0x08)
	double RayDistance; // 0x30(0x08)
	double HeightOffset; // 0x38(0x08)
	double SearchRadius; // 0x40(0x08)
};

// ScriptStruct MapStatCollector.*45fdbbfb77
// Size: 0x20 (Inherited: 0x00)
struct F*45fdbbfb77 {
	struct FString MapName; // 0x00(0x10)
	struct FString *9430115d9f; // 0x10(0x10)
};

// ScriptStruct MapStatCollector.*6b30df112f
// Size: 0x20 (Inherited: 0x00)
struct F*6b30df112f {
	struct FString StatName; // 0x00(0x10)
	struct FString *05bab6a35d; // 0x10(0x10)
};

