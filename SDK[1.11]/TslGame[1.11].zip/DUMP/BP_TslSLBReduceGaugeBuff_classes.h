// BlueprintGeneratedClass BP_TslSLBReduceGaugeBuff.BP_TslSLBReduceGaugeBuff_C
// Size: 0x4a0 (Inherited: 0x498)
struct ABP_TslSLBReduceGaugeBuff_C : ATslFBRBuff {
	struct USceneComponent* DefaultSceneRoot[0x08]; // 0x498(0x08)

	void UserConstructionScript(); // Function BP_TslSLBReduceGaugeBuff.BP_TslSLBReduceGaugeBuff_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

