// ScriptStruct LevelSequence.*5f70314217
// Size: 0x38 (Inherited: 0x00)
struct F*5f70314217 {
	struct UObject* *2d89fab18a[0x1c]; // 0x00(0x1c)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString ComponentName[0x10]; // 0x20(0x10)
	struct UObject* *e9c0a56ae1[0x08]; // 0x30(0x08)
};

// ScriptStruct LevelSequence.*18b04c0f43
// Size: 0x50 (Inherited: 0x00)
struct F*18b04c0f43 {
	struct TMap<struct FGuid, struct F*b20fa12cb6> *ab2c4d6ddf[0x50]; // 0x00(0x50)
};

// ScriptStruct LevelSequence.*b20fa12cb6
// Size: 0x10 (Inherited: 0x00)
struct F*b20fa12cb6 {
	struct TArray<struct F*4144c94bfd> References[0x10]; // 0x00(0x10)
};

// ScriptStruct LevelSequence.*4144c94bfd
// Size: 0x20 (Inherited: 0x00)
struct F*4144c94bfd {
	struct FString PackageName[0x10]; // 0x00(0x10)
	struct FString ObjectPath[0x10]; // 0x10(0x10)
};

// ScriptStruct LevelSequence.*464c634831
// Size: 0x50 (Inherited: 0x00)
struct F*464c634831 {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct LevelSequence.*b84b7e6303
// Size: 0x20 (Inherited: 0x00)
struct F*b84b7e6303 {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct LevelSequence.*cf8a9c6e3b
// Size: 0x50 (Inherited: 0x00)
struct F*cf8a9c6e3b {
	struct FText MasterName[0x18]; // 0x00(0x18)
	float MasterTime[0x04]; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FText CurrentShotName[0x18]; // 0x20(0x18)
	float CurrentShotLocalTime[0x04]; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct UCameraComponent* CameraComponent[0x08]; // 0x40(0x08)
	struct F*7c29304c5c Settings[0x08]; // 0x48(0x08)
};

// ScriptStruct LevelSequence.*7c29304c5c
// Size: 0x08 (Inherited: 0x00)
struct F*7c29304c5c {
	bool ZeroPadAmount; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float FrameRate[0x04]; // 0x04(0x04)
};

// ScriptStruct LevelSequence.*b53731d2a6
// Size: 0x01 (Inherited: 0x00)
struct F*b53731d2a6 {
	char pad_0[0x1]; // 0x00(0x01)
};

