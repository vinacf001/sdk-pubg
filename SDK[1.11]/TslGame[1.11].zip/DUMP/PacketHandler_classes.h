// Class PacketHandler.*662c187ec2
// Size: 0x28 (Inherited: 0x28)
struct U*662c187ec2 : UObject {
};

