// BlueprintGeneratedClass BP_Impact_DronePackage.BP_Impact_DronePackage_C
// Size: 0x12d8 (Inherited: 0x12d0)
struct ABP_Impact_DronePackage_C : ATslImpactEffect {
	struct UParticleSystem* FleshFX[0x08]; // 0x12d0(0x08)

	void UserConstructionScript(); // Function BP_Impact_DronePackage.BP_Impact_DronePackage_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

