// WidgetBlueprintGeneratedClass BP_PubgIdWidget.BP_PubgIdWidget_C
// Size: 0x628 (Inherited: 0x620)
struct UBP_PubgIdWidget_C : U*91d390f031 {
	struct UTextBlock* PlayerNameText[0x08]; // 0x620(0x08)
};

