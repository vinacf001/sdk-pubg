// BlueprintGeneratedClass BP_EmPickup_Castable.BP_EmPickup_Castable_C
// Size: 0x90 (Inherited: 0x90)
struct UBP_EmPickup_Castable_C : U*927eb0faa0 {
};

