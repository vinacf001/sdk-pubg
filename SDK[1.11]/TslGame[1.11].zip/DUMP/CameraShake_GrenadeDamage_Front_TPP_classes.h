// BlueprintGeneratedClass CameraShake_GrenadeDamage_Front_TPP.CameraShake_GrenadeDamage_Front_TPP_C
// Size: 0x160 (Inherited: 0x160)
struct UCameraShake_GrenadeDamage_Front_TPP_C : UCameraShake {
};

