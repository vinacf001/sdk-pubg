// ScriptStruct GeometryCache.*94c69945b1
// Size: 0x50 (Inherited: 0x00)
struct F*94c69945b1 {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct GeometryCache.*71f819e977
// Size: 0x50 (Inherited: 0x00)
struct F*71f819e977 {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct GeometryCache.*db752c0120
// Size: 0x0c (Inherited: 0x00)
struct F*db752c0120 {
	char pad_0[0xc]; // 0x00(0x0c)
};

