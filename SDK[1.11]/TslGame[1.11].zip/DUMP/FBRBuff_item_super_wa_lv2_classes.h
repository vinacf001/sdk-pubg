// BlueprintGeneratedClass FBRBuff_item_super_wa_lv2.FBRBuff_item_super_wa_lv2_C
// Size: 0x4c0 (Inherited: 0x4b8)
struct AFBRBuff_item_super_wa_lv2_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot[0x08]; // 0x4b8(0x08)

	void UserConstructionScript(); // Function FBRBuff_item_super_wa_lv2.FBRBuff_item_super_wa_lv2_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

