// WidgetBlueprintGeneratedClass LobbyRotationRectWidget.LobbyRotationRectWidget_C
// Size: 0x420 (Inherited: 0x418)
struct ULobbyRotationRectWidget_C : U*b6db81511e {
	struct UImage* RotationRect[0x08]; // 0x418(0x08)
};

