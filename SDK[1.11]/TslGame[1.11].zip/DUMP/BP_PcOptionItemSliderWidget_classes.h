// WidgetBlueprintGeneratedClass BP_PcOptionItemSliderWidget.BP_PcOptionItemSliderWidget_C
// Size: 0x870 (Inherited: 0x868)
struct UBP_PcOptionItemSliderWidget_C : U*09cb64dd50 {
	struct USizeBox* IndentationSizeBox[0x08]; // 0x868(0x08)
};

