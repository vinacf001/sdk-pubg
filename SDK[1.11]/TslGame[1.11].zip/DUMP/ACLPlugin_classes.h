// Class ACLPlugin.ACLStatsDumpCommandlet
// Size: 0x80 (Inherited: 0x80)
struct UACLStatsDumpCommandlet : UCommandlet {
};

// Class ACLPlugin.AnimCompress_ACLAuto
// Size: 0x48 (Inherited: 0x48)
struct UAnimCompress_ACLAuto : UAnimCompress {
};

// Class ACLPlugin.*83905c7eb2
// Size: 0x48 (Inherited: 0x48)
struct U*83905c7eb2 : UAnimCompress {
};

// Class ACLPlugin.*ecaa10e490
// Size: 0x60 (Inherited: 0x48)
struct U*ecaa10e490 : U*83905c7eb2 {
	enum class *64d1ea9ef9 *d0a4aa94a2; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	float *9598ff5361[0x04]; // 0x4c(0x04)
	float *52dfab0903[0x04]; // 0x50(0x04)
	float *99d1f717d9[0x04]; // 0x54(0x04)
	float *c0c7a3d0d0[0x04]; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
};

// Class ACLPlugin.*7b003d30ca
// Size: 0x70 (Inherited: 0x48)
struct U*7b003d30ca : U*83905c7eb2 {
	float *9598ff5361[0x04]; // 0x48(0x04)
	float *52dfab0903[0x04]; // 0x4c(0x04)
	enum class *64d1ea9ef9 *d0a4aa94a2; // 0x50(0x01)
	enum class *a955d4225e *13b8cb6e4c; // 0x51(0x01)
	enum class *9b7e97d129 *53b169f3ee; // 0x52(0x01)
	enum class *9b7e97d129 *563572dd1f; // 0x53(0x01)
	float *c0c7a3d0d0[0x04]; // 0x54(0x04)
	float *63786ce313[0x04]; // 0x58(0x04)
	float *5b131163be[0x04]; // 0x5c(0x04)
	float *f029f92952[0x04]; // 0x60(0x04)
	char *011ff54230 : 1; // 0x64(0x01)
	char *7749b5b983 : 1; // 0x64(0x01)
	char *47342ff38d : 1; // 0x64(0x01)
	char *2c1075589b : 1; // 0x64(0x01)
	char *b5e4673bd5 : 1; // 0x64(0x01)
	char *45c5ddf567 : 1; // 0x64(0x01)
	char *55f16a374a : 1; // 0x64(0x01)
	char pad_64_7 : 1; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
	uint16 *104b796b26[0x02]; // 0x68(0x02)
	uint16 *ea6396fd3e[0x02]; // 0x6a(0x02)
	char pad_6C[0x4]; // 0x6c(0x04)
};

