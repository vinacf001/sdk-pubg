// WidgetBlueprintGeneratedClass KeyGuideTabWidget.KeyGuideTabWidget_C
// Size: 0x468 (Inherited: 0x468)
struct UKeyGuideTabWidget_C : U*470d1af080 {
};

