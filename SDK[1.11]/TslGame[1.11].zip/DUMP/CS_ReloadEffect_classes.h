// BlueprintGeneratedClass CS_ReloadEffect.CS_ReloadEffect_C
// Size: 0x160 (Inherited: 0x160)
struct UCS_ReloadEffect_C : UCameraShake {
};

