// Class ClothingSystemRuntime.*81a85dc7ae
// Size: 0x28 (Inherited: 0x28)
struct U*81a85dc7ae : UObject {
};

// Class ClothingSystemRuntime.ClothingAsset
// Size: 0x158 (Inherited: 0x48)
struct UClothingAsset : U*ac42304f2a {
	struct F*3b13593114 *3b13593114[0xbc]; // 0x48(0xbc)
	char pad_104[0x4]; // 0x104(0x04)
	struct TArray<struct F*2643f3aca7> *a09dd6c691[0x10]; // 0x108(0x10)
	struct TArray<int32> *38207f2b95[0x10]; // 0x118(0x10)
	struct TArray<struct FName> *39c466bccc[0x10]; // 0x128(0x10)
	struct TArray<int32> *74308bc425[0x10]; // 0x138(0x10)
	int32 *7f9991c46f[0x04]; // 0x148(0x04)
	char pad_14C[0x4]; // 0x14c(0x04)
	struct U*81a85dc7ae* CustomData[0x08]; // 0x150(0x08)
};

// Class ClothingSystemRuntime.*669c3e725f
// Size: 0x28 (Inherited: 0x28)
struct U*669c3e725f : U*aefcf253a9 {
};

