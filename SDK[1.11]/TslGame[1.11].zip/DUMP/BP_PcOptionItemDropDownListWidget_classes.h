// WidgetBlueprintGeneratedClass BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C
// Size: 0x8c0 (Inherited: 0x890)
struct UBP_PcOptionItemDropDownListWidget_C : U*befee03514 {
	struct F*abc8f374e0 UberGraphFrame[0x08]; // 0x890(0x08)
	struct U*692e3f208b* ComboBox[0x08]; // 0x898(0x08)
	struct UButton* ComboBoxButton[0x08]; // 0x8a0(0x08)
	struct USizeBox* IndentationSizeBox[0x08]; // 0x8a8(0x08)
	struct FMulticastDelegate OnSelectionChanged[0x10]; // 0x8b0(0x10)

	void BndEvt__ComboBox_K2Node_ComponentBoundEvent_21_OnSelectionChangedEvent__DelegateSignature(); // Function BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C.BndEvt__ComboBox_K2Node_ComponentBoundEvent_21_OnSelectionChangedEvent__DelegateSignature // BlueprintEvent // @ game+0x2cd4ac
	struct FString ExecuteUbergraph_BP_PcOptionItemDropDownListWidget(); // Function BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C.ExecuteUbergraph_BP_PcOptionItemDropDownListWidget //  // @ game+0x2cd4ac
	struct FString OnSelectionChanged__DelegateSignature(); // Function BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C.OnSelectionChanged__DelegateSignature // Public|Delegate|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

