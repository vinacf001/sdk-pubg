// BlueprintGeneratedClass BP_ViewModeStudio.BP_ViewModeStudio_C
// Size: 0x458 (Inherited: 0x450)
struct ABP_ViewModeStudio_C : AViewModeStudio {
	struct F*abc8f374e0 UberGraphFrame[0x08]; // 0x450(0x08)

	void UserConstructionScript(); // Function BP_ViewModeStudio.BP_ViewModeStudio_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void SetViewModeAbleActor(); // Function BP_ViewModeStudio.BP_ViewModeStudio_C.SetViewModeAbleActor // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void ExecuteUbergraph_BP_ViewModeStudio(); // Function BP_ViewModeStudio.BP_ViewModeStudio_C.ExecuteUbergraph_BP_ViewModeStudio //  // @ game+0x2cd4ac
};

