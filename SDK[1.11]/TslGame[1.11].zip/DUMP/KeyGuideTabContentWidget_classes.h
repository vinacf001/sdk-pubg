// WidgetBlueprintGeneratedClass KeyGuideTabContentWidget.KeyGuideTabContentWidget_C
// Size: 0x518 (Inherited: 0x500)
struct UKeyGuideTabContentWidget_C : U*3945e9cacf {
	struct F*abc8f374e0 UberGraphFrame[0x08]; // 0x500(0x08)
	struct UTextBlock* TitleNormal[0x08]; // 0x508(0x08)
	struct UTextBlock* TitleSelected[0x08]; // 0x510(0x08)

	void PreConstruct(); // Function KeyGuideTabContentWidget.KeyGuideTabContentWidget_C.PreConstruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x2cd4ac
	int32 ExecuteUbergraph_KeyGuideTabContentWidget(); // Function KeyGuideTabContentWidget.KeyGuideTabContentWidget_C.ExecuteUbergraph_KeyGuideTabContentWidget //  // @ game+0x2cd4ac
};

