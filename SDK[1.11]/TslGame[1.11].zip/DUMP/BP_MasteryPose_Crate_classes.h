// BlueprintGeneratedClass BP_MasteryPose_Crate.BP_MasteryPose_Crate_C
// Size: 0x468 (Inherited: 0x438)
struct ABP_MasteryPose_Crate_C : ABP_MasteryPose_C {
	struct UStaticMeshComponent* Plane[0x08]; // 0x438(0x08)
	struct UAsyncStaticMeshComponent* CrateMesh[0x08]; // 0x440(0x08)
	struct USpotLightComponent* SpotLight1[0x08]; // 0x448(0x08)
	struct USpotLightComponent* spotlight[0x08]; // 0x450(0x08)
	struct USpotLightComponent* LobbySpotLight[0x08]; // 0x458(0x08)
	struct UParticleSystemComponent* LobbyParticles[0x08]; // 0x460(0x08)

	void UserConstructionScript(); // Function BP_MasteryPose_Crate.BP_MasteryPose_Crate_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

