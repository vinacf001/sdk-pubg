// BlueprintGeneratedClass FBRBuff_IncreaseMeleeBackAttack.FBRBuff_IncreaseMeleeBackAttack_C
// Size: 0x4a0 (Inherited: 0x498)
struct AFBRBuff_IncreaseMeleeBackAttack_C : ATslFBRBuff {
	struct USceneComponent* DefaultSceneRoot[0x08]; // 0x498(0x08)

	void UserConstructionScript(); // Function FBRBuff_IncreaseMeleeBackAttack.FBRBuff_IncreaseMeleeBackAttack_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

