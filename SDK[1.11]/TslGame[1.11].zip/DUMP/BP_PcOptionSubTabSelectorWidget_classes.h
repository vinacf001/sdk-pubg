// WidgetBlueprintGeneratedClass BP_PcOptionSubTabSelectorWidget.BP_PcOptionSubTabSelectorWidget_C
// Size: 0x450 (Inherited: 0x428)
struct UBP_PcOptionSubTabSelectorWidget_C : U*7bd9e40db9 {
	struct UBP_GamepadKeyIconWidget_C* BP_GamepadKeyIconWidget_C_1[0x08]; // 0x428(0x08)
	struct UBP_GamepadKeyIconWidget_C* BP_GamepadKeyIconWidget_C_2[0x08]; // 0x430(0x08)
	struct U*290fc681a4* GamepadLB[0x08]; // 0x438(0x08)
	struct U*290fc681a4* GamepadRB[0x08]; // 0x440(0x08)
	struct UImage* Image_1[0x08]; // 0x448(0x08)
};

