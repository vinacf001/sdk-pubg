// BlueprintGeneratedClass AudioTestActor.AudioTestActor_C
// Size: 0x3f0 (Inherited: 0x3e8)
struct AAudioTestActor_C : AActor {
	struct USceneComponent* DefaultSceneRoot[0x08]; // 0x3e8(0x08)

	void PrintDistance(); // Function AudioTestActor.AudioTestActor_C.PrintDistance // Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void Destroy(); // Function AudioTestActor.AudioTestActor_C.Destroy // Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void PrintText(); // Function AudioTestActor.AudioTestActor_C.PrintText // Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	struct FString SetSwitch(); // Function AudioTestActor.AudioTestActor_C.SetSwitch // Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void SetNextSound(); // Function AudioTestActor.AudioTestActor_C.SetNextSound // Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void Retrigger(); // Function AudioTestActor.AudioTestActor_C.Retrigger // Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void PlayAudioRetrigger(); // Function AudioTestActor.AudioTestActor_C.PlayAudioRetrigger // Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void PlayAudio(); // Function AudioTestActor.AudioTestActor_C.PlayAudio // Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void Initialize(); // Function AudioTestActor.AudioTestActor_C.Initialize // Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void UserConstructionScript(); // Function AudioTestActor.AudioTestActor_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

