// Class MK3DPublisher.AudioCapturer
// Size: 0x468 (Inherited: 0x3e8)
struct AAudioCapturer : AActor {
	char pad_3E8[0x80]; // 0x3e8(0x80)
};

// Class MK3DPublisher.*6e128d3bb3
// Size: 0x28 (Inherited: 0x28)
struct U*6e128d3bb3 : UBlueprintFunctionLibrary {

	void *fbd11c8a26(); // Function MK3DPublisher.*6e128d3bb3.*fbd11c8a26 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6831f20
	void *3b4e31c975(); // Function MK3DPublisher.*6e128d3bb3.*3b4e31c975 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832070
	int32 *af2a23f308(); // Function MK3DPublisher.*6e128d3bb3.*af2a23f308 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6831df4
	void *1bdb097bdf(int32* Width, int32* Frame, struct FString* outputPath); // Function MK3DPublisher.*6e128d3bb3.*1bdb097bdf // Final|Native|Static|Public|BlueprintCallable // @ game+0x6833490
	void *3a22b36ecb(); // Function MK3DPublisher.*6e128d3bb3.*3a22b36ecb // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832d18
	void *248fcf30fc(); // Function MK3DPublisher.*6e128d3bb3.*248fcf30fc // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832cb4
	int32 *33c2031987(); // Function MK3DPublisher.*6e128d3bb3.*33c2031987 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6832430
	void *b81c8abfa3(int32* Height, int32* VideoBitrate); // Function MK3DPublisher.*6e128d3bb3.*b81c8abfa3 // Final|Native|Static|Public|BlueprintCallable // @ game+0x68336f0
	void *5d3d0fcc94(); // Function MK3DPublisher.*6e128d3bb3.*5d3d0fcc94 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832d78
	void *5c167dd49c(); // Function MK3DPublisher.*6e128d3bb3.*5c167dd49c // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832e60
	void *398e7d9ba4(int32* inIdx); // Function MK3DPublisher.*6e128d3bb3.*398e7d9ba4 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6832194
	void *f1872e58ba(); // Function MK3DPublisher.*6e128d3bb3.*f1872e58ba // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832ddc
	void *2126b7ff7d(); // Function MK3DPublisher.*6e128d3bb3.*2126b7ff7d // Final|Native|Static|Public|BlueprintCallable // @ game+0x68320fc
	void *03e7a35727(); // Function MK3DPublisher.*6e128d3bb3.*03e7a35727 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6832818
	int32 *0a438fff8d(); // Function MK3DPublisher.*6e128d3bb3.*0a438fff8d // Final|Native|Static|Public|BlueprintCallable // @ game+0x6831fe0
	void *f926c45c3a(); // Function MK3DPublisher.*6e128d3bb3.*f926c45c3a // Final|Native|Static|Public|BlueprintCallable // @ game+0x683347c
	void *204479987d(); // Function MK3DPublisher.*6e128d3bb3.*204479987d // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832fd4
	void *7006f60661(); // Function MK3DPublisher.*6e128d3bb3.*7006f60661 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832a88
	void *6d0b60443f(); // Function MK3DPublisher.*6e128d3bb3.*6d0b60443f // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x68329d4
	void *fa66a3a5e4(); // Function MK3DPublisher.*6e128d3bb3.*fa66a3a5e4 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832f28
	int32 *03d7280695(int32* Width); // Function MK3DPublisher.*6e128d3bb3.*03d7280695 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6831cdc
	void *a59933c3cb(); // Function MK3DPublisher.*6e128d3bb3.*a59933c3cb // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6831a2c
	void *4cfa6d2f95(); // Function MK3DPublisher.*6e128d3bb3.*4cfa6d2f95 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832768
	void *ad2c60d77c(); // Function MK3DPublisher.*6e128d3bb3.*ad2c60d77c // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6831ad8
	void *c8a50e2aa7(); // Function MK3DPublisher.*6e128d3bb3.*c8a50e2aa7 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832bc8
	void *e76e8bbeec(); // Function MK3DPublisher.*6e128d3bb3.*e76e8bbeec // Final|Native|Static|Public|BlueprintCallable // @ game+0x6833414
	float *4506b8c7cd(); // Function MK3DPublisher.*6e128d3bb3.*4506b8c7cd // Final|Native|Static|Public|BlueprintCallable // @ game+0x68339bc
	void *4fc021d0da(); // Function MK3DPublisher.*6e128d3bb3.*4fc021d0da // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832790
	void *e809755714(struct UUserWidget** InWidget); // Function MK3DPublisher.*6e128d3bb3.*e809755714 // Final|Native|Static|Public|BlueprintCallable // @ game+0x683199c
	int32 *8375d1fe96(); // Function MK3DPublisher.*6e128d3bb3.*8375d1fe96 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x683307c
	float *4ef94035a0(); // Function MK3DPublisher.*6e128d3bb3.*4ef94035a0 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6833aa4
	void *adc0beba41(); // Function MK3DPublisher.*6e128d3bb3.*adc0beba41 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6833950
	void *22ffa0ce88(); // Function MK3DPublisher.*6e128d3bb3.*22ffa0ce88 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6831b84
	void *663d1c0f69(); // Function MK3DPublisher.*6e128d3bb3.*663d1c0f69 // Final|Native|Static|Public|BlueprintCallable // @ game+0x68326d8
	int32 *203ecfa57f(); // Function MK3DPublisher.*6e128d3bb3.*203ecfa57f // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x683253c
	void *331964a351(); // Function MK3DPublisher.*6e128d3bb3.*331964a351 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6831fb8
	int32 *7a2cd73beb(struct FString* Str); // Function MK3DPublisher.*6e128d3bb3.*7a2cd73beb // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6833218
	int32 *18961060bf(); // Function MK3DPublisher.*6e128d3bb3.*18961060bf // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x683229c
	void *6a18810aeb(); // Function MK3DPublisher.*6e128d3bb3.*6a18810aeb // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6831c30
	void *c35d5e1e49(); // Function MK3DPublisher.*6e128d3bb3.*c35d5e1e49 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6833b8c
	void *c816d53d3d(); // Function MK3DPublisher.*6e128d3bb3.*c816d53d3d // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832c2c
	void *d027265167(); // Function MK3DPublisher.*6e128d3bb3.*d027265167 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832ec4
	void *bc40893864(); // Function MK3DPublisher.*6e128d3bb3.*bc40893864 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6832920
	void *81f9f72787(); // Function MK3DPublisher.*6e128d3bb3.*81f9f72787 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832c50
	struct FString *d068694a96(); // Function MK3DPublisher.*6e128d3bb3.*d068694a96 // Final|Native|Static|Public|HasOutParms|BlueprintCallable // @ game+0x6833c88
	void *20cc247e80(); // Function MK3DPublisher.*6e128d3bb3.*20cc247e80 // Final|Native|Static|Public|BlueprintCallable // @ game+0x6832738
};

// Class MK3DPublisher.ViewportCapturer
// Size: 0x480 (Inherited: 0x3e8)
struct AViewportCapturer : AActor {
	char pad_3E8[0x98]; // 0x3e8(0x98)
};

