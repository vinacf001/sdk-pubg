// Class FacialAnimation.*e773cb3a40
// Size: 0x7e0 (Inherited: 0x7a0)
struct U*e773cb3a40 : UAudioComponent {
	char pad_7A0[0x8]; // 0x7a0(0x08)
	struct FName CurveSourceBindingName[0x08]; // 0x7a8(0x08)
	float CurveSyncOffset[0x04]; // 0x7b0(0x04)
	char pad_7B4[0x2c]; // 0x7b4(0x2c)
};

