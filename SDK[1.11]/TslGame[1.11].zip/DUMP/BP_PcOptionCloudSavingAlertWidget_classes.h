// WidgetBlueprintGeneratedClass BP_PcOptionCloudSavingAlertWidget.BP_PcOptionCloudSavingAlertWidget_C
// Size: 0x488 (Inherited: 0x488)
struct UBP_PcOptionCloudSavingAlertWidget_C : U*85de85f6a1 {
};

