// BlueprintGeneratedClass Powerup_KFCDrink.Powerup_KFCDrink_C
// Size: 0x448 (Inherited: 0x440)
struct APowerup_KFCDrink_C : APowerup_Base_C {
	struct F*abc8f374e0 UberGraphFrame[0x08]; // 0x440(0x08)

	void UserConstructionScript(); // Function Powerup_KFCDrink.Powerup_KFCDrink_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void ReceiveBeginPlay(); // Function Powerup_KFCDrink.Powerup_KFCDrink_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x2cd4ac
	void ExecuteUbergraph_Powerup_KFCDrink(); // Function Powerup_KFCDrink.Powerup_KFCDrink_C.ExecuteUbergraph_Powerup_KFCDrink //  // @ game+0x2cd4ac
};

