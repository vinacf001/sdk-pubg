// WidgetBlueprintGeneratedClass LobbyCustomizeSpinnerWidget.LobbyCustomizeSpinnerWidget_C
// Size: 0x428 (Inherited: 0x420)
struct ULobbyCustomizeSpinnerWidget_C : U*7fa455d9e8 {
	struct UImage* LoadingSpinnerImage[0x08]; // 0x420(0x08)
};

