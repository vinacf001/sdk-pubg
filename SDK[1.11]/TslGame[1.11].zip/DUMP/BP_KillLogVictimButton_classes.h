// WidgetBlueprintGeneratedClass BP_KillLogVictimButton.BP_KillLogVictimButton_C
// Size: 0x700 (Inherited: 0x6f0)
struct UBP_KillLogVictimButton_C : U*44ac9ae1d3 {
	struct F*abc8f374e0 UberGraphFrame[0x08]; // 0x6f0(0x08)
	struct UButton* Button_1[0x08]; // 0x6f8(0x08)

	void BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function BP_KillLogVictimButton.BP_KillLogVictimButton_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x2cd4ac
	void ExecuteUbergraph_BP_KillLogVictimButton(); // Function BP_KillLogVictimButton.BP_KillLogVictimButton_C.ExecuteUbergraph_BP_KillLogVictimButton //  // @ game+0x2cd4ac
};

