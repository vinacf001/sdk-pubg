// BlueprintGeneratedClass DmgType_VehicleHit.DmgType_VehicleHit_C
// Size: 0xf8 (Inherited: 0xf8)
struct UDmgType_VehicleHit_C : UTslDamageType {
};

