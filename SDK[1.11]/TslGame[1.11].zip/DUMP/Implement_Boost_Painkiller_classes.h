// BlueprintGeneratedClass Implement_Boost_Painkiller.Implement_Boost_Painkiller_C
// Size: 0x30 (Inherited: 0x30)
struct UImplement_Boost_Painkiller_C : U*e021139337 {
};

