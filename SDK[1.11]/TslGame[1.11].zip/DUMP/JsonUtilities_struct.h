// ScriptStruct JsonUtilities.*389eb860c6
// Size: 0x20 (Inherited: 0x00)
struct F*389eb860c6 {
	struct FString *fcf8916e64[0x10]; // 0x00(0x10)
	char pad_10[0x10]; // 0x10(0x10)
};

