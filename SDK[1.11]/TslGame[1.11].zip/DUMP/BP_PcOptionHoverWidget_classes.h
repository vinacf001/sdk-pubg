// WidgetBlueprintGeneratedClass BP_PcOptionHoverWidget.BP_PcOptionHoverWidget_C
// Size: 0x470 (Inherited: 0x460)
struct UBP_PcOptionHoverWidget_C : U*d096db5074 {
	struct U*54cc75d10f* Out[0x08]; // 0x460(0x08)
	struct U*54cc75d10f* Hover[0x08]; // 0x468(0x08)
};

