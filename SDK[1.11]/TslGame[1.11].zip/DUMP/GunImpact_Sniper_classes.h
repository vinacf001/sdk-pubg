// BlueprintGeneratedClass GunImpact_Sniper.GunImpact_Sniper_C
// Size: 0x12e8 (Inherited: 0x12e0)
struct AGunImpact_Sniper_C : ATslGunImpact {
	struct F*abc8f374e0 UberGraphFrame[0x08]; // 0x12e0(0x08)

	void UserConstructionScript(); // Function GunImpact_Sniper.GunImpact_Sniper_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void ExecuteUbergraph_GunImpact_Sniper(); // Function GunImpact_Sniper.GunImpact_Sniper_C.ExecuteUbergraph_GunImpact_Sniper //  // @ game+0x2cd4ac
};

