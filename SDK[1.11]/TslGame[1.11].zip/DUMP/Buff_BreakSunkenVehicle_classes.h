// BlueprintGeneratedClass Buff_BreakSunkenVehicle.Buff_BreakSunkenVehicle_C
// Size: 0x480 (Inherited: 0x470)
struct ABuff_BreakSunkenVehicle_C : ATslBuff {
	struct F*abc8f374e0 UberGraphFrame[0x08]; // 0x470(0x08)
	struct USceneComponent* DefaultSceneRoot[0x08]; // 0x478(0x08)

	void UserConstructionScript(); // Function Buff_BreakSunkenVehicle.Buff_BreakSunkenVehicle_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void TickBuff(); // Function Buff_BreakSunkenVehicle.Buff_BreakSunkenVehicle_C.TickBuff // Event|Public|BlueprintEvent // @ game+0x2cd4ac
	void StopBuffBlueprint(); // Function Buff_BreakSunkenVehicle.Buff_BreakSunkenVehicle_C.StopBuffBlueprint // Event|Public|BlueprintEvent // @ game+0x2cd4ac
	bool ExecuteUbergraph_Buff_BreakSunkenVehicle(struct APawn** CallFunc__899b3f9638_ReturnValue, bool CallFunc_IsValid_ReturnValue2); // Function Buff_BreakSunkenVehicle.Buff_BreakSunkenVehicle_C.ExecuteUbergraph_Buff_BreakSunkenVehicle //  // @ game+0x2cd4ac
};

