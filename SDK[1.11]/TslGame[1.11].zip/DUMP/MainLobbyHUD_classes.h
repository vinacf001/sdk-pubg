// WidgetBlueprintGeneratedClass MainLobbyHUD.MainLobbyHUD_C
// Size: 0x338 (Inherited: 0x310)
struct UMainLobbyHUD_C : U*f1b991159b {
	struct F*abc8f374e0 UberGraphFrame[0x08]; // 0x310(0x08)
	struct UInvalidationBox* InvalidationBox_1[0x08]; // 0x318(0x08)
	struct UInvalidationBox* InvalidationBox_2[0x08]; // 0x320(0x08)
	struct UImage* LoadingSpinnerImage[0x08]; // 0x328(0x08)
	struct AReplayList_BP_C* refReplayListBp[0x08]; // 0x330(0x08)

	void OnKeyDown(struct FGeometry* MyGeometry, struct FEventReply* ReturnValue); // Function MainLobbyHUD.MainLobbyHUD_C.OnKeyDown // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void HasChildren(); // Function MainLobbyHUD.MainLobbyHUD_C.HasChildren // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const // @ game+0x2cd4ac
	void BndEvt__Button_0_K2Node_ComponentBoundEvent_35_OnButtonClickedEvent__DelegateSignature(); // Function MainLobbyHUD.MainLobbyHUD_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_35_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x2cd4ac
	bool ExecuteUbergraph_MainLobbyHUD(struct FTransform* CallFunc_MakeTransform_ReturnValue); // Function MainLobbyHUD.MainLobbyHUD_C.ExecuteUbergraph_MainLobbyHUD // HasDefaults // @ game+0x2cd4ac
};

