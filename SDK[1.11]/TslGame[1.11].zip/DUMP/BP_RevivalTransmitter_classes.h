// BlueprintGeneratedClass BP_RevivalTransmitter.BP_RevivalTransmitter_C
// Size: 0x158 (Inherited: 0x158)
struct UBP_RevivalTransmitter_C : U*95c575648a {
};

