// BlueprintGeneratedClass DeathDropItemPackage.DeathDropItemPackage_C
// Size: 0x608 (Inherited: 0x600)
struct ADeathDropItemPackage_C : AFloorSnapItemPackage {
	struct F*abc8f374e0 UberGraphFrame[0x08]; // 0x600(0x08)

	struct TArray<struct FFormatArgumentData> GetCategory(struct FString* CallFunc__1f01808331_ReturnValue); // Function DeathDropItemPackage.DeathDropItemPackage_C.GetCategory // Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void UserConstructionScript(); // Function DeathDropItemPackage.DeathDropItemPackage_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void ReceiveBeginPlay(); // Function DeathDropItemPackage.DeathDropItemPackage_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x2cd4ac
	void ExecuteUbergraph_DeathDropItemPackage(int32* EntryPoint); // Function DeathDropItemPackage.DeathDropItemPackage_C.ExecuteUbergraph_DeathDropItemPackage // HasDefaults // @ game+0x2cd4ac
};

