// WidgetBlueprintGeneratedClass BP_ReportPlayerWidget.BP_ReportPlayerWidget_C
// Size: 0x5f8 (Inherited: 0x5d0)
struct UBP_ReportPlayerWidget_C : U*0b12cc9da8 {
	struct UTextBlock* NoSubjectTextBlock[0x08]; // 0x5d0(0x08)
	struct UTextBlock* TextCancel[0x08]; // 0x5d8(0x08)
	struct UTextBlock* TextOK[0x08]; // 0x5e0(0x08)
	struct FMulticastDelegate ButtonEvent[0x10]; // 0x5e8(0x10)

	void ButtonEvent__DelegateSignature(); // Function BP_ReportPlayerWidget.BP_ReportPlayerWidget_C.ButtonEvent__DelegateSignature // Public|Delegate|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

