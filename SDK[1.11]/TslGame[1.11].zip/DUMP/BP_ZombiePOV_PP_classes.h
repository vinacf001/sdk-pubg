// BlueprintGeneratedClass BP_ZombiePOV_PP.BP_ZombiePOV_PP_C
// Size: 0x478 (Inherited: 0x470)
struct ABP_ZombiePOV_PP_C : ATslPostProcessEffect {
	struct USceneComponent* DefaultSceneRoot[0x08]; // 0x470(0x08)

	void UserConstructionScript(); // Function BP_ZombiePOV_PP.BP_ZombiePOV_PP_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

