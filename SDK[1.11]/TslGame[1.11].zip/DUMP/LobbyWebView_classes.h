// WidgetBlueprintGeneratedClass LobbyWebView.LobbyWebView_C
// Size: 0x438 (Inherited: 0x430)
struct ULobbyWebView_C : U*2b93ea56e7 {
	struct ULobbyRotationRectWidget_C* RotationRect[0x08]; // 0x430(0x08)

	struct FString OnKeyUp(struct FKeyEvent* InKeyEvent); // Function LobbyWebView.LobbyWebView_C.OnKeyUp // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	struct FString OnKeyDown(); // Function LobbyWebView.LobbyWebView_C.OnKeyDown // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	struct FGeometry OnPreviewMouseButtonDown(struct F*174cd056c7* MouseEvent, struct FEventReply* CallFunc__0439345480_ReturnValue); // Function LobbyWebView.LobbyWebView_C.OnPreviewMouseButtonDown // BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
	void GetMainCoherentWidget(); // Function LobbyWebView.LobbyWebView_C.GetMainCoherentWidget // Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const // @ game+0x2cd4ac
	struct FKey OnPreviewKeyDown(struct FEventReply* ReturnValue, struct FText* CallFunc__d3a3fdf6d0_ReturnValue); // Function LobbyWebView.LobbyWebView_C.OnPreviewKeyDown // Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

