// BlueprintGeneratedClass BP_Shield.BP_Shield_C
// Size: 0x400 (Inherited: 0x3e8)
struct ABP_Shield_C : AActor {
	struct UStaticMeshComponent* DecalMesh[0x08]; // 0x3e8(0x08)
	struct UStaticMeshComponent* StaticMesh[0x08]; // 0x3f0(0x08)
	struct USceneComponent* DefaultSceneRoot[0x08]; // 0x3f8(0x08)

	void UserConstructionScript(); // Function BP_Shield.BP_Shield_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x2cd4ac
};

