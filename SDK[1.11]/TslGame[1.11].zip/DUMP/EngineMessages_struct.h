// ScriptStruct EngineMessages.*b1843270a5
// Size: 0x18 (Inherited: 0x00)
struct F*b1843270a5 {
	struct FString Text[0x10]; // 0x00(0x10)
	double TimeSeconds[0x08]; // 0x10(0x08)
};

// ScriptStruct EngineMessages.*544a8b09e3
// Size: 0x10 (Inherited: 0x00)
struct F*544a8b09e3 {
	struct FString UserName[0x10]; // 0x00(0x10)
};

// ScriptStruct EngineMessages.*3d162b2081
// Size: 0x20 (Inherited: 0x00)
struct F*3d162b2081 {
	struct FString Command[0x10]; // 0x00(0x10)
	struct FString UserName[0x10]; // 0x10(0x10)
};

// ScriptStruct EngineMessages.*cdb9c80c49
// Size: 0x20 (Inherited: 0x00)
struct F*cdb9c80c49 {
	struct FString UserName[0x10]; // 0x00(0x10)
	struct FString *6d253847d3[0x10]; // 0x10(0x10)
};

// ScriptStruct EngineMessages.*6ade7fb752
// Size: 0x20 (Inherited: 0x00)
struct F*6ade7fb752 {
	struct FString UserName[0x10]; // 0x00(0x10)
	struct FString *e253fb7bc8[0x10]; // 0x10(0x10)
};

// ScriptStruct EngineMessages.*38f9beff05
// Size: 0x50 (Inherited: 0x00)
struct F*38f9beff05 {
	struct FString CurrentLevel[0x10]; // 0x00(0x10)
	int32 EngineVersion[0x04]; // 0x10(0x04)
	bool *05f73d26c1; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	struct FGuid InstanceId[0x10]; // 0x18(0x10)
	struct FString InstanceType[0x10]; // 0x28(0x10)
	struct FGuid SessionId[0x10]; // 0x38(0x10)
	float *51c9d003a6[0x04]; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// ScriptStruct EngineMessages.*b79037246e
// Size: 0x01 (Inherited: 0x00)
struct F*b79037246e {
	char pad_0[0x1]; // 0x00(0x01)
};

