// WidgetBlueprintGeneratedClass MouseWidgetBP.MouseWidgetBP_C
// Size: 0x468 (Inherited: 0x468)
struct UMouseWidgetBP_C : U*5975ef1fd6 {
};

