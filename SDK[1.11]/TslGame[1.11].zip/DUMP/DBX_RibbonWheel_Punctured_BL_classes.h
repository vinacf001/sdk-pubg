// BlueprintGeneratedClass DBX_RibbonWheel_Punctured_BL.DBX_RibbonWheel_Punctured_BL_C
// Size: 0x3a8 (Inherited: 0x3a8)
struct UDBX_RibbonWheel_Punctured_BL_C : UDBX_RibbonWheel_Punctured_C {
};

