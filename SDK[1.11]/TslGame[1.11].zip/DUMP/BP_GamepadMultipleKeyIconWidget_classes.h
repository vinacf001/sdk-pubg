// WidgetBlueprintGeneratedClass BP_GamepadMultipleKeyIconWidget.BP_GamepadMultipleKeyIconWidget_C
// Size: 0x540 (Inherited: 0x520)
struct UBP_GamepadMultipleKeyIconWidget_C : U*672373cc62 {
	struct UImage* PlusImage[0x08]; // 0x520(0x08)
	struct UImage* PlusImage2[0x08]; // 0x528(0x08)
	struct UImage* SlashImage[0x08]; // 0x530(0x08)
	struct UImage* SlashImage2[0x08]; // 0x538(0x08)
};

