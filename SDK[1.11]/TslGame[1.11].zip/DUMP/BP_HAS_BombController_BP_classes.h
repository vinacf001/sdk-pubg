// BlueprintGeneratedClass BP_HAS_BombController_BP.BP_HAS_BombController_BP_C
// Size: 0x478 (Inherited: 0x478)
struct ABP_HAS_BombController_BP_C : ATslAnimSpawnSkeletalObject {
};

