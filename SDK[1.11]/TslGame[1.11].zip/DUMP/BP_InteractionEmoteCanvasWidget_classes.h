// WidgetBlueprintGeneratedClass BP_InteractionEmoteCanvasWidget.BP_InteractionEmoteCanvasWidget_C
// Size: 0x438 (Inherited: 0x438)
struct UBP_InteractionEmoteCanvasWidget_C : U*bfc2bc5ae2 {
};

