// WidgetBlueprintGeneratedClass BP_DisplayOptionSliderWidget.BP_DisplayOptionSliderWidget_C
// Size: 0x890 (Inherited: 0x868)
struct UBP_DisplayOptionSliderWidget_C : U*09cb64dd50 {
	struct F*abc8f374e0 UberGraphFrame[0x08]; // 0x868(0x08)
	struct UProgressBar* BrightnessProgressBar[0x08]; // 0x870(0x08)
	struct USlider* BrightnessSlider[0x08]; // 0x878(0x08)
	struct UEditableText* BrightnessText[0x08]; // 0x880(0x08)
	struct UProgressBar* NewVar_1[0x08]; // 0x888(0x08)

	void Tick(); // Function BP_DisplayOptionSliderWidget.BP_DisplayOptionSliderWidget_C.Tick // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x2cd4ac
	void ExecuteUbergraph_BP_DisplayOptionSliderWidget(float* CallFunc_GetValue_ReturnValue); // Function BP_DisplayOptionSliderWidget.BP_DisplayOptionSliderWidget_C.ExecuteUbergraph_BP_DisplayOptionSliderWidget // HasDefaults // @ game+0x2cd4ac
};

