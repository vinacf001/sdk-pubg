// WidgetBlueprintGeneratedClass BP_PcOption_SubTabLabelWidget.BP_PcOption_SubTabLabelWidget_C
// Size: 0x460 (Inherited: 0x460)
struct UBP_PcOption_SubTabLabelWidget_C : U*48c60e01ea {
};

