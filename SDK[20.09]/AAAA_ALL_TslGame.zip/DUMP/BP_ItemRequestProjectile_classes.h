// BlueprintGeneratedClass BP_ItemRequestProjectile.BP_ItemRequestProjectile_C
// Size: 0x690 (Inherited: 0x690)
struct ABP_ItemRequestProjectile_C : ATslItemRequestProjectile {
	bool *333279535f; // 0x660(0x01)
	float *83b618706b; // 0x664(0x04)
	float *58b8b72d0e; // 0x668(0x04)
	float *cf054f6b39; // 0x66c(0x04)
	struct ATslCharacter* Target; // 0x670(0x08)

	void *e935426e0b(); // Function TslGame.TslItemRequestProjectile.*e935426e0b // Final|Native|Protected // @ game+0x564c158
};

