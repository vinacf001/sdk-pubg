// WidgetBlueprintGeneratedClass BP_PcOptionSupplementaryPreviewImageWidget.BP_PcOptionSupplementaryPreviewImageWidget_C
// Size: 0x438 (Inherited: 0x438)
struct UBP_PcOptionSupplementaryPreviewImageWidget_C : U*0d2d87f9a0 {
	struct F*d3069d51ff Image_Binder; // 0x410(0x28)
};

