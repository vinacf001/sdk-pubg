// Class JsonUtilities.*1bfa646fde
// Size: 0x28 (Inherited: 0x28)
struct U*1bfa646fde : UObject {
};

