// BlueprintGeneratedClass BP_UnderwaterBulletTrailEffectShort.BP_UnderwaterBulletTrailEffectShort_C
// Size: 0x510 (Inherited: 0x510)
struct ABP_UnderwaterBulletTrailEffectShort_C : ATslParticleBulletTrail {
	struct FVector *618ff0fac0; // 0x4e8(0x0c)
	float *d3cd7bd91f; // 0x4f4(0x04)
	struct UMaterialInterface* *2a61d3067f; // 0x4f8(0x08)
};

