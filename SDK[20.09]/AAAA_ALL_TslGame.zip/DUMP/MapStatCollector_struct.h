// ScriptStruct MapStatCollector.*66f4adf62f
// Size: 0x48 (Inherited: 0x00)
struct F*66f4adf62f {
	struct FName Name; // 0x00(0x08)
	struct FBox2D SamplingArea; // 0x08(0x14)
	char pad_1C[0x4]; // 0x1c(0x04)
	double GroundHeight; // 0x20(0x08)
	double PointInterval; // 0x28(0x08)
	double RayDistance; // 0x30(0x08)
	double HeightOffset; // 0x38(0x08)
	double SearchRadius; // 0x40(0x08)
};

// ScriptStruct MapStatCollector.*2a14cb262c
// Size: 0x20 (Inherited: 0x00)
struct F*2a14cb262c {
	struct FString MapName; // 0x00(0x10)
	struct FString *c0f6d45c49; // 0x10(0x10)
};

// ScriptStruct MapStatCollector.*72cbbd73a0
// Size: 0x20 (Inherited: 0x00)
struct F*72cbbd73a0 {
	struct FString StatName; // 0x00(0x10)
	struct FString *cf22183cab; // 0x10(0x10)
};

