// BlueprintGeneratedClass Implement_Boost_Drink.Implement_Boost_Drink_C
// Size: 0x30 (Inherited: 0x30)
struct UImplement_Boost_Drink_C : U*45d056da2e {
	float BoostGaugeAmount; // 0x28(0x04)
};

