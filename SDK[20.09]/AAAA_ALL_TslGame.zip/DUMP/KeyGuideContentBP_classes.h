// WidgetBlueprintGeneratedClass KeyGuideContentBP.KeyGuideContentBP_C
// Size: 0x498 (Inherited: 0x478)
struct UKeyGuideContentBP_C : U*067391b601 {
	struct UKeyImageWIdgetBP_C* KeyImageWIdgetBP_1; // 0x478(0x08)
	struct UKeyImageWIdgetBP_C* KeyImageWIdgetBP_2; // 0x480(0x08)
	struct UKeyImageWIdgetBP_C* KeyImageWIdgetBP_3; // 0x488(0x08)
	struct UKeyImageWIdgetBP_C* KeyImageWIdgetBP_4; // 0x490(0x08)
};

