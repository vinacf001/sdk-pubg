// Enum MK3DPublisher.*919466aee7
enum class *919466aee7 : uint8 {
	*a28d774b39,
	*e797c4bc4d,
	*8d3c703558,
	*c0d9e9409f,
	*919466aee7_MAX,
};

