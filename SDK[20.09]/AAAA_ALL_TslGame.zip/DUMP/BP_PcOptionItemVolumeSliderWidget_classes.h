// WidgetBlueprintGeneratedClass BP_PcOptionItemVolumeSliderWidget.BP_PcOptionItemVolumeSliderWidget_C
// Size: 0x8c0 (Inherited: 0x8b0)
struct UBP_PcOptionItemVolumeSliderWidget_C : U*df57d22912 {
	struct USizeBox* IndentationSizeBox; // 0x8b0(0x08)
	struct U*3bbae755be* TslUniversalInputVisibilitySwitcher_1; // 0x8b8(0x08)
};

