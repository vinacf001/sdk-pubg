// BlueprintGeneratedClass LobbyParachute.LobbyParachute_C
// Size: 0x430 (Inherited: 0x430)
struct ALobbyParachute_C : ALobbyParachute {
	struct USkeletalMesh* ParachuteSK; // 0x400(0x08)
	struct F*1b7d567481 *1b7d567481; // 0x408(0x20)
	struct U*6a49296386* ParachuteSKReference; // 0x428(0x08)

	void *02b88a4e9d(); // Function TslGame.LobbyParachute.*02b88a4e9d // Final|Native|Public|BlueprintCallable // @ game+0x566b3f0
	void OnRep_ReplicatedSkinParam(); // Function TslGame.LobbyParachute.OnRep_ReplicatedSkinParam // Final|Native|Private // @ game+0x566fac4
};

