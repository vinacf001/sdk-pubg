// Enum HoudiniEngineRuntime.*c49ea897ae
enum class *c49ea897ae : uint8 {
	*3c40e5796a,
	*f553862243,
	*5327542fd8,
	*1f609078d8,
	*c49ea897ae_MAX,
};

// Enum HoudiniEngineRuntime.*4ef8ff24ed
enum class *4ef8ff24ed : uint8 {
	*e8ff5f5117,
	*0b0cdba1d8,
	*d91b7e01ad,
	*a4cecae161,
	*2f2ff09a70,
	*4ef8ff24ed_MAX,
};

// Enum HoudiniEngineRuntime.*94bd113afd
enum class *94bd113afd : uint8 {
	*1f630126d6,
	*af928952b1,
	*17faafc722,
	*94bd113afd_MAX,
};

// Enum HoudiniEngineRuntime.*0ad53bb409
enum class *0ad53bb409 : uint8 {
	*3317d0119a,
	*776badd59b,
	*a90519dee7,
	*530f3b47fb,
	*0ad53bb409_MAX,
};

// Enum HoudiniEngineRuntime.*50bc741638
enum class *50bc741638 : uint8 {
	*f880145369,
	*49485a6792,
	*fc040b5149,
	*86d279c655,
	*50bc741638_MAX,
};

// Enum HoudiniEngineRuntime.*31c562eaaa
enum class *31c562eaaa : uint8 {
	*b333129677,
	*936093fcae,
	*4bf686dcb8,
	*b02cb2004c,
	*31c562eaaa_MAX,
};

// Enum HoudiniEngineRuntime.EHoudiniHandleType
enum class EHoudiniHandleType : uint8 {
	Xform,
	Bounder,
	Unsupported,
	EHoudiniHandleType_MAX,
};

// ScriptStruct HoudiniEngineRuntime.*394bf1e9ca
// Size: 0x30 (Inherited: 0x00)
struct F*394bf1e9ca {
	struct FString Name; // 0x00(0x10)
	struct FDirectoryPath path; // 0x10(0x10)
	struct FString ContentDirID; // 0x20(0x10)
};

