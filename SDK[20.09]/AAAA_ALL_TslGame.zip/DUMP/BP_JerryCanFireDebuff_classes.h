// BlueprintGeneratedClass BP_JerryCanFireDebuff.BP_JerryCanFireDebuff_C
// Size: 0x4b8 (Inherited: 0x4b0)
struct ABP_JerryCanFireDebuff_C : ATslMolotovFireDebuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4b0(0x08)
};

