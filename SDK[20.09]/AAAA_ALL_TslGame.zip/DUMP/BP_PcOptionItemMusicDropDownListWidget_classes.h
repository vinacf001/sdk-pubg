// WidgetBlueprintGeneratedClass BP_PcOptionItemMusicDropDownListWidget.BP_PcOptionItemMusicDropDownListWidget_C
// Size: 0x8b8 (Inherited: 0x8a0)
struct UBP_PcOptionItemMusicDropDownListWidget_C : U*2546065b5d {
	struct U*15885c1d90* ComboBox; // 0x8a0(0x08)
	struct UButton* ComboBoxButton; // 0x8a8(0x08)
	struct USizeBox* IndentationSizeBox; // 0x8b0(0x08)
};

