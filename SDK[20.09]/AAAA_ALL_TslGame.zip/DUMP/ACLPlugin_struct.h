// Enum ACLPlugin.*7e21892861
enum class *7e21892861 : uint8 {
	*0b5fca5ec8,
	*23e2582fee,
	*02b0388f28,
	*74ff6159c8,
	*99c2da0707,
	*cf367617f3,
	*7e21892861_MAX,
};

// Enum ACLPlugin.*4135de9f5f
enum class *4135de9f5f : uint8 {
	*772d3089d1,
	*458618d2a3,
	*9a0e12b9b1,
	*4135de9f5f_MAX,
};

// Enum ACLPlugin.*adfeed7711
enum class *adfeed7711 : uint8 {
	*c96493e51b,
	*822dc4b539,
	*a9092b7f81,
	*6944ac2414,
	*adfeed7711_MAX,
};

