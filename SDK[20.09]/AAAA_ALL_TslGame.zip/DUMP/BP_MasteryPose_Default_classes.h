// BlueprintGeneratedClass BP_MasteryPose_Default.BP_MasteryPose_Default_C
// Size: 0x458 (Inherited: 0x440)
struct ABP_MasteryPose_Default_C : ABP_MasteryPose_C {
	struct USpotLightComponent* SpotLightEyes; // 0x440(0x08)
	struct USpotLightComponent* LobbySpotLight; // 0x448(0x08)
	struct USpotLightComponent* spotlight; // 0x450(0x08)
};

