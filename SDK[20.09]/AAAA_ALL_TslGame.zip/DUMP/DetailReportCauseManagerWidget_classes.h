// WidgetBlueprintGeneratedClass DetailReportCauseManagerWidget.DetailReportCauseManagerWidget_C
// Size: 0x438 (Inherited: 0x438)
struct UDetailReportCauseManagerWidget_C : U*bfd8a49f01 {
	struct U*d6141ce5d8* ReportRadioBox; // 0x410(0x08)
	struct UTextBlock* TextGuide; // 0x418(0x08)
	struct USizeBox* SizeboxCheatingDetail; // 0x420(0x08)
	struct UMultiLineEditableTextBox* TextboxCheatingDetail; // 0x428(0x08)
	int32 *0e9077b09a; // 0x430(0x04)

	void HandleOnOptionToggled(); // Function TslGame.*bfd8a49f01.HandleOnOptionToggled // Final|Native|Private // @ game+0x56e2d88
	void HandleOnTextChanged(); // Function TslGame.*bfd8a49f01.HandleOnTextChanged // Final|Native|Private|HasOutParms // @ game+0x56e2e48
};

