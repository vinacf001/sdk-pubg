// ScriptStruct JsonUtilities.*0c5655bb7c
// Size: 0x20 (Inherited: 0x00)
struct F*0c5655bb7c {
	struct FString *f91f5634b4; // 0x00(0x10)
	char pad_10[0x10]; // 0x10(0x10)
};

