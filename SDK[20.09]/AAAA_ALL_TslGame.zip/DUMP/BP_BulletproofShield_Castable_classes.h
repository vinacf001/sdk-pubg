// BlueprintGeneratedClass BP_BulletproofShield_Castable.BP_BulletproofShield_Castable_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBP_BulletproofShield_Castable_C : U*6c648a8ff6 {
	struct UClass* BulletShieldClass; // 0x28(0x20)
	struct F*c31413884b PlacementTraceParams; // 0x48(0x50)
	struct U*7e25f3baf0* *0d7b0222f2; // 0x98(0x08)
	struct UClass* *3ec36aa1b0; // 0xa0(0x08)
	struct ATslBulletproofShield* *615c027365; // 0xa8(0x08)
};

