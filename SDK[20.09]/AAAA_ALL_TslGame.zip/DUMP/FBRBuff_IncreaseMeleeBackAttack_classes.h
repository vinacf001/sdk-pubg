// BlueprintGeneratedClass FBRBuff_IncreaseMeleeBackAttack.FBRBuff_IncreaseMeleeBackAttack_C
// Size: 0x4a8 (Inherited: 0x4a0)
struct AFBRBuff_IncreaseMeleeBackAttack_C : ATslFBRBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4a0(0x08)
};

