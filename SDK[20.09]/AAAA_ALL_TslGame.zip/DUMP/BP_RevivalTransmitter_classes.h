// BlueprintGeneratedClass BP_RevivalTransmitter.BP_RevivalTransmitter_C
// Size: 0x158 (Inherited: 0x158)
struct UBP_RevivalTransmitter_C : U*3ac6468f2b {
	struct FName *687dcf7d0c; // 0x150(0x08)
};

