// BlueprintGeneratedClass Powerup_Painkillers.Powerup_Painkillers_C
// Size: 0x458 (Inherited: 0x448)
struct APowerup_Painkillers_C : APowerup_Base_C {
	struct F*73a77c28fa UberGraphFrame; // 0x448(0x08)
	struct F*9c84e0ea54 Timer2Handle; // 0x450(0x08)

	void UserConstructionScript(); // Function Powerup_Painkillers.Powerup_Painkillers_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	void ReceiveBeginPlay(); // Function Powerup_Painkillers.Powerup_Painkillers_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x1e037c
	void CustomEvent_1(); // Function Powerup_Painkillers.Powerup_Painkillers_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	void ReceiveDestroyed(); // Function Powerup_Painkillers.Powerup_Painkillers_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x1e037c
	struct FName ExecuteUbergraph_Powerup_Painkillers(); // Function Powerup_Painkillers.Powerup_Painkillers_C.ExecuteUbergraph_Powerup_Painkillers // HasDefaults // @ game+0x1e037c
};

