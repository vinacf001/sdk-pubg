// ScriptStruct LevelSequence.*7feae1615c
// Size: 0x38 (Inherited: 0x00)
struct F*7feae1615c {
	struct UObject* *9fa2c3d738; // 0x00(0x1c)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString ComponentName; // 0x20(0x10)
	struct UObject* *2175440e5d; // 0x30(0x08)
};

// ScriptStruct LevelSequence.*eefc5802d4
// Size: 0x50 (Inherited: 0x00)
struct F*eefc5802d4 {
	struct TMap<struct FGuid, struct F*9f07787fc2> *6aff307cd2; // 0x00(0x50)
};

// ScriptStruct LevelSequence.*9f07787fc2
// Size: 0x10 (Inherited: 0x00)
struct F*9f07787fc2 {
	struct TArray<struct F*f3a51e6218> References; // 0x00(0x10)
};

// ScriptStruct LevelSequence.*f3a51e6218
// Size: 0x20 (Inherited: 0x00)
struct F*f3a51e6218 {
	struct FString PackageName; // 0x00(0x10)
	struct FString ObjectPath; // 0x10(0x10)
};

// ScriptStruct LevelSequence.*4dbebbd2ce
// Size: 0x50 (Inherited: 0x00)
struct F*4dbebbd2ce {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct LevelSequence.*5ffb5d9b5d
// Size: 0x20 (Inherited: 0x00)
struct F*5ffb5d9b5d {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct LevelSequence.*bc40c72930
// Size: 0x50 (Inherited: 0x00)
struct F*bc40c72930 {
	struct FText MasterName; // 0x00(0x18)
	float MasterTime; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FText CurrentShotName; // 0x20(0x18)
	float CurrentShotLocalTime; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct UCameraComponent* CameraComponent; // 0x40(0x08)
	struct F*b2fd281c26 Settings; // 0x48(0x08)
};

// ScriptStruct LevelSequence.*b2fd281c26
// Size: 0x08 (Inherited: 0x00)
struct F*b2fd281c26 {
	bool ZeroPadAmount; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float FrameRate; // 0x04(0x04)
};

// ScriptStruct LevelSequence.*aa2fc4fd6b
// Size: 0x01 (Inherited: 0x00)
struct F*aa2fc4fd6b {
	char pad_0[0x1]; // 0x00(0x01)
};

