// WidgetBlueprintGeneratedClass BP_PcOptionItemStepperWidget.BP_PcOptionItemStepperWidget_C
// Size: 0x8e8 (Inherited: 0x8e0)
struct UBP_PcOptionItemStepperWidget_C : U*8e7feb1906 {
	struct USizeBox* IndentationSizeBox; // 0x8e0(0x08)
};

