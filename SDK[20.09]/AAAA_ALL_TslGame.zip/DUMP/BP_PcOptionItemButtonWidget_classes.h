// WidgetBlueprintGeneratedClass BP_PcOptionItemButtonWidget.BP_PcOptionItemButtonWidget_C
// Size: 0x868 (Inherited: 0x868)
struct UBP_PcOptionItemButtonWidget_C : U*f834ecb527 {
	float *8457bb3677; // 0x7d0(0x04)
	struct UButton* OptionButton; // 0x7d8(0x08)
	struct UTextBlock* OptionButtonText; // 0x7e0(0x08)
	bool *3ea46b2be5; // 0x858(0x01)
	struct F*9c84e0ea54 *5af34cede7; // 0x860(0x08)

	void ShowPopupDialogEx(); // Function TslGame.*f834ecb527.ShowPopupDialogEx // Final|Native|Protected // @ game+0x56f3798
	void OnPopupButtonPressedEvent(); // Function TslGame.*f834ecb527.OnPopupButtonPressedEvent // Final|Native|Protected // @ game+0x56eabf0
};

