// WidgetBlueprintGeneratedClass BP_RankEmblemWidget.BP_RankEmblemWidget_C
// Size: 0x4e8 (Inherited: 0x4e0)
struct UBP_RankEmblemWidget_C : U*d6fbd75522 {
	struct UImage* EmblemImage; // 0x4e0(0x08)
};

