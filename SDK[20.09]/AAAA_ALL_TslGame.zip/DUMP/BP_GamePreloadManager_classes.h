// BlueprintGeneratedClass BP_GamePreloadManager.BP_GamePreloadManager_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBP_GamePreloadManager_C : U*12d7add056 {
	struct TArray<struct FStringAssetReference> *df235348a9; // 0x28(0x10)
	struct TArray<struct FStringAssetReference> *561bbc38b2; // 0x38(0x10)
	struct TMap<enum class ETslPreloadPriority, struct F*53cee72d81> Loaded; // 0x48(0x50)
};

