// BlueprintGeneratedClass FBRBuff_v2_Item_Trap_Ra_Lv3.FBRBuff_v2_Item_Trap_Ra_Lv3_C
// Size: 0x4c8 (Inherited: 0x4c0)
struct AFBRBuff_v2_Item_Trap_Ra_Lv3_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4c0(0x08)
};

