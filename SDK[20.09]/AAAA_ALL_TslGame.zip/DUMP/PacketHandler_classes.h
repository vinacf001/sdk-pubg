// Class PacketHandler.*69f5424441
// Size: 0x28 (Inherited: 0x28)
struct U*69f5424441 : UObject {
};

