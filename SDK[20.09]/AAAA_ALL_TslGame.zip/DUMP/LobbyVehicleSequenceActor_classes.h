// BlueprintGeneratedClass LobbyVehicleSequenceActor.LobbyVehicleSequenceActor_C
// Size: 0x4c0 (Inherited: 0x4c0)
struct ALobbyVehicleSequenceActor_C : ATslLobbyLevelVehicleSequenceActor {
	struct TMap<struct FName, struct ULevelSequence*> *344001afbd; // 0x468(0x50)
};

