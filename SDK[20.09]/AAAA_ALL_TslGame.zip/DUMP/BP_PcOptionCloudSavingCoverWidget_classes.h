// WidgetBlueprintGeneratedClass BP_PcOptionCloudSavingCoverWidget.BP_PcOptionCloudSavingCoverWidget_C
// Size: 0x560 (Inherited: 0x560)
struct UBP_PcOptionCloudSavingCoverWidget_C : U*6a0f3a5121 {
	struct U*6b11b3bf02* Cover_Fade_In; // 0x460(0x08)
	struct U*6b11b3bf02* Cover_Fade_Out; // 0x468(0x08)
	struct U*6b11b3bf02* Warning_Fade_In; // 0x470(0x08)
	struct U*6b11b3bf02* Warning_Fade_Out; // 0x478(0x08)
	struct UTextBlock* Waiting_Text; // 0x480(0x08)
	struct USizeBox* Warning_SizeBox; // 0x488(0x08)
	struct UTextBlock* Warning_Text; // 0x490(0x08)
	struct U*38a6a790e5* *982c921f8d; // 0x498(0x08)

	void *4794f28fef(); // Function TslGame.*6a0f3a5121.*4794f28fef // Final|Native|Public // @ game+0x56d349c
	void *9b34a85d67(); // Function TslGame.*6a0f3a5121.*9b34a85d67 // Final|Native|Public // @ game+0x56d0708
};

