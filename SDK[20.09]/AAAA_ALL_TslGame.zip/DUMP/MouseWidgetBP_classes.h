// WidgetBlueprintGeneratedClass MouseWidgetBP.MouseWidgetBP_C
// Size: 0x468 (Inherited: 0x468)
struct UMouseWidgetBP_C : U*dd77d9bfc8 {
	struct F*eaae7901d4 KeysPanel_Binder; // 0x410(0x20)
	struct F*d3069d51ff MiddleMouseButton_Binder; // 0x430(0x28)
	struct TArray<struct FString> MiddleMouseButtonActionsOrAxies; // 0x458(0x10)
};

