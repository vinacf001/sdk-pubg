// BlueprintGeneratedClass BP_Vantage_LGD.BP_Vantage_LGD_C
// Size: 0x1010 (Inherited: 0x1000)
struct ABP_Vantage_LGD_C : ABP_Vantage_C {
	struct U*4553db084a* VehicleSpecialActionInteraction; // 0x1000(0x08)
	struct UStaticMeshComponent* Windscreen_Special; // 0x1008(0x08)
};

