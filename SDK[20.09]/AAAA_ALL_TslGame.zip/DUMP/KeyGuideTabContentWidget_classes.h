// WidgetBlueprintGeneratedClass KeyGuideTabContentWidget.KeyGuideTabContentWidget_C
// Size: 0x518 (Inherited: 0x500)
struct UKeyGuideTabContentWidget_C : U*8ad6576fd3 {
	struct F*73a77c28fa UberGraphFrame; // 0x500(0x08)
	struct UTextBlock* TitleNormal; // 0x508(0x08)
	struct UTextBlock* TitleSelected; // 0x510(0x08)

	void PreConstruct(); // Function KeyGuideTabContentWidget.KeyGuideTabContentWidget_C.PreConstruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x1e037c
	void ExecuteUbergraph_KeyGuideTabContentWidget(); // Function KeyGuideTabContentWidget.KeyGuideTabContentWidget_C.ExecuteUbergraph_KeyGuideTabContentWidget //  // @ game+0x1e037c
};

