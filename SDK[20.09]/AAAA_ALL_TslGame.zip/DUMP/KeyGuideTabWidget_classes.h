// WidgetBlueprintGeneratedClass KeyGuideTabWidget.KeyGuideTabWidget_C
// Size: 0x468 (Inherited: 0x468)
struct UKeyGuideTabWidget_C : U*f94da2b1a6 {
	struct TArray<struct U*8ad6576fd3*> *acddc294df; // 0x410(0x10)
	struct F*7f3debddd2 *474fdcbb64; // 0x420(0x20)
	struct FMulticastDelegate OnTabRotated; // 0x440(0x10)
	DelegateProperty *5de19b96d1; // 0x450(0x10)

	void RotateRight(); // Function TslGame.*f94da2b1a6.RotateRight // Final|Native|Public|BlueprintCallable // @ game+0x56f13fc
	void UpdateIndexTo(); // Function TslGame.*f94da2b1a6.UpdateIndexTo // Final|Native|Public|BlueprintCallable // @ game+0x56f4de4
	void RotateLeft(); // Function TslGame.*f94da2b1a6.RotateLeft // Final|Native|Public|BlueprintCallable // @ game+0x56f13a4
	void ResetSelector(); // Function TslGame.*f94da2b1a6.ResetSelector // Final|Native|Public|BlueprintCallable // @ game+0x56f1314
};

