// BlueprintGeneratedClass DeathDropItemPackage.DeathDropItemPackage_C
// Size: 0x610 (Inherited: 0x608)
struct ADeathDropItemPackage_C : AFloorSnapItemPackage {
	struct F*73a77c28fa UberGraphFrame; // 0x608(0x08)

	struct TArray<struct FFormatArgumentData> GetCategory(); // Function DeathDropItemPackage.DeathDropItemPackage_C.GetCategory // Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	void UserConstructionScript(); // Function DeathDropItemPackage.DeathDropItemPackage_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	void ReceiveBeginPlay(); // Function DeathDropItemPackage.DeathDropItemPackage_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x1e037c
	int32 ExecuteUbergraph_DeathDropItemPackage(); // Function DeathDropItemPackage.DeathDropItemPackage_C.ExecuteUbergraph_DeathDropItemPackage // HasDefaults // @ game+0x1e037c
};

