// BlueprintGeneratedClass BP_DirectMessageManager.BP_DirectMessageManager_C
// Size: 0x230 (Inherited: 0x230)
struct UBP_DirectMessageManager_C : U*8ebce1f209 {
	struct UStringTable* *7d9ac2fa9d; // 0x28(0x08)
	float *ca4a395f7a; // 0x30(0x04)
	int32 *3bbfc6e3fc; // 0x34(0x04)
	int32 *0c80cb2d4f; // 0x38(0x04)
	float *222cf8817b; // 0x3c(0x04)
	int32 *c9872fe81e; // 0x40(0x04)
	float *7557731f02; // 0x44(0x04)
	int32 *29c582a58d; // 0x48(0x04)
	bool *1804c21f61; // 0x4c(0x01)

	void *e66c1f2daf(struct FWuDirectMessage Param0); // Function TslGame.*8ebce1f209.*e66c1f2daf // Final|Native|Public|HasOutParms // @ game+0x564d0e4
	void *33a1f9c6e3(); // Function TslGame.*8ebce1f209.*33a1f9c6e3 // Final|Native|Public // @ game+0x564c8f4
	void *86ba36298f(); // Function TslGame.*8ebce1f209.*86ba36298f // Final|Native|Public // @ game+0x564d4dc
	void *e66fc02ff2(); // Function TslGame.*8ebce1f209.*e66fc02ff2 // Final|Native|Public // @ game+0x56570f0
	void *b85b7da45b(); // Function TslGame.*8ebce1f209.*b85b7da45b // Final|Native|Public // @ game+0x565163c
};

