// WidgetBlueprintGeneratedClass KeyWidgetBP.KeyWidgetBP_C
// Size: 0x560 (Inherited: 0x548)
struct UKeyWidgetBP_C : U*699e83eed1 {
	struct F*73a77c28fa UberGraphFrame; // 0x548(0x08)
	struct UImage* BorderImage; // 0x550(0x08)
	struct UTextBlock* KeyNameTextBlock; // 0x558(0x08)

	void PreConstruct(); // Function KeyWidgetBP.KeyWidgetBP_C.PreConstruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x1e037c
	struct U*26255869a0* ExecuteUbergraph_KeyWidgetBP(bool ___bool_Variable2, struct FLinearColor K2Node_Select_Default); // Function KeyWidgetBP.KeyWidgetBP_C.ExecuteUbergraph_KeyWidgetBP // HasDefaults // @ game+0x1e037c
};

