// BlueprintGeneratedClass FBRBuff2021_Flare_wi_lv2.FBRBuff2021_Flare_wi_lv2_C
// Size: 0x4c8 (Inherited: 0x4c0)
struct AFBRBuff2021_Flare_wi_lv2_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4c0(0x08)
};

