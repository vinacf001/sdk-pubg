// BlueprintGeneratedClass BP_EmPickup_Castable.BP_EmPickup_Castable_C
// Size: 0x90 (Inherited: 0x90)
struct UBP_EmPickup_Castable_C : U*2b2b6d8736 {
	struct UClass* BalloonClass; // 0x28(0x20)
	struct UClass* *b1f11ca139; // 0x48(0x08)
	struct F*a6cf5e6125 PlacementTraceParams; // 0x50(0x3c)
	bool bCanBeUsedIndoors; // 0x8c(0x01)

	struct ATslCharacter* *a2e0148d3e(); // Function TslGame.*2b2b6d8736.*a2e0148d3e // Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure // @ game+0x564728c
};

