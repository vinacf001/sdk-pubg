// BlueprintGeneratedClass BP_MasteryPose_Bush.BP_MasteryPose_Bush_C
// Size: 0x458 (Inherited: 0x440)
struct ABP_MasteryPose_Bush_C : ABP_MasteryPose_C {
	struct UAsyncStaticMeshComponent* GrassMesh; // 0x440(0x08)
	struct UAsyncStaticMeshComponent* BushMesh; // 0x448(0x08)
	struct USpotLightComponent* spotlight; // 0x450(0x08)
};

