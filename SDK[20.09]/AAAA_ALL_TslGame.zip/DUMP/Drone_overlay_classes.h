// WidgetBlueprintGeneratedClass Drone_overlay.Drone_overlay_C
// Size: 0x350 (Inherited: 0x2e0)
struct UDrone_overlay_C : U*2fa80acbf8 {
	struct F*73a77c28fa UberGraphFrame; // 0x2e0(0x08)
	struct UImage* AltitudeMeter; // 0x2e8(0x08)
	struct UImage* Brackets; // 0x2f0(0x08)
	struct UImage* DisableBg; // 0x2f8(0x08)
	struct UVerticalBox* DroneInventoryVerticalBox; // 0x300(0x08)
	struct UImage* Image_96; // 0x308(0x08)
	struct UImage* Image_103; // 0x310(0x08)
	struct UImage* Image_332; // 0x318(0x08)
	struct UImage* Image_350; // 0x320(0x08)
	struct UImage* Image_635; // 0x328(0x08)
	struct UImage* Img_BgLine; // 0x330(0x08)
	struct UImage* Img_IconBg; // 0x338(0x08)
	struct USafeZone* SafeZone_1; // 0x340(0x08)
	struct UTextBlock* TextBlock_100; // 0x348(0x08)

	void ExecuteUbergraph_Drone_overlay(); // Function Drone_overlay.Drone_overlay_C.ExecuteUbergraph_Drone_overlay //  // @ game+0x1e037c
};

