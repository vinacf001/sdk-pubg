// WidgetBlueprintGeneratedClass BP_DisplayOptionWidget.BP_DisplayOptionWidget_C
// Size: 0xa60 (Inherited: 0xa30)
struct UBP_DisplayOptionWidget_C : U*39f2c22c49 {
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget; // 0xa30(0x08)
	struct UBP_GamepadMultipleKeyIconWidget_C* BP_GamepadMultipleKeyIconWidget_1; // 0xa38(0x08)
	struct UTextBlock* BtnsKM_0_Text; // 0xa40(0x08)
	struct UTextBlock* BtnsKM_1_Text; // 0xa48(0x08)
	struct UBP_DisplayOptionSliderWidget_C* DisplayOptionSlider; // 0xa50(0x08)
	struct UImage* IconBgImage; // 0xa58(0x08)
};

