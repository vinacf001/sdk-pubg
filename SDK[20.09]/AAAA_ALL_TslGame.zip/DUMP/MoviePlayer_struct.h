// Enum MoviePlayer.*c488183f22
enum class *c488183f22 : uint8 {
	*ecdfc9288a,
	*673c0c00e7,
	*d922c5ce8b,
	*b7bdd2a004,
	*c488183f22_MAX,
};

