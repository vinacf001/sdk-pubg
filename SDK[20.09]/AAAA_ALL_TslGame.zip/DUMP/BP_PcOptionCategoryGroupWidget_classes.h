// WidgetBlueprintGeneratedClass BP_PcOptionCategoryGroupWidget.BP_PcOptionCategoryGroupWidget_C
// Size: 0x4b0 (Inherited: 0x4b0)
struct UBP_PcOptionCategoryGroupWidget_C : U*f006d355bb {
	struct FName *ea3a0b9286; // 0x410(0x08)
	struct FName *70b3f5339d; // 0x418(0x08)
	struct FName CategoryName; // 0x420(0x08)
	bool *6d164355e5; // 0x428(0x01)
	struct U*38a6a790e5* *982c921f8d; // 0x430(0x08)
	struct F*f4f57b85a2 DisplayNameText_Binder; // 0x438(0x20)
	struct F*f0cac2bec7 ItemWidgetsVerticalBox_Binder; // 0x458(0x28)
	struct UButton* HoverHighlightButton; // 0x480(0x08)
	struct UImage* TooltipIconImage; // 0x488(0x08)
	struct FLinearColor ColorNormal; // 0x490(0x10)
	struct FLinearColor ColorTooltipIconHighlighted; // 0x4a0(0x10)

	void OnCloudOptionTooltipActivated(); // Function TslGame.*f006d355bb.OnCloudOptionTooltipActivated // Final|Native|Public // @ game+0x56e5f68
	void OnCloudOptionTooltipDeactivated(); // Function TslGame.*f006d355bb.OnCloudOptionTooltipDeactivated // Final|Native|Public // @ game+0x56e5f7c
};

