// WidgetBlueprintGeneratedClass HoldableKeyImageWIdgetBP.HoldableKeyImageWidgetBP_C
// Size: 0x4c8 (Inherited: 0x4c8)
struct UHoldableKeyImageWidgetBP_C : U*e21e041c4a {
	struct UImage* KeyboardHoldSpinner; // 0x468(0x08)
	struct U*c1ef4cc603* KeyboardHoldSpinnerPanel; // 0x470(0x08)
	struct UImage* MouseHoldSpinner; // 0x478(0x08)
	struct U*c1ef4cc603* MouseHoldSpinnerPanel; // 0x480(0x08)
	struct UImage* DoubleTapImage; // 0x488(0x08)
	struct UImage* HoldTriangleImage; // 0x490(0x08)
	struct U*6b11b3bf02* HoldAnimation; // 0x498(0x08)
	struct UMaterialParameterCollection* InteractionHoldMPC; // 0x4a0(0x08)
	float HoldDuration; // 0x4a8(0x04)
	float *6be37009f9; // 0x4ac(0x04)
	bool *d07fd2e587; // 0x4b0(0x01)
	bool *646ee865ae; // 0x4b1(0x01)
	bool *a9180b69c4; // 0x4b2(0x01)
	enum class EKeyboardKeyIconDisplayType *b159113adc; // 0x4b3(0x01)
	struct FName ActionName; // 0x4b8(0x08)

	void HoldKeyboard(bool Param0); // Function TslGame.*e21e041c4a.HoldKeyboard // Final|Native|Protected // @ game+0x56e3100
};

