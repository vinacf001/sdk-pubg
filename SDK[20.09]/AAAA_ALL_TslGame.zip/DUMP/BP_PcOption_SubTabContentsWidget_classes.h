// WidgetBlueprintGeneratedClass BP_PcOption_SubTabContentsWidget.BP_PcOption_SubTabContentsWidget_C
// Size: 0x430 (Inherited: 0x430)
struct UBP_PcOption_SubTabContentsWidget_C : U*869355da1e {
	struct UClass* CategoryGroupWidgetClass; // 0x420(0x08)
	struct UScrollBox* CategoryGroupsScrollBox; // 0x428(0x08)
};

