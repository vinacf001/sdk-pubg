// BlueprintGeneratedClass LaserPointerAttachment.LaserPointerAttachment_C
// Size: 0xca0 (Inherited: 0xca0)
struct ULaserPointerAttachment_C : U*bc8135a912 {
	struct UParticleSystem* *67c6bb134f; // 0xc30(0x08)
	struct FName *bdb0c61a2c; // 0xc38(0x08)
	float *af3e01db8c; // 0xc40(0x04)
	struct U*1ba2d2b086* *d75fb5986e; // 0xc48(0x08)
	float *28bc740fd2; // 0xc50(0x04)
	struct FLinearColor *51922b196a; // 0xc54(0x10)
	float *488b2a9067; // 0xc64(0x04)
	float *86316c47e6; // 0xc68(0x04)
	struct UParticleSystemComponent* *2161edbf77; // 0xc70(0x08)
	struct USpotLightComponent* *e6959f5911; // 0xc78(0x08)
	struct ATslCharacter* Character; // 0xc80(0x08)
	struct ATslWeapon_Gun* Gun; // 0xc88(0x08)

	void *874b49e026(); // Function TslGame.*bc8135a912.*874b49e026 // Final|Native|Private|BlueprintCallable // @ game+0x5635e44
	void ActivateLaser(); // Function TslGame.*bc8135a912.ActivateLaser // Final|Native|Private // @ game+0x5607e98
	void *57704b135e(); // Function TslGame.*bc8135a912.*57704b135e // Final|Native|Private // @ game+0x5620190
};

