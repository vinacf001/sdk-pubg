// WidgetBlueprintGeneratedClass BP_KillLogVictimButton.BP_KillLogVictimButton_C
// Size: 0x700 (Inherited: 0x6f0)
struct UBP_KillLogVictimButton_C : U*2c5af6f77d {
	struct F*73a77c28fa UberGraphFrame; // 0x6f0(0x08)
	struct UButton* Button_1; // 0x6f8(0x08)

	void BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function BP_KillLogVictimButton.BP_KillLogVictimButton_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x1e037c
	void ExecuteUbergraph_BP_KillLogVictimButton(); // Function BP_KillLogVictimButton.BP_KillLogVictimButton_C.ExecuteUbergraph_BP_KillLogVictimButton //  // @ game+0x1e037c
};

