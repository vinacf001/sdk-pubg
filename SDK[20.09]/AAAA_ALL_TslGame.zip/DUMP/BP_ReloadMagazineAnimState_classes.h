// BlueprintGeneratedClass BP_ReloadMagazineAnimState.BP_ReloadMagazineAnimState_C
// Size: 0x48 (Inherited: 0x38)
struct UBP_ReloadMagazineAnimState_C : U*261bae6f8b {
	enum class Enum_MagazineReloadAnimStateActionType ActionType; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct AActor* Gun; // 0x40(0x08)
};

