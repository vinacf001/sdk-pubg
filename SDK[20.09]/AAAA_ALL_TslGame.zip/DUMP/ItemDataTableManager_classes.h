// BlueprintGeneratedClass ItemDataTableManager.ItemDataTableManager_C
// Size: 0x4f0 (Inherited: 0x4f0)
struct UItemDataTableManager_C : U*88f02e29e6 {
	struct F*934241cd34 *6f41e8a62c; // 0x70(0x180)
	struct TArray<struct UDataTable*> Tables; // 0x1f8(0x10)
	struct F*3ede8d9757 *3ede8d9757; // 0x2f8(0xa0)
	struct TArray<struct FName> *c404f85e0a; // 0x3f8(0x10)
	struct TArray<struct FName> *fdb56bc72b; // 0x408(0x10)
	struct TArray<struct FName> *dfb31fb113; // 0x418(0x10)
	struct TArray<struct FName> *8e7654de30; // 0x428(0x10)
	struct TArray<struct FName> *78a574be4b; // 0x438(0x10)
	struct TArray<struct FName> *5dd0179124; // 0x448(0x10)
	struct TArray<struct FName> *4dd174b5c1; // 0x458(0x10)
	struct TArray<struct FName> *c949f05130; // 0x468(0x10)
	struct TArray<struct FName> *e91ecf0c08; // 0x478(0x10)
	struct TArray<struct FName> *3baf3768b1; // 0x488(0x10)
	struct TArray<struct FName> *b1efa6f8b8; // 0x498(0x10)
	struct TArray<struct FName> *8553694d32; // 0x4a8(0x10)
	struct TArray<struct FName> *1f0899459e; // 0x4b8(0x10)
	struct TArray<struct FName> *6e0f8dc182; // 0x4c8(0x10)
	struct TArray<struct FName> *ee79a26cb9; // 0x4d8(0x10)
};

