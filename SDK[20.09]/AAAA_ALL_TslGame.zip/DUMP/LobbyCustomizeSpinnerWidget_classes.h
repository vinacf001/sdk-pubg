// WidgetBlueprintGeneratedClass LobbyCustomizeSpinnerWidget.LobbyCustomizeSpinnerWidget_C
// Size: 0x428 (Inherited: 0x420)
struct ULobbyCustomizeSpinnerWidget_C : U*fae9ecea58 {
	struct UImage* LoadingSpinnerImage; // 0x420(0x08)
};

