// WidgetBlueprintGeneratedClass BP_PcOptionItemSliderWidget.BP_PcOptionItemSliderWidget_C
// Size: 0x870 (Inherited: 0x868)
struct UBP_PcOptionItemSliderWidget_C : U*241f31645a {
	struct USizeBox* IndentationSizeBox; // 0x868(0x08)
};

