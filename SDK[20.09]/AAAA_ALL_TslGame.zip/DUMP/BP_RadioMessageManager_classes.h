// BlueprintGeneratedClass BP_RadioMessageManager.BP_RadioMessageManager_C
// Size: 0x620 (Inherited: 0x620)
struct UBP_RadioMessageManager_C : U*76ae821617 {
	bool *335c462b09; // 0x500(0x01)
	struct UStringTable* *2ab2fe1a86; // 0x508(0x08)
	struct UDataTable* *a9964f18c3; // 0x510(0x08)
	struct UDataTable* *3edd4a24d0; // 0x518(0x08)
	float *d4b53e74fd; // 0x520(0x04)
	float *ca4a395f7a; // 0x524(0x04)
	int32 *3bbfc6e3fc; // 0x528(0x04)
	float *222cf8817b; // 0x52c(0x04)
	int32 *c9872fe81e; // 0x530(0x04)
	float *7557731f02; // 0x534(0x04)
	float *0fe7c4101d; // 0x538(0x04)
	float *185dc9003c; // 0x53c(0x04)
	float *91c478a622; // 0x540(0x04)
	struct TArray<float> *3089f1c5ed; // 0x548(0x10)
	SetProperty *610b0ef785; // 0x5a0(0x50)
	struct UStringTable* *cfdb060cdf; // 0x608(0x08)
	struct TArray<enum class EGameModeType> *aade42d3cc; // 0x610(0x10)
};

