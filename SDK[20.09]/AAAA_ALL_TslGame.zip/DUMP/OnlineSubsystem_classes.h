// Class OnlineSubsystem.NamedInterfaces
// Size: 0xc0 (Inherited: 0x28)
struct UNamedInterfaces : UObject {
	struct TArray<struct F*38eedad185> *24aa564d2e; // 0x28(0x10)
	struct TArray<struct F*c93a91e800> NamedInterfaceDefs; // 0x38(0x10)
	char pad_48[0x78]; // 0x48(0x78)
};

// Class OnlineSubsystem.*6928e405e2
// Size: 0x28 (Inherited: 0x28)
struct U*6928e405e2 : UInterface {
};

