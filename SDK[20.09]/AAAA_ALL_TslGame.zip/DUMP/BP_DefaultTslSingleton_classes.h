// BlueprintGeneratedClass BP_DefaultTslSingleton.BP_DefaultTslSingleton_C
// Size: 0x12d8 (Inherited: 0x12d8)
struct UBP_DefaultTslSingleton_C : U*c2312fa369 {
	struct U*07b9fd50d4* *a5115dc5cd; // 0xe8(0x08)
	struct TArray<struct F*eed0e853bc> *ad39945af1; // 0xf0(0x10)
	struct TMap<struct FString, struct FString> *ca5d13d19c; // 0x100(0x50)
	struct U*ef8e403dff* *ef8e403dff; // 0x150(0x08)
	struct UDataTable* *44249f67d0; // 0x158(0x08)
	struct UDataTable* *a4aa0cc524; // 0x160(0x08)
	struct TMap<struct FName, struct F*92674ee893> *243e47f572; // 0x168(0x50)
	struct UClass* *0804fdb9e8; // 0x1b8(0x08)
	struct UClass* *dd642b843e; // 0x1c0(0x08)
	struct FStringAssetReference *3a671ee8ff; // 0x1c8(0x10)
	struct UDataTable* *88bea4e304; // 0x1d8(0x08)
	struct UDataTable* *63ece39c31; // 0x1e0(0x08)
	struct UDataTable* *ad837b4a44; // 0x1e8(0x08)
	struct FStringAssetReference *9048144095; // 0x1f0(0x10)
	struct FStringClassReference *717123d1e7; // 0x200(0x10)
	struct FStringClassReference *113437d5ed; // 0x210(0x10)
	struct FStringAssetReference *cd1790ee3e; // 0x220(0x10)
	struct UUniqueWeaponDataAsset* UniqueWeaponDataAsset; // 0x230(0x08)
	struct UDataTable* *e08624f3eb; // 0x238(0x08)
	struct FStringAssetReference *4ebd6b6044; // 0x240(0x10)
	struct UDataTable* *d92be1648b; // 0x250(0x08)
	struct FStringAssetReference *22eeb3f434; // 0x258(0x10)
	struct FStringAssetReference *1e811a23e8; // 0x268(0x10)
	struct UClass* *67281b2a7a; // 0x278(0x08)
	struct FStringClassReference *94d4eed905; // 0x280(0x10)
	struct UStaticMesh* *cfc6ccc890; // 0x290(0x20)
	struct UDataTable* *da82ac46ae; // 0x2b0(0x08)
	struct UStringTable* *7e89840803; // 0x2b8(0x08)
	struct F*94738f547e *6903e04ee8; // 0x2c0(0xc40)
	float *0c3eeb9f64; // 0xf00(0x04)
	float *83868b2c7f; // 0xf04(0x04)
	float *f63c4d7799; // 0xf08(0x04)
	struct TArray<struct F*b8d1a82639> *a0de0a9d4b; // 0xf10(0x10)
	struct TArray<struct FName> *8ee24d5afd; // 0xf20(0x10)
	struct UClass* *b3f6ade4c4; // 0xf30(0x20)
	struct UClass* *6e7f9a856d; // 0xf50(0x08)
	struct UClass* *005dff5b44; // 0xf58(0x08)
	struct U*88f02e29e6* *84eaa6efcd; // 0xf60(0x08)
	struct UTslPubgIdAssetManager* *96b26bc8d6; // 0xf68(0x08)
	struct UClass* *c9cd1e501d; // 0xf70(0x08)
	struct U*ffa189cdc3* *b566bf1b21; // 0xf78(0x08)
	struct U*8a11305d66* *8bdb4d12d5; // 0xf80(0x08)
	struct U*e671635853* *1430e47e5d; // 0xf88(0x08)
	struct F*303ba27a65 *736b6bf381; // 0xf90(0x340)
	struct UDataTable* *a7ba77be53; // 0x12d0(0x08)

	void *2a11883a34(); // Function TslGame.*c2312fa369.*2a11883a34 // Final|Native|Public // @ game+0x56c8e68
	void *4d0e619025(); // Function TslGame.*c2312fa369.*4d0e619025 // Final|Native|Private // @ game+0x56d0650
	void *43d454bef2(); // Function TslGame.*c2312fa369.*43d454bef2 // Final|Native|Public // @ game+0x56c8ec0
	void *2f1b98dea7(); // Function TslGame.*c2312fa369.*2f1b98dea7 // Final|Native|Public // @ game+0x56c8ea8
	void *b08e493979(); // Function TslGame.*c2312fa369.*b08e493979 // Final|Native|Public|Const // @ game+0x56c4f48
	void *1224e925a8(); // Function TslGame.*c2312fa369.*1224e925a8 // Final|Native|Public|Const // @ game+0x56c8e50
};

