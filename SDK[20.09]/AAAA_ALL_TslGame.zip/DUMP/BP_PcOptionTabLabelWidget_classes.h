// WidgetBlueprintGeneratedClass BP_PcOptionTabLabelWidget.BP_PcOptionTabLabelWidget_C
// Size: 0x4b8 (Inherited: 0x4b8)
struct UBP_PcOptionTabLabelWidget_C : U*a305babf06 {
	struct FName *f629e70e0e; // 0x410(0x08)
	struct F*7f3debddd2 LabelButton_Binder; // 0x418(0x20)
	struct F*f4f57b85a2 LabelText_Binder; // 0x438(0x20)
	struct F*8e32972a91 HighlightDecoration_Binder; // 0x458(0x28)
	struct FLinearColor LabelTextNormalColor; // 0x480(0x10)
	struct FLinearColor LabelTextHighlightColor; // 0x490(0x10)
	struct UBorder* Active_Border; // 0x4a0(0x08)

	void OnLabelButtonClicked(); // Function TslGame.*a305babf06.OnLabelButtonClicked // Final|Native|Private // @ game+0x56e8b18
};

