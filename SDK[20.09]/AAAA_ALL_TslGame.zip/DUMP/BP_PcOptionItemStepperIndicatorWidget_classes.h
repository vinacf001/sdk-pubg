// WidgetBlueprintGeneratedClass BP_PcOptionItemStepperIndicatorWidget.BP_PcOptionItemStepperIndicatorWidget_C
// Size: 0x4b8 (Inherited: 0x4b8)
struct UBP_PcOptionItemStepperIndicatorWidget_C : U*8fa7e75b36 {
	struct U*8e7feb1906* Owner; // 0x410(0x08)
	int32 Index; // 0x418(0x04)
	struct F*c69f8ed24a SizeBox_Binder; // 0x420(0x28)
	struct F*7f3debddd2 Button_Binder; // 0x448(0x20)
	struct F*959656208f InnerBorder_Binder; // 0x468(0x30)
	struct FLinearColor ColorNormal; // 0x498(0x10)
	struct FLinearColor ColorHighlighted; // 0x4a8(0x10)

	void OnClicked(); // Function TslGame.*8fa7e75b36.OnClicked // Final|Native|Public // @ game+0x56e5d4c
};

