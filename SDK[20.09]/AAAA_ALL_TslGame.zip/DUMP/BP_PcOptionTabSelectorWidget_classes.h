// WidgetBlueprintGeneratedClass BP_PcOptionTabSelectorWidget.BP_PcOptionTabSelectorWidget_C
// Size: 0x470 (Inherited: 0x448)
struct UBP_PcOptionTabSelectorWidget_C : U*3b7d7321c7 {
	struct UBP_GamepadKeyIconWidget_C* BP_GamepadKeyIconWidget; // 0x448(0x08)
	struct UBP_GamepadKeyIconWidget_C* BP_GamepadKeyIconWidget_1; // 0x450(0x08)
	struct U*3bbae755be* GamepadLB; // 0x458(0x08)
	struct U*3bbae755be* GamepadRB; // 0x460(0x08)
	struct UInvalidationBox* InvalidationBox_6; // 0x468(0x08)
};

