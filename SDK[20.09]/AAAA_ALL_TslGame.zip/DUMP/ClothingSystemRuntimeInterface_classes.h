// Class ClothingSystemRuntimeInterface.*9695c7a28c
// Size: 0x48 (Inherited: 0x28)
struct U*9695c7a28c : UObject {
	struct FString *93c6c71b46; // 0x28(0x10)
	struct FGuid *01d392c645; // 0x38(0x10)
};

// Class ClothingSystemRuntimeInterface.*b14b3c8b7b
// Size: 0x28 (Inherited: 0x28)
struct U*b14b3c8b7b : UObject {
};

