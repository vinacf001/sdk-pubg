// BlueprintGeneratedClass M_OutPlayArea2.M_OutPlayArea2_C
// Size: 0x488 (Inherited: 0x478)
struct AM_OutPlayArea2_C : ATslPostProcessEffect {
	struct F*73a77c28fa UberGraphFrame; // 0x478(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x480(0x08)

	void UserConstructionScript(); // Function M_OutPlayArea2.M_OutPlayArea2_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	struct FString OnSetEffectParameter(); // Function M_OutPlayArea2.M_OutPlayArea2_C.OnSetEffectParameter // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x1e037c
	bool ExecuteUbergraph_M_OutPlayArea2(); // Function M_OutPlayArea2.M_OutPlayArea2_C.ExecuteUbergraph_M_OutPlayArea2 //  // @ game+0x1e037c
};

