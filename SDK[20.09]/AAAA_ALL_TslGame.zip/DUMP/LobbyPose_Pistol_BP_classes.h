// BlueprintGeneratedClass LobbyPose_Pistol_BP.LobbyPose_Pistol_BP_C
// Size: 0x480 (Inherited: 0x480)
struct ALobbyPose_Pistol_BP_C : ATslAnimSpawnSkeletalObject {
	struct UAnimSequence* *d55f6c33de; // 0x478(0x08)
};

