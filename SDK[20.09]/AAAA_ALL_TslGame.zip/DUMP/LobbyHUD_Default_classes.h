// BlueprintGeneratedClass LobbyHUD_Default.LobbyHUD_Default_C
// Size: 0x19e8 (Inherited: 0x19e0)
struct ALobbyHUD_Default_C : ALobbyHUD {
	struct F*73a77c28fa UberGraphFrame; // 0x19e0(0x08)

	void UserConstructionScript(); // Function LobbyHUD_Default.LobbyHUD_Default_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	void ReceivePostBeginPlay(); // Function LobbyHUD_Default.LobbyHUD_Default_C.ReceivePostBeginPlay // Event|Public|BlueprintEvent // @ game+0x1e037c
	void ExecuteUbergraph_LobbyHUD_Default(); // Function LobbyHUD_Default.LobbyHUD_Default_C.ExecuteUbergraph_LobbyHUD_Default //  // @ game+0x1e037c
};

