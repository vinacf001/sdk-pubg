// ScriptStruct GeometryCache.*87007d3e22
// Size: 0x50 (Inherited: 0x00)
struct F*87007d3e22 {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct GeometryCache.*f1a00d06ef
// Size: 0x50 (Inherited: 0x00)
struct F*f1a00d06ef {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct GeometryCache.*051638b3da
// Size: 0x0c (Inherited: 0x00)
struct F*051638b3da {
	char pad_0[0xc]; // 0x00(0x0c)
};

