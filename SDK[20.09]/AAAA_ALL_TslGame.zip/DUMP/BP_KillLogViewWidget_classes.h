// WidgetBlueprintGeneratedClass BP_KillLogViewWidget.BP_KillLogViewWidget_C
// Size: 0x450 (Inherited: 0x438)
struct UBP_KillLogViewWidget_C : U*e07797b531 {
	struct F*73a77c28fa UberGraphFrame; // 0x438(0x08)
	struct UButton* Button_1; // 0x440(0x08)
	struct UImage* DebugCrosshair; // 0x448(0x08)

	void BndEvt__Button_0_K2Node_ComponentBoundEvent_116_OnButtonClickedEvent__DelegateSignature(); // Function BP_KillLogViewWidget.BP_KillLogViewWidget_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_116_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x1e037c
	struct APlayerController* ExecuteUbergraph_BP_KillLogViewWidget(int32 EntryPoint); // Function BP_KillLogViewWidget.BP_KillLogViewWidget_C.ExecuteUbergraph_BP_KillLogViewWidget //  // @ game+0x1e037c
};

