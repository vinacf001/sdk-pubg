// BlueprintGeneratedClass BP_SandboxManager_Training.BP_SandboxManager_Training_C
// Size: 0x5c0 (Inherited: 0x5c0)
struct UBP_SandboxManager_Training_C : U*69acd6e3f5 {
	float *34d07bf453; // 0x5b8(0x04)
};

