// Class InputCore.*7f6c7381bd
// Size: 0x28 (Inherited: 0x28)
struct U*7f6c7381bd : UObject {
};

