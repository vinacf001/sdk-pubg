// WidgetBlueprintGeneratedClass BP_PcOptionInputBlockerWidget.BP_PcOptionInputBlockerWidget_C
// Size: 0x468 (Inherited: 0x468)
struct UBP_PcOptionInputBlockerWidget_C : U*5ac73eb87f {
	struct U*38a6a790e5* Owner; // 0x460(0x08)
};

