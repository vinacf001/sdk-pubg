// BlueprintGeneratedClass BP_JerryCan_CastableImplement.BP_JerryCan_CastableImplement_C
// Size: 0x160 (Inherited: 0x160)
struct UBP_JerryCan_CastableImplement_C : U*bd01736211 {
	struct F*d632a80c24 *d632a80c24; // 0x28(0x130)
	enum class ECastableItemType *6482583803; // 0x158(0x01)
};

