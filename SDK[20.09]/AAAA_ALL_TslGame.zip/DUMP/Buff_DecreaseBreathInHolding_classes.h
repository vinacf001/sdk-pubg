// BlueprintGeneratedClass Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C
// Size: 0x4a0 (Inherited: 0x480)
struct ABuff_DecreaseBreathInHolding_C : ACharacterBreathBuff {
	struct F*73a77c28fa UberGraphFrame; // 0x480(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x488(0x08)
	struct F*dae3044c79 BuffClass; // 0x490(0x10)

	enum class EBreathType UserConstructionScript(); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	void TickBuff(); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.TickBuff // Event|Public|BlueprintEvent // @ game+0x1e037c
	enum class EBreathType ExecuteUbergraph_Buff_DecreaseBreathInHolding(int32 EntryPoint, float CallFunc__dbbd9a6658_ReturnValue, bool CallFunc__cd60d899db_ReturnValue, bool K2Node_ClassDynamicCast_bSuccess); // Function Buff_DecreaseBreathInHolding.Buff_DecreaseBreathInHolding_C.ExecuteUbergraph_Buff_DecreaseBreathInHolding //  // @ game+0x1e037c
};

