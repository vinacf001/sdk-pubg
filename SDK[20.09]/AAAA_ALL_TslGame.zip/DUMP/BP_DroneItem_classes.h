// BlueprintGeneratedClass BP_DroneItem.BP_DroneItem_C
// Size: 0x380 (Inherited: 0x380)
struct UBP_DroneItem_C : U*d44c6de977 {
	struct UClass* *3af32c5044; // 0x348(0x08)
	struct UStaticMesh* *c1f039f690; // 0x350(0x20)
	struct ATslDrone* *1d755cd050; // 0x370(0x08)
};

