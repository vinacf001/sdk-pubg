// WidgetBlueprintGeneratedClass BP_PcOptionSupplementaryPreviewMaterialWidget.BP_PcOptionSupplementaryPreviewMaterialWidget_C
// Size: 0x498 (Inherited: 0x498)
struct UBP_PcOptionSupplementaryPreviewMaterialWidget_C : U*68ae082d73 {
	struct F*d3069d51ff Image_Binder; // 0x410(0x28)
	struct TMap<struct FString, struct F*0ffa8a44ff> *826f0a0c8e; // 0x438(0x50)
	struct FString *c7610f1de5; // 0x488(0x10)
};

