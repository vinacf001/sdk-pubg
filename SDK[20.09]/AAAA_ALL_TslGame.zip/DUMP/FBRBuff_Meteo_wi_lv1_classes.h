// BlueprintGeneratedClass FBRBuff_Meteo_wi_lv1.FBRBuff_Meteo_wi_lv1_C
// Size: 0x4c8 (Inherited: 0x4c0)
struct AFBRBuff_Meteo_wi_lv1_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4c0(0x08)
};

