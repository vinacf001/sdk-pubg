// BlueprintGeneratedClass Buff_BreakSunkenVehicle.Buff_BreakSunkenVehicle_C
// Size: 0x488 (Inherited: 0x478)
struct ABuff_BreakSunkenVehicle_C : ATslBuff {
	struct F*73a77c28fa UberGraphFrame; // 0x478(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x480(0x08)

	void UserConstructionScript(); // Function Buff_BreakSunkenVehicle.Buff_BreakSunkenVehicle_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	void TickBuff(); // Function Buff_BreakSunkenVehicle.Buff_BreakSunkenVehicle_C.TickBuff // Event|Public|BlueprintEvent // @ game+0x1e037c
	void StopBuffBlueprint(); // Function Buff_BreakSunkenVehicle.Buff_BreakSunkenVehicle_C.StopBuffBlueprint // Event|Public|BlueprintEvent // @ game+0x1e037c
	struct APawn* ExecuteUbergraph_Buff_BreakSunkenVehicle(struct U*456eb1620c* CallFunc__74ebe1bdc5_ReturnValue2); // Function Buff_BreakSunkenVehicle.Buff_BreakSunkenVehicle_C.ExecuteUbergraph_Buff_BreakSunkenVehicle //  // @ game+0x1e037c
};

