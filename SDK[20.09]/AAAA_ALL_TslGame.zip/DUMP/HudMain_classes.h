// WidgetBlueprintGeneratedClass HudMain.HudMain_C
// Size: 0x4d8 (Inherited: 0x4d8)
struct UHudMain_C : U*3e1e6cf138 {
	struct UCanvasPanel* HideOnObserverSpectating; // 0x420(0x08)
	float *5b8460cafc; // 0x428(0x04)
	float *d98eda56d1; // 0x42c(0x04)
	struct U*17e02c3a8c* HitNotifyWidget; // 0x468(0x08)
	struct UClass* *02bbbf9f46; // 0x470(0x20)
	struct UClass* *e9142a50a8; // 0x490(0x20)

	void OnKey_ShowCarePackageItemList(); // Function TslGame.*3e1e6cf138.OnKey_ShowCarePackageItemList // Final|Native|Private // @ game+0xb40a24
	void OnKey_ToggleHealItemWheelReleased(); // Function TslGame.*3e1e6cf138.OnKey_ToggleHealItemWheelReleased // Final|Native|Private // @ game+0x56e8a10
	void OnKey_ToggleEmoteWheelPressed(); // Function TslGame.*3e1e6cf138.OnKey_ToggleEmoteWheelPressed // Final|Native|Private // @ game+0x56e89d4
	void ShowReplayTimeLine(); // Function TslGame.*3e1e6cf138.ShowReplayTimeLine // Final|Native|Private // @ game+0x56f37ac
	void OnKey_ToggleEmoteWheelReleased(); // Function TslGame.*3e1e6cf138.OnKey_ToggleEmoteWheelReleased // Final|Native|Private // @ game+0x56e89e8
	void OnKey_ToggleAnticheatCenterbar(); // Function TslGame.*3e1e6cf138.OnKey_ToggleAnticheatCenterbar // Final|Native|Private // @ game+0x56e89c0
	void OnKey_SystemMenuOrEscape(); // Function TslGame.*3e1e6cf138.OnKey_SystemMenuOrEscape // Final|Native|Private // @ game+0x56e89ac
	void OnKey_MapCharacterIconShowNameOnly(); // Function TslGame.*3e1e6cf138.OnKey_MapCharacterIconShowNameOnly // Final|Native|Private // @ game+0x56e8980
	void OnKey_ToggleThrowableItemWheelPressed(); // Function TslGame.*3e1e6cf138.OnKey_ToggleThrowableItemWheelPressed // Final|Native|Private // @ game+0x56e8a38
	void OnKey_MapCharacterIconShowBoth(); // Function TslGame.*3e1e6cf138.OnKey_MapCharacterIconShowBoth // Final|Native|Private // @ game+0x56e8950
	void HideMapForReplay(); // Function TslGame.*3e1e6cf138.HideMapForReplay // Final|Native|Private // @ game+0x56e3018
	void OnKey_MapCharacterIconShowIconOnly(); // Function TslGame.*3e1e6cf138.OnKey_MapCharacterIconShowIconOnly // Final|Native|Private // @ game+0x56e8968
	void OnKey_ToggleOption(); // Function TslGame.*3e1e6cf138.OnKey_ToggleOption // Final|Native|Private // @ game+0x56e8a24
	void SetObserverSpectatingUpTransform(); // Function TslGame.*3e1e6cf138.SetObserverSpectatingUpTransform // Final|Native|Public|BlueprintCallable // @ game+0x56f28cc
	void SetObserverSpectatingDownTransform(); // Function TslGame.*3e1e6cf138.SetObserverSpectatingDownTransform // Final|Native|Public|BlueprintCallable // @ game+0x56f28b0
	void OnKey_ToggleThrowableItemWheelReleased(); // Function TslGame.*3e1e6cf138.OnKey_ToggleThrowableItemWheelReleased // Final|Native|Private // @ game+0x56e8a4c
	void OnKey_ToggleHealItemWheelPressed(); // Function TslGame.*3e1e6cf138.OnKey_ToggleHealItemWheelPressed // Final|Native|Private // @ game+0x56e89fc
	void OnKey_ReplayMenuOrEscape(); // Function TslGame.*3e1e6cf138.OnKey_ReplayMenuOrEscape // Final|Native|Private // @ game+0x56e8998
};

