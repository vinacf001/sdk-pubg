// WidgetBlueprintGeneratedClass KeyImageWIdgetBP.KeyImageWIdgetBP_C
// Size: 0x468 (Inherited: 0x468)
struct UKeyImageWIdgetBP_C : U*1d68794586 {
	bool bShift; // 0x440(0x01)
	bool bCtrl; // 0x441(0x01)
	bool bAlt; // 0x442(0x01)
	struct U*c1ef4cc603* ModifierPanel; // 0x448(0x08)
	struct UImage* ModifierKeyImage; // 0x450(0x08)
	struct UTextBlock* PlusTextBlock; // 0x458(0x08)
	int32 DesiredPlusTextFontSize; // 0x460(0x04)
};

