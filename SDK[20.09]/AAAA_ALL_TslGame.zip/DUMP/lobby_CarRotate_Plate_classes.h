// BlueprintGeneratedClass lobby_CarRotate_Plate.lobby_CarRotate_Plate_C
// Size: 0x410 (Inherited: 0x3f0)
struct Alobby_CarRotate_Plate_C : AActor {
	struct UStaticMeshComponent* lobby_Vehicel_Floor_Rotate_Main01; // 0x3f0(0x08)
	struct UStaticMeshComponent* lobby_Helmet3_Logo; // 0x3f8(0x08)
	struct UStaticMeshComponent* lobby_Vehicel_Floor_Rotate_sub01; // 0x400(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x408(0x08)
};

