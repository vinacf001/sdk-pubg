// WidgetBlueprintGeneratedClass BP_DisplayOptionSliderWidget.BP_DisplayOptionSliderWidget_C
// Size: 0x890 (Inherited: 0x868)
struct UBP_DisplayOptionSliderWidget_C : U*241f31645a {
	struct F*73a77c28fa UberGraphFrame; // 0x868(0x08)
	struct UProgressBar* BrightnessProgressBar; // 0x870(0x08)
	struct USlider* BrightnessSlider; // 0x878(0x08)
	struct UEditableText* BrightnessText; // 0x880(0x08)
	struct UProgressBar* NewVar_1; // 0x888(0x08)

	void Tick(); // Function BP_DisplayOptionSliderWidget.BP_DisplayOptionSliderWidget_C.Tick // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x1e037c
	struct FGeometry ExecuteUbergraph_BP_DisplayOptionSliderWidget(); // Function BP_DisplayOptionSliderWidget.BP_DisplayOptionSliderWidget_C.ExecuteUbergraph_BP_DisplayOptionSliderWidget // HasDefaults // @ game+0x1e037c
};

