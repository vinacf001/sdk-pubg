// BlueprintGeneratedClass Buff_BoostHealOverTime.Buff_BoostHealOverTime_C
// Size: 0x498 (Inherited: 0x490)
struct ABuff_BoostHealOverTime_C : ABuff_BoostHealOverTime {
	struct USceneComponent* DefaultSceneRoot; // 0x490(0x08)
};

