// ScriptStruct AssetRegistry.AssetBundleData
// Size: 0x10 (Inherited: 0x00)
struct FAssetBundleData {
	struct TArray<struct F*8d187fe4dc> *e613c44b38; // 0x00(0x10)
};

// ScriptStruct AssetRegistry.*8d187fe4dc
// Size: 0x28 (Inherited: 0x00)
struct F*8d187fe4dc {
	struct FPrimaryAssetId *736c0ff9d5; // 0x00(0x10)
	struct FName BundleName; // 0x10(0x08)
	struct TArray<struct FStringAssetReference> *30fc9989fc; // 0x18(0x10)
};

