// Enum PrefabAsset.*82089f54f6
enum class *82089f54f6 : uint8 {
	*e0c8f6da65,
	*05207b0a37,
	*48225b2537,
	*82089f54f6_MAX,
};

// ScriptStruct PrefabAsset.*f3ec451ec7
// Size: 0x28 (Inherited: 0x00)
struct F*f3ec451ec7 {
	char bImportant : 1; // 0x00(0x01)
	char pad_0_1 : 7; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	enum class *c0765ad24b IndoorOutdoor; // 0x04(0x01)
	struct FLightingChannels LightingChannels; // 0x05(0x03)
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // 0x08(0x10)
	struct FString ParentPrefab; // 0x18(0x10)
};

