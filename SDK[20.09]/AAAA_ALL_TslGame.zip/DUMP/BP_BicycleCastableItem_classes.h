// BlueprintGeneratedClass BP_BicycleCastableItem.BP_BicycleCastableItem_C
// Size: 0x98 (Inherited: 0x98)
struct UBP_BicycleCastableItem_C : U*31bfd8ccf6 {
	struct UClass* *eb935de0c2; // 0x28(0x20)
	struct UClass* *d0c62f66f6; // 0x48(0x08)
	struct F*47b656c0d7 *b3cd9251d3; // 0x50(0x38)
};

