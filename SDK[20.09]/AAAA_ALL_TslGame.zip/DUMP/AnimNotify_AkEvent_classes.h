// BlueprintGeneratedClass AnimNotify_AkEvent.AnimNotify_AkEvent_C
// Size: 0x60 (Inherited: 0x60)
struct UAnimNotify_AkEvent_C : UAnimNotify_AkEvent {
	struct UAkAudioEvent* AkEvent; // 0x38(0x08)
	struct U*017342191e* EventData; // 0x40(0x08)
	struct FName EventDataTag; // 0x48(0x08)
	bool bFollowOwner; // 0x50(0x01)
	float MaxPlayRange; // 0x54(0x04)
	bool bMuteOnPlayingEmote; // 0x58(0x01)
	bool bMuteOnPlayingMoveEmote; // 0x59(0x01)
	bool bIsLocalPlayerTypeInPreview; // 0x5a(0x01)
};

