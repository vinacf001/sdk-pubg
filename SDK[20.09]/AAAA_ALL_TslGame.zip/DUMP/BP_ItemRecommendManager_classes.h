// BlueprintGeneratedClass BP_ItemRecommendManager.BP_ItemRecommendManager_C
// Size: 0x118 (Inherited: 0x118)
struct UBP_ItemRecommendManager_C : U*0952b72b34 {
	struct TMap<struct UObject*, struct AActor*> *7a683f9b56; // 0x40(0x50)
	struct TArray<struct AActor*> *eef747f547; // 0x90(0x10)
	float *9223583ad3; // 0xb4(0x04)
	float *e7ba514a73; // 0xb8(0x04)
	float *88fc3b8563; // 0xbc(0x04)
	struct UClass* *6f5381805c; // 0xc0(0x08)
	float *4bbe45d303; // 0xc8(0x04)
	int32 *618a8da903; // 0xcc(0x04)
};

