// WidgetBlueprintGeneratedClass InteractInfoTextWidget.InteractInfoTextWidget_C
// Size: 0x578 (Inherited: 0x548)
struct UInteractInfoTextWidget_C : U*2679a92f7f {
	struct U*6b11b3bf02* Blinking; // 0x548(0x08)
	struct UHorizontalBox* InteractInfoCancelMsgBox; // 0x550(0x08)
	struct UBorder* InteractInfoCancelMsgLayer; // 0x558(0x08)
	struct UTextBlock* InteractInfoText; // 0x560(0x08)
	struct UBorder* InteractInfoTextBox; // 0x568(0x08)
	struct UTextBlock* InteractText; // 0x570(0x08)
};

