// WidgetBlueprintGeneratedClass BP_PcOptionTooltipWidget.BP_PcOptionTooltipWidget_C
// Size: 0x430 (Inherited: 0x430)
struct UBP_PcOptionTooltipWidget_C : U*d3b0f737be {
	struct UTextBlock* OptionTooltipText; // 0x410(0x08)
	struct FVector2D PositionOffset; // 0x418(0x08)
	struct UWidget* *259ccb060f; // 0x420(0x08)
};

