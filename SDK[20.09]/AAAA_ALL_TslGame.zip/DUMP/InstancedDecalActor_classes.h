// BlueprintGeneratedClass InstancedDecalActor.InstancedDecalActor_C
// Size: 0x3f8 (Inherited: 0x3f8)
struct AInstancedDecalActor_C : ADecalActor {
	struct UDecalComponent* Decal; // 0x3f0(0x08)

	void *5ef8202fe7(); // Function Engine.DecalActor.*5ef8202fe7 // Final|Native|Public|BlueprintCallable|BlueprintPure|Const // @ game+0x638e08c
	void CreateDynamicMaterialInstance(); // Function Engine.DecalActor.CreateDynamicMaterialInstance // Native|Public|BlueprintCallable // @ game+0x5616eac
	void *e5a6406b5b(); // Function Engine.DecalActor.*e5a6406b5b // Final|Native|Public|BlueprintCallable // @ game+0x63a09dc
};

