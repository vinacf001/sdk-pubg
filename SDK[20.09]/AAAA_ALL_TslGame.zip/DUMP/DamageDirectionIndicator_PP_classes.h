// BlueprintGeneratedClass DamageDirectionIndicator_PP.DamageDirectionIndicator_PP_C
// Size: 0x488 (Inherited: 0x478)
struct ADamageDirectionIndicator_PP_C : ATslPostProcessEffect {
	struct F*73a77c28fa UberGraphFrame; // 0x478(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x480(0x08)

	void UserConstructionScript(); // Function DamageDirectionIndicator_PP.DamageDirectionIndicator_PP_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	void ExecuteUbergraph_DamageDirectionIndicator_PP(); // Function DamageDirectionIndicator_PP.DamageDirectionIndicator_PP_C.ExecuteUbergraph_DamageDirectionIndicator_PP //  // @ game+0x1e037c
};

