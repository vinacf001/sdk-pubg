// WidgetBlueprintGeneratedClass BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C
// Size: 0x8c0 (Inherited: 0x890)
struct UBP_PcOptionItemDropDownListWidget_C : U*d1ec4ebb6e {
	struct F*73a77c28fa UberGraphFrame; // 0x890(0x08)
	struct U*15885c1d90* ComboBox; // 0x898(0x08)
	struct UButton* ComboBoxButton; // 0x8a0(0x08)
	struct USizeBox* IndentationSizeBox; // 0x8a8(0x08)
	struct FMulticastDelegate OnSelectionChanged; // 0x8b0(0x10)

	void BndEvt__ComboBox_K2Node_ComponentBoundEvent_21_OnSelectionChangedEvent__DelegateSignature(); // Function BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C.BndEvt__ComboBox_K2Node_ComponentBoundEvent_21_OnSelectionChangedEvent__DelegateSignature // BlueprintEvent // @ game+0x1e037c
	struct FString ExecuteUbergraph_BP_PcOptionItemDropDownListWidget(); // Function BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C.ExecuteUbergraph_BP_PcOptionItemDropDownListWidget //  // @ game+0x1e037c
	struct FString OnSelectionChanged__DelegateSignature(); // Function BP_PcOptionItemDropDownListWidget.BP_PcOptionItemDropDownListWidget_C.OnSelectionChanged__DelegateSignature // Public|Delegate|BlueprintCallable|BlueprintEvent // @ game+0x1e037c
};

