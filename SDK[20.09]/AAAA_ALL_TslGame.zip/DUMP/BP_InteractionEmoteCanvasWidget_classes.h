// WidgetBlueprintGeneratedClass BP_InteractionEmoteCanvasWidget.BP_InteractionEmoteCanvasWidget_C
// Size: 0x438 (Inherited: 0x438)
struct UBP_InteractionEmoteCanvasWidget_C : U*c9d024cf01 {
	struct U*6b11b3bf02* InfoBlink; // 0x410(0x08)
	struct U*6b11b3bf02* InfoEmerging; // 0x418(0x08)
	struct U*6b11b3bf02* InfoVanishing; // 0x420(0x08)
	struct UTextBlock* EmoteMessageText; // 0x428(0x08)

	void OnInteract(); // Function TslGame.*c9d024cf01.OnInteract // Final|Native|Public // @ game+0x56e8334
};

