// BlueprintGeneratedClass Powerup_AidKit.Powerup_AidKit_C
// Size: 0x458 (Inherited: 0x448)
struct APowerup_AidKit_C : APowerup_Base_C {
	struct F*73a77c28fa UberGraphFrame; // 0x448(0x08)
	struct F*9c84e0ea54 Timer2Handle; // 0x450(0x08)

	void UserConstructionScript(); // Function Powerup_AidKit.Powerup_AidKit_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	void ReceiveBeginPlay(); // Function Powerup_AidKit.Powerup_AidKit_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x1e037c
	void ReceiveDestroyed(); // Function Powerup_AidKit.Powerup_AidKit_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x1e037c
	void CustomEvent_1(); // Function Powerup_AidKit.Powerup_AidKit_C.CustomEvent_1 // BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	struct F*9c84e0ea54 ExecuteUbergraph_Powerup_AidKit(DelegateProperty _37b0074df2_OutputDelegate); // Function Powerup_AidKit.Powerup_AidKit_C.ExecuteUbergraph_Powerup_AidKit // HasDefaults // @ game+0x1e037c
};

