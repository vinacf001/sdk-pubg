// ScriptStruct EngineMessages.*b11e487a0b
// Size: 0x18 (Inherited: 0x00)
struct F*b11e487a0b {
	struct FString Text; // 0x00(0x10)
	double TimeSeconds; // 0x10(0x08)
};

// ScriptStruct EngineMessages.*d25be5e9de
// Size: 0x10 (Inherited: 0x00)
struct F*d25be5e9de {
	struct FString UserName; // 0x00(0x10)
};

// ScriptStruct EngineMessages.*a74090e525
// Size: 0x20 (Inherited: 0x00)
struct F*a74090e525 {
	struct FString Command; // 0x00(0x10)
	struct FString UserName; // 0x10(0x10)
};

// ScriptStruct EngineMessages.*45d24fa2c7
// Size: 0x20 (Inherited: 0x00)
struct F*45d24fa2c7 {
	struct FString UserName; // 0x00(0x10)
	struct FString *ca4ed6c3de; // 0x10(0x10)
};

// ScriptStruct EngineMessages.*c8f68b19cc
// Size: 0x20 (Inherited: 0x00)
struct F*c8f68b19cc {
	struct FString UserName; // 0x00(0x10)
	struct FString *c28f31c888; // 0x10(0x10)
};

// ScriptStruct EngineMessages.*9d50198c7d
// Size: 0x50 (Inherited: 0x00)
struct F*9d50198c7d {
	struct FString CurrentLevel; // 0x00(0x10)
	int32 EngineVersion; // 0x10(0x04)
	bool *c133fde381; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	struct FGuid InstanceId; // 0x18(0x10)
	struct FString InstanceType; // 0x28(0x10)
	struct FGuid SessionId; // 0x38(0x10)
	float *929a14f176; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// ScriptStruct EngineMessages.*8e7d182b69
// Size: 0x01 (Inherited: 0x00)
struct F*8e7d182b69 {
	char pad_0[0x1]; // 0x00(0x01)
};

