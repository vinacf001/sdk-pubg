// BlueprintGeneratedClass BP_PP_OutlineCustomDepthOcclusion_Inst.BP_PP_OutlineCustomDepthOcclusion_Inst_C
// Size: 0x480 (Inherited: 0x478)
struct ABP_PP_OutlineCustomDepthOcclusion_Inst_C : ATslPostProcessEffect {
	struct USceneComponent* DefaultSceneRoot; // 0x478(0x08)
};

