// WidgetBlueprintGeneratedClass LobbyRotationRectWidget.LobbyRotationRectWidget_C
// Size: 0x420 (Inherited: 0x418)
struct ULobbyRotationRectWidget_C : U*030f977d4f {
	struct UImage* RotationRect; // 0x418(0x08)
};

