// BlueprintGeneratedClass LobbyPostPorcessEffect.LobbyPostPorcessEffect_C
// Size: 0x480 (Inherited: 0x478)
struct ALobbyPostPorcessEffect_C : ATslPostProcessEffect {
	struct USceneComponent* DefaultSceneRoot; // 0x478(0x08)
};

