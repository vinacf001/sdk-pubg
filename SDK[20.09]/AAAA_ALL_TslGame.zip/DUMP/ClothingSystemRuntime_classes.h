// Class ClothingSystemRuntime.*5ed7fe2be7
// Size: 0x28 (Inherited: 0x28)
struct U*5ed7fe2be7 : UObject {
};

// Class ClothingSystemRuntime.ClothingAsset
// Size: 0x158 (Inherited: 0x48)
struct UClothingAsset : U*9695c7a28c {
	struct F*edc1a71729 *edc1a71729; // 0x48(0xbc)
	char pad_104[0x4]; // 0x104(0x04)
	struct TArray<struct F*c79c15f315> *6f651a8a78; // 0x108(0x10)
	struct TArray<int32> *d0f8878831; // 0x118(0x10)
	struct TArray<struct FName> *ba34fee0dc; // 0x128(0x10)
	struct TArray<int32> *7994b28604; // 0x138(0x10)
	int32 *98892b785e; // 0x148(0x04)
	char pad_14C[0x4]; // 0x14c(0x04)
	struct U*5ed7fe2be7* CustomData; // 0x150(0x08)
};

// Class ClothingSystemRuntime.*07d5681c88
// Size: 0x28 (Inherited: 0x28)
struct U*07d5681c88 : U*b14b3c8b7b {
};

