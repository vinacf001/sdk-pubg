// BlueprintGeneratedClass FBRBuff_Medikit_pa_lv1.FBRBuff_Medikit_pa_lv1_C
// Size: 0x4c8 (Inherited: 0x4c0)
struct AFBRBuff_Medikit_pa_lv1_C : ATslFBRItemBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4c0(0x08)
};

