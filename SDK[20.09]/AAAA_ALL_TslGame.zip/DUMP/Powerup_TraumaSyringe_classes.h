// BlueprintGeneratedClass Powerup_TraumaSyringe.Powerup_TraumaSyringe_C
// Size: 0x458 (Inherited: 0x448)
struct APowerup_TraumaSyringe_C : APowerup_Base_C {
	struct F*73a77c28fa UberGraphFrame; // 0x448(0x08)
	struct F*9c84e0ea54 Timer2Handle; // 0x450(0x08)

	void UserConstructionScript(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	void Throw Syringe Cap Away(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.Throw Syringe Cap Away // BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	void ReceiveDestroyed(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.ReceiveDestroyed // Event|Public|BlueprintEvent // @ game+0x1e037c
	float Init Syringe Delay(); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.Init Syringe Delay // BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	int32 ExecuteUbergraph_Powerup_TraumaSyringe(float K2Node_CustomEvent_Syringe_Throw_Delay, struct F*9c84e0ea54 CallFunc__bee29fc1fc_ReturnValue); // Function Powerup_TraumaSyringe.Powerup_TraumaSyringe_C.ExecuteUbergraph_Powerup_TraumaSyringe // HasDefaults // @ game+0x1e037c
};

