// BlueprintGeneratedClass FBPBuff_AddJump.FBPBuff_AddJump_C
// Size: 0x4a8 (Inherited: 0x4a0)
struct AFBPBuff_AddJump_C : ATslFBRBuff {
	struct USceneComponent* DefaultSceneRoot; // 0x4a0(0x08)
};

