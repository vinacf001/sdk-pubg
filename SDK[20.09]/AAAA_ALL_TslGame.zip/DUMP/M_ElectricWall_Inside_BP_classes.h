// BlueprintGeneratedClass M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C
// Size: 0x498 (Inherited: 0x478)
struct AM_ElectricWall_Inside_BP_C : ATslPostProcessEffect {
	struct F*73a77c28fa UberGraphFrame; // 0x478(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x480(0x08)
	float _____0______0_F1196C2844F052526643A091F7753F02; // 0x488(0x04)
	enum class ETimelineDirection _____0__Direction_F1196C2844F052526643A091F7753F02; // 0x48c(0x01)
	char pad_48D[0x3]; // 0x48d(0x03)
	struct UTimelineComponent* �Є�|�x�_1; // 0x490(0x08)

	void UserConstructionScript(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.UserConstructionScript // Event|Public|BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	void �Є�|�x�_(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.�Є�|�x�_ // BlueprintEvent // @ game+0x1e037c
	void �Є�|�x�_(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.�Є�|�x�_ // BlueprintEvent // @ game+0x1e037c
	void ReceiveBeginPlay(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.ReceiveBeginPlay // Event|Protected|BlueprintEvent // @ game+0x1e037c
	void Custom Event_1(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.Custom Event_1 // BlueprintCallable|BlueprintEvent // @ game+0x1e037c
	struct FString OnSetEffectParameter(); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.OnSetEffectParameter // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x1e037c
	bool ExecuteUbergraph_M_ElectricWall_Inside_BP(DelegateProperty _37b0074df2_OutputDelegate, float CallFunc_RandomFloatInRange_ReturnValue, struct FString K2Node_Event_ParameterName, bool CallFunc__3e55e7d95c_ReturnValue3); // Function M_ElectricWall_Inside_BP.M_ElectricWall_Inside_BP_C.ExecuteUbergraph_M_ElectricWall_Inside_BP // HasDefaults // @ game+0x1e037c
};

