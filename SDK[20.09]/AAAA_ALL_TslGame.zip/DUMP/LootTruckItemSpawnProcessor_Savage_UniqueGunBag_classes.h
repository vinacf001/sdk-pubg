// BlueprintGeneratedClass LootTruckItemSpawnProcessor_Savage_UniqueGunBag.LootTruckItemSpawnProcessor_Savage_UniqueGunBag_C
// Size: 0x130 (Inherited: 0x130)
struct ULootTruckItemSpawnProcessor_Savage_UniqueGunBag_C : U*0f96463040 {
	struct FString PresetSpawnTableKey; // 0x120(0x10)
};

