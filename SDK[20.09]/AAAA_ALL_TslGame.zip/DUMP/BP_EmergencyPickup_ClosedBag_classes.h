// BlueprintGeneratedClass BP_EmergencyPickup_ClosedBag.BP_EmergencyPickup_ClosedBag_C
// Size: 0x408 (Inherited: 0x400)
struct ABP_EmergencyPickup_ClosedBag_C : ATslEmPickupBag {
	struct UStaticMeshComponent* StaticMesh; // 0x400(0x08)
};

