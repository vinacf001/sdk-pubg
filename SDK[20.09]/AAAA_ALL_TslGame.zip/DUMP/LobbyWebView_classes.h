// WidgetBlueprintGeneratedClass LobbyWebView.LobbyWebView_C
// Size: 0x438 (Inherited: 0x430)
struct ULobbyWebView_C : U*fe99a42592 {
	struct ULobbyRotationRectWidget_C* RotationRect; // 0x430(0x08)
};

