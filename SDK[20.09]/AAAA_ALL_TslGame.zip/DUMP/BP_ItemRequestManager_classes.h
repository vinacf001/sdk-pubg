// BlueprintGeneratedClass BP_ItemRequestManager.BP_ItemRequestManager_C
// Size: 0x500 (Inherited: 0x500)
struct UBP_ItemRequestManager_C : U*6b4ad9b3c1 {
	struct U*5fc898fe2e* *093df3e14f; // 0x28(0x08)
	float *83033696d7; // 0x30(0x04)
	float *8df9c71136; // 0x34(0x04)
	float *cf3a5b07d1; // 0x38(0x04)
	float *84f9bdc1fa; // 0x3c(0x04)
	float *41c92ddfda; // 0x40(0x04)
	float *91fc543fad; // 0x44(0x04)
	float *b664ac6273; // 0x48(0x04)
	float *a7f54619c4; // 0x4c(0x04)
	float *083dc3ea00; // 0x50(0x04)
	bool *a85eb68481; // 0x54(0x01)
	bool *68fa3fe0e2; // 0x55(0x01)
	struct FName *9f13881ab6; // 0x58(0x08)
	struct FName *82792ac60d; // 0x60(0x08)
	struct TMap<struct FName, int32> *21b8d24f3f; // 0x68(0x50)
	struct TMap<enum class ERadioMessageCategory, struct FName> *1b4bde6360; // 0xb8(0x50)
	struct TArray<struct FName> *5fd4b47689; // 0x108(0x10)
	struct FString *a6d9a5817d; // 0x118(0x10)
	struct FText *97577d29c3; // 0x128(0x18)
	struct FText *867d58f113; // 0x140(0x18)
	struct FName *f91a2f37ef; // 0x158(0x08)

	void OnInputReleased(); // Function TslGame.*6b4ad9b3c1.OnInputReleased // Final|Native|Public // @ game+0x56af764
	void *eb0d2edee7(struct ATslPlayerState* Param0); // Function TslGame.*6b4ad9b3c1.*eb0d2edee7 // Final|Native|Private|HasOutParms // @ game+0x56b03f8
	void OnInputPressed(); // Function TslGame.*6b4ad9b3c1.OnInputPressed // Final|Native|Public // @ game+0x56af750
	void *d3f8fd7c76(); // Function TslGame.*6b4ad9b3c1.*d3f8fd7c76 // Final|Native|Public|HasOutParms // @ game+0x56aee50
	struct ATslPlayerState* *794242d128(); // Function TslGame.*6b4ad9b3c1.*794242d128 // Final|Native|Private // @ game+0x56b031c
};

