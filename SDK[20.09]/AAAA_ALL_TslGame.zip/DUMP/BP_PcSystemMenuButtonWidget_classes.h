// WidgetBlueprintGeneratedClass BP_PcSystemMenuButtonWidget.BP_PcSystemMenuButtonWidget_C
// Size: 0x4e0 (Inherited: 0x4c0)
struct UBP_PcSystemMenuButtonWidget_C : U*037b984307 {
	struct F*73a77c28fa UberGraphFrame; // 0x4c0(0x08)
	struct UTextBlock* ButtonText; // 0x4c8(0x08)
	struct FMulticastDelegate OnClicked; // 0x4d0(0x10)

	void PreConstruct(); // Function BP_PcSystemMenuButtonWidget.BP_PcSystemMenuButtonWidget_C.PreConstruct // BlueprintCosmetic|Event|Public|BlueprintEvent // @ game+0x1e037c
	void BndEvt__Button_Internal_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function BP_PcSystemMenuButtonWidget.BP_PcSystemMenuButtonWidget_C.BndEvt__Button_Internal_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // BlueprintEvent // @ game+0x1e037c
	int32 ExecuteUbergraph_BP_PcSystemMenuButtonWidget(); // Function BP_PcSystemMenuButtonWidget.BP_PcSystemMenuButtonWidget_C.ExecuteUbergraph_BP_PcSystemMenuButtonWidget //  // @ game+0x1e037c
	void OnClicked__DelegateSignature(); // Function BP_PcSystemMenuButtonWidget.BP_PcSystemMenuButtonWidget_C.OnClicked__DelegateSignature // Public|Delegate|BlueprintCallable|BlueprintEvent // @ game+0x1e037c
};

