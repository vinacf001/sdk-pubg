// BlueprintGeneratedClass BP_ZiplinePostProcessEffect.BP_ZiplinePostProcessEffect_C
// Size: 0x480 (Inherited: 0x478)
struct ABP_ZiplinePostProcessEffect_C : ATslPostProcessEffect {
	struct USceneComponent* DefaultSceneRoot; // 0x478(0x08)
};

