// BlueprintGeneratedClass DmgTypeBP_Environmental.DmgTypeBP_Environmental_C
// Size: 0x40 (Inherited: 0x40)
struct UDmgTypeBP_Environmental_C : U*498af98d1d {
	char bCausedByWorld : 1; // 0x28(0x01)
	char bScaleMomentumByMass : 1; // 0x28(0x01)
	char bRadialDamageVelChange : 1; // 0x28(0x01)
	float DamageImpulse; // 0x2c(0x04)
	float DestructibleImpulse; // 0x30(0x04)
	float DestructibleDamageSpreadScale; // 0x34(0x04)
	float DamageFalloff; // 0x38(0x04)
};

