// WidgetBlueprintGeneratedClass LobbyNameTagWildCard.LobbyNameTagWildCard_C
// Size: 0x508 (Inherited: 0x4c0)
struct ULobbyNameTagWildCard_C : U*535e5949ee {
	struct UImage* HostImage; // 0x4c0(0x08)
	struct UImage* InAMatchImg; // 0x4c8(0x08)
	struct UImage* LogoutImg; // 0x4d0(0x08)
	struct UImage* NotReadyImg; // 0x4d8(0x08)
	struct UImage* QueuingImg; // 0x4e0(0x08)
	struct UImage* ReadyImg; // 0x4e8(0x08)
	struct UImage* VoiceDetect; // 0x4f0(0x08)
	struct UImage* VoiceMute; // 0x4f8(0x08)
	struct UImage* VoiceNormal; // 0x500(0x08)
};

